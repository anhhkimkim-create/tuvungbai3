# Hướng dẫn phần Thi đấu (xếp hạng)

## Phần này làm được gì
- Chủ phòng tạo phòng và nhận **mã phòng 5 ký tự**, **link mời** và **mã QR**.
- Người chơi mở link (hoặc nhập mã ở mục **Thi đấu**) rồi **đặt tên**. Tên không được trùng với người khác trong phòng.
- Chủ phòng thấy danh sách người đã vào, có thể **mời ra** người đặt tên bậy, rồi bấm **Bắt đầu**.
- Mọi người làm **cùng một bộ câu hỏi** từ vựng Bài 3. Có 10, 15, 20 hoặc 30 câu, chọn được nhóm từ. Không có câu nghe, không có ngữ pháp.
- **Mỗi trận có giờ: 12 giây cho mỗi câu** (10 câu = 2 phút, 15 câu = 3 phút, 20 câu = 4 phút, 30 câu = 6 phút).
  Đồng hồ đếm ngược ở góc trên, chuyển đỏ khi còn 10 giây. Hết giờ là trận kết thúc, câu chưa làm không có điểm.
- **Trận cũng kết thúc 3 giây sau khi người đầu tiên làm xong tất cả các câu** (cái nào đến trước thì tính). Trong 3 giây đó, mọi người thấy dòng "… đã về đích!" và vẫn được trả lời tiếp.
- **Bảng xếp hạng** hiện ngay trong game cho cả phòng. Ngay sau đó **mèo Mochi** nhận xét theo thứ hạng của từng người:
  - Top 1–5: "Bạn quá xuất sắc, xuất khẩu vô tư nha!"
  - Top 6–12: "Cũng bình thường thôi."
  - Từ hạng 13: "とり / gà"
- **Ván mới:** chơi lại với những người đang ở trong phòng, bộ câu hỏi mới.

## Cách tính điểm
- Mỗi câu đúng được 100 điểm. Trả lời trong 2 giây được thêm 50 điểm; phần thưởng giảm dần và hết hẳn sau 8 giây.
- Xếp hạng lần lượt theo: điểm → số câu đúng → ai đã làm xong → ai nhanh hơn.
- **Chống bấm bừa** (bật sẵn, tắt được khi tạo phòng): người về đích đầu tiên phải đúng ít nhất một nửa số câu thì trận mới kết thúc sớm. Như vậy một người bấm bừa cho nhanh không làm cả phòng phải dừng.
- Trận cũng kết thúc khi tất cả mọi người làm xong, hoặc khi chủ phòng bấm **Kết thúc trận**.

## Điều quan trọng: máy chủ phòng chính là "máy chủ"
Không có máy chủ riêng hay tài khoản nào. Các máy người chơi kết nối thẳng với máy chủ phòng qua mạng (WebRTC). Máy chủ ghép phòng miễn phí 0.peerjs.com chỉ giúp hai máy tìm thấy nhau.
- Chủ phòng **giữ trang game mở và màn hình sáng** tới khi xong trận. Tải lại hoặc đóng trang là phòng đóng.
- Nên làm chủ phòng bằng laptop hoặc máy tính đang cắm sạc. Dùng điện thoại thì đừng chuyển sang ứng dụng khác lâu.
- Chủ phòng có thể **cùng chơi** (bật sẵn) hoặc **chỉ xem** tiến độ cả phòng để chiếu lên màn hình lớn.
- Tối đa 60 người một phòng.
- Người chơi mất mạng giữa trận: game tự kết nối lại, người đó giữ nguyên chỗ và các câu đã làm.

## Đưa game lên mạng để có link riêng (không có chữ claude.ai)
Phần thi đấu cần mở game từ một trang web thật. Bản trong claude.ai không kết nối ra ngoài được, và file mở trên máy thì không có link để gửi.

**Netlify (miễn phí, khoảng 5 phút):**
1. Vào https://app.netlify.com/signup và đăng ký miễn phí bằng Email (hoặc GitHub). **Đăng nhập trước rồi mới tải game lên**:
   thả file lúc chưa đăng nhập thì trang bị khóa bằng mật khẩu tạm cho tới khi bạn nhận về tài khoản.
2. Chọn **Add new project** (có chỗ ghi *Add new site*) → **Deploy manually**, rồi kéo cả thư mục `kotoba-game` vào ô thả file.
   Cách nhanh hơn: mở thẳng https://app.netlify.com/drop rồi kéo thư mục vào.
3. Vào **Project configuration** (hoặc *Site configuration*) → **Change project name** và đặt tên, ví dụ `kotoba-bai3`.
   Link sẽ là `https://kotoba-bai3.netlify.app`. Đây là link bạn gửi mọi người, link mời vào phòng cũng bắt đầu bằng địa chỉ này.
4. Khi game có bản mới: vào tab **Deploys** của project, kéo thư mục `kotoba-game` vào lại. Link giữ nguyên.

Cách khác: GitHub Pages hoặc Cloudflare Pages cũng được, vì game chỉ gồm file tĩnh. Muốn tên miền riêng (.com, .vn) thì mua tên miền rồi gắn vào Netlify.

## Chơi khác mạng (Wi-Fi ↔ 4G, mỗi người một nhà): cài máy chuyển tiếp
Cùng một Wi-Fi thì các máy nối thẳng được với nhau. Khác mạng thì nhà mạng thường chặn kết nối thẳng, nên cần một
**máy chuyển tiếp (TURN)** đứng giữa. Máy chuyển tiếp miễn phí của PeerJS đã ngừng hoạt động, vì vậy bạn cần tạo
một máy chuyển tiếp riêng (miễn phí 20 GB mỗi tháng ở Metered; một trận thi chỉ tốn vài chục KB mỗi người):
1. Đăng ký ở https://dashboard.metered.ca/signup.
2. Menu bên trái: **TURN Server → Credentials** → **Create Credential** → **Create credential**.
3. Ở dòng vừa tạo, bấm nút **ICE** để copy danh sách máy chủ (hoặc **Get credential → Show ICE Servers Array**).
4. Mở file `js/contest/contest-turn-relay-config.js` bằng Notepad, dán đè lên dấu `[]` ở dòng `KT.CONTEST_ICE_SERVERS`,
   giữ dấu `;` ở cuối, lưu lại. (Hoặc gửi đoạn vừa copy cho Claude để gắn giúp.)
5. Đưa lại thư mục game lên Netlify (mục **Production deploys**).

Khi chưa cài, phòng chờ của chủ phòng có dòng nhắc "người chơi cần dùng chung Wi-Fi", và người ở mạng khác sẽ thấy
thông báo giải thích thay vì chờ mãi. Thông tin máy chuyển tiếp nằm công khai trong game (máy người chơi cần nó để
kết nối) — đó là cách dùng bình thường; tệ nhất là người lạ dùng ké hạn mức miễn phí.
Dự phòng: ExpressTURN (https://www.expressturn.com) miễn phí 1000 GB/tháng nhưng gói miễn phí chỉ có cổng 3478,
một số mạng trường học chặn cổng này.

## Tổ chức một trận
1. Mở link Netlify → tab **Thi đấu** → điền **Tạo phòng mới** → **Tạo phòng**.
2. Gửi **link mời** (nút Sao chép link hoặc Chia sẻ) vào nhóm Zalo hay Messenger, hoặc chiếu **mã QR** cho cả lớp quét.
3. Chờ tên mọi người hiện trong danh sách → **Bắt đầu**.
4. Xong trận: xem bảng xếp hạng → **Ván mới** hoặc **Đóng phòng**.

## Nếu có người không vào được
- "Không tìm thấy phòng": kiểm tra lại mã, hoặc trang của chủ phòng đã bị đóng hay tải lại.
- "Không nối được tới chủ phòng": người chơi đang ở mạng khác mà game chưa cài máy chuyển tiếp (xem mục "Chơi khác mạng"),
  hoặc mạng trường/công ty chặn kiểu kết nối này. Máy chuyển tiếp Metered có cổng 443 nên vượt được phần lớn tường lửa.
- Dùng Chrome, Edge, Safari hoặc Firefox bản mới.

## Dữ liệu
- Tên và điểm chỉ đi giữa các máy trong phòng. Không có máy chủ nào lưu bảng xếp hạng.
- Mỗi máy tự nhớ tên đã dùng và 6 trận gần nhất (mục "Trận gần đây").
- Tiến độ học trong thành phố không bị ảnh hưởng bởi kết quả thi.