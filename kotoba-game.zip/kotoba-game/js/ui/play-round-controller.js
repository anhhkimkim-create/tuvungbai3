/* Play screen + round controller: word card -> question -> record answer ->
   feedback (wrong answers wait for "Đã hiểu") -> next, then the round results.
   Every answer is saved immediately, so leaving mid-round never loses progress. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;
  const kindOf = (type) => (type === 'workshop' ? 'workshop' : type === 'match' ? 'match' : 'choice');

  const P = (KT.play = {
    round: null, q: null, timer: null, auto: null, timeLeft: 0, voiceNotice: false,

    start(round) {
      if (!round || !round.items.length) { KT.app.toast('Chưa có từ nào để chơi ở đây.'); return; }
      const S = KT.store.S;
      S.round += 1; S.started = true;
      Object.assign(round, {
        no: S.round, idx: 0, correct: 0, answered: 0, streak: 0, gainScore: 0, gainShards: 0,
        introduced: [], wrongIds: [], restored: [], mastered: [],
        pctBefore: round.zone ? KT.learn.zoneStats(round.zone).pct : null,
        unlockedBefore: KT.ZONES.filter((z) => KT.learn.unlocked(z.id)).map((z) => z.id),
      });
      P.round = round;
      KT.store.save();
      KT.app.go('play');
      if (!KT.speech.ok() && !P.voiceNotice) {
        P.voiceNotice = true;
        KT.app.toast('Thiết bị chưa có giọng đọc tiếng Nhật, nên thử thách nghe được thay bằng thử thách nhìn chữ.', 5200);
      }
    },

    next() {
      const r = P.round;
      clearTimeout(P.auto);
      if (P.q && P.q.cleanup) P.q.cleanup();
      P.q = null;
      U.$('#play-feedback').hidden = true;
      if (r.idx >= r.items.length) { P.finish(); return; }
      const it = r.items[r.idx];
      U.$('#play-bar').style.setProperty('--p', U.pct(r.idx, r.items.length) + '%');
      U.$('#play-count').textContent = (r.idx + 1) + '/' + r.items.length;
      if (it.intro && !it.introShown && !KT.learn.peek(it.id).in) { it.introShown = true; P.showIntro(it); return; }
      P.ask(it);
    },

    makeQ(it) {
      const r = P.round, w = KT.WORD[it.id];
      const q = { item: it, word: w, type: it.type, zone: it.zone, kind: kindOf(it.type), answered: false,
        assisted: !!it.retry, variant: (r.idx * 7 + w.id.length) % 9 };
      if (q.zone === 5) q.season = w.season || KT.stage.SEASONS[Math.floor(r.correct / 2) % 4];
      if (q.kind === 'choice') { const o = KT.options.forType(q.type, w, 4); q.options = o.words; q.mode = o.mode; }
      return q;
    },

    showIntro(it) {
      const q = P.makeQ(it);
      U.$('#play-body').innerHTML = '<div class="play-q">' + KT.challenges.intro.render(q) + '</div>';
      KT.learn.introduce(it.id);
      P.round.introduced.push(it.id);
      KT.store.save();
      const b = U.$('[data-act="introDone"]');
      if (b) b.focus({ preventScroll: true });
    },

    ask(it) {
      const q = (P.q = P.makeQ(it));
      KT.learn.tick();
      U.$('#play-body').innerHTML = '<div class="play-q" id="play-q">' + KT.challenges[q.kind].render(q) + '</div>';
      const root = U.$('#play-q');
      U.$$('.s-lantern', root).forEach((l, i) => l.classList.toggle('on', i < P.round.correct));
      KT.challenges[q.kind].mount(root, q, (res) => P.answer(q, res));
      const title = U.$('.q-title', root);
      if (title) { title.setAttribute('tabindex', '-1'); title.focus({ preventScroll: true }); }
      P.startTimer(q);
    },

    answer(q, res) {
      if (q.answered || P.q !== q) return;
      q.answered = true;
      P.stopTimer();
      const r = P.round, S = KT.store.S, root = U.$('#play-q');
      if (q.kind === 'match' && res.timeout) {
        res.perWord = q.set.map((w) => ({ id: w.id, correct: !!q.matched[w.id] && !q.mistakes[w.id] }));
      }
      const fam = q.switched ? 'B' : KT.TYPES[q.type].fam;
      const assisted = q.assisted || !!res.assisted;
      const per = res.perWord || [{ id: q.word.id, correct: res.correct }];
      per.forEach((pw) => {
        const out = KT.learn.record(pw.id, fam, pw.correct, { assisted });
        if (out.firstCorrect) r.restored.push(pw.id);
        if (out.becameMastered) r.mastered.push(pw.id);
        if (!pw.correct && !r.wrongIds.includes(pw.id)) r.wrongIds.push(pw.id);
      });
      r.answered += 1;
      let gain = null;
      if (res.correct) {
        r.correct += 1; r.streak += 1;
        let pts = 10 + (r.streak % 3 === 0 ? 5 : 0);
        if (r.mode === 'challenge' && P.timeLeft > 0) pts += Math.ceil(P.timeLeft / 2);
        S.score += pts; S.shards += 1; r.gainScore += pts; r.gainShards += 1;
        gain = { pts, streak: r.streak };
        if (q.word.season) S.lastSeason = q.word.season;
        KT.sfx.play('ok');
      } else {
        r.streak = 0;
        KT.sfx.play('bad');
        per.filter((pw) => !pw.correct).forEach((pw) => { if (KT.planner.requeue(r, r.idx, pw.id, q.type)) res.requeued = true; });
      }
      KT.store.save();
      KT.app.hud();
      KT.challenges[q.kind].reveal(root, q, res);
      KT.fx.react(U.$('.stage', root), q, res);
      KT.feedback.show(q, res, gain, assisted);
      if (res.correct) P.auto = setTimeout(() => { if (P.q === q && KT.app.screen === 'play') P.cont(); }, 1700);
    },

    cont() {
      clearTimeout(P.auto);
      if (!P.round || (P.q && !P.q.answered)) return;
      P.round.idx += 1;
      P.next();
    },

    startTimer(q) {
      const el = U.$('#play-timer');
      const base = P.round.mode === 'challenge' ? Number(KT.store.S.settings.timer) || 0 : 0;
      P.timeLeft = 0;
      if (!base) { el.hidden = true; return; }
      P.timeLeft = base * (q.kind === 'choice' ? 1 : 2);
      el.hidden = false;
      el.textContent = P.timeLeft + 's';
      el.classList.remove('low');
      P.timer = setInterval(() => {
        P.timeLeft -= 1;
        el.textContent = Math.max(0, P.timeLeft) + 's';
        el.classList.toggle('low', P.timeLeft <= 5);
        if (P.timeLeft > 0 && P.timeLeft <= 3) KT.sfx.play('tick');
        if (P.timeLeft <= 0) { P.stopTimer(); P.answer(q, { correct: false, timeout: true }); }
      }, 1000);
    },
    stopTimer() { clearInterval(P.timer); P.timer = null; },

    finish() {
      const r = P.round;
      if (r.mode !== 'review') { const z = KT.store.zone(r.zone); z.rounds += 1; z.best = Math.max(z.best || 0, r.correct); }
      r.newlyUnlocked = KT.ZONES.filter((z) => KT.learn.unlocked(z.id) && !r.unlockedBefore.includes(z.id)).map((z) => z.id);
      KT.sfx.play(r.newlyUnlocked.length ? 'unlock' : 'win');
      KT.store.save();
      KT.app.go('result', { round: r });
    },

    onKey(e) {
      if (KT.app.screen !== 'play' || U.$('.dialog-backdrop')) return;
      if ((e.key === 'Enter' || e.key === ' ') && e.target.closest && e.target.closest('button, input, a')) return;
      const fb = U.$('#play-feedback');
      if (fb && !fb.hidden) { if (e.key === 'Enter') { e.preventDefault(); P.cont(); } return; }
      const q = P.q;
      if (!q || q.answered) return;
      if (q.kind === 'choice' && /^[1-9]$/.test(e.key)) { e.preventDefault(); KT.challenges.choice.pick(U.$('#play-q'), Number(e.key) - 1); return; }
      if (KT.challenges[q.kind].key) KT.challenges[q.kind].key(U.$('#play-q'), q, e);
    },
  });

  KT.screens.play = {
    render() {
      const r = P.round, st = KT.store.S.settings;
      const title = r.mode === 'review' ? 'Ôn từ sai' : (r.mode === 'challenge' ? 'Thử thách · ' : '') + KT.zoneOf(r.zone).name;
      return '<section class="play' + (r.zone === 6 ? ' night-zone' : '') + '"><header class="play-top"><div class="play-top-in wrap">' +
        '<button class="icon-btn" data-act="quitRound" aria-label="Thoát lượt chơi">' + KT.ui.ic.close + '</button>' +
        '<div class="play-progress"><div class="play-title">' + U.esc(title) + '</div><div class="bar"><i id="play-bar"></i></div></div>' +
        '<span class="play-count tnum" id="play-count"></span><span class="play-timer tnum" id="play-timer" hidden></span>' +
        '<button class="icon-btn" data-act="toggleFuri" aria-pressed="' + st.furigana + '" aria-label="Hiện cách đọc trên chữ Hán" title="Hiện cách đọc trên chữ Hán">' + KT.ui.ic.eye + '</button>' +
        '<button class="icon-btn" data-act="toggleSound" aria-pressed="' + st.sound + '" aria-label="Âm thanh hiệu ứng" title="Âm thanh hiệu ứng">' + (st.sound ? KT.ui.ic.sound : KT.ui.ic.mute) + '</button>' +
        '</div></header><div class="play-body wrap" id="play-body"></div><div class="feedback" id="play-feedback" hidden></div></section>';
    },
    mount() { document.addEventListener('keydown', P.onKey); P.next(); },
    leave() {
      P.stopTimer(); clearTimeout(P.auto);
      document.removeEventListener('keydown', P.onKey);
      if (P.q && P.q.cleanup) P.q.cleanup();
      try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    },
  };

  KT.actions.introDone = () => { KT.sfx.play('tap'); P.ask(P.round.items[P.round.idx]); };
  KT.actions.nextQuestion = () => P.cont();
  KT.actions.quitRound = async () => {
    const v = await KT.app.dialog({
      title: 'Rời lượt chơi?',
      body: 'Các câu đã trả lời vẫn được lưu. Lượt này sẽ không được tính là hoàn thành.',
      actions: [{ label: 'Chơi tiếp', cls: 'btn-primary', value: null }, { label: 'Về bản đồ', cls: 'btn-ghost', value: 'quit' }],
    });
    if (v === 'quit') KT.app.go('map');
  };
  KT.actions.toggleSound = (el) => {
    const st = KT.store.S.settings;
    st.sound = !st.sound; KT.store.save();
    el.setAttribute('aria-pressed', st.sound);
    el.innerHTML = st.sound ? KT.ui.ic.sound : KT.ui.ic.mute;
    if (st.sound) KT.sfx.play('tap');
  };
  KT.actions.toggleFuri = (el) => {
    const st = KT.store.S.settings;
    st.furigana = !st.furigana; KT.store.save();
    el.setAttribute('aria-pressed', st.furigana);
    KT.app.applySettings();
    KT.app.toast(st.furigana ? 'Đang hiện cách đọc trên chữ Hán.' : 'Đã ẩn cách đọc trên chữ Hán.');
  };
})();