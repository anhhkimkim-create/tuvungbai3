/* Word card (shown before a new word and in the notebook), the answer feedback
   sheet, and scene reactions on the stage (restored object, petals, fireworks…). */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const canSay = (w) => KT.speech.ok() && !String(w.kana).includes('／');

  function cardHTML(w) {
    const reading = w.kana !== w.jp ? '<p class="wc-kana">Cách đọc: <span class="jp" lang="ja">' + esc(w.kana) + '</span></p>' : '';
    const notes = [w.note, KT.GROUP_NOTES[w.g]].filter(Boolean).map((n) => '<li>' + esc(n) + '</li>').join('');
    return '<div class="wc-art">' + KT.icons.forWord(w) + '</div><div class="wc-body">' +
      '<p class="eyebrow">Nhóm ' + w.g + ' · ' + esc(KT.GROUPS[w.g]) + '</p>' +
      '<div class="wc-jp">' + KT.jp.html(w, { ruby: true }) + '</div>' + reading + '<p class="wc-vi">' + esc(w.vi) + '</p>' +
      (notes ? '<ul class="wc-notes">' + notes + '</ul>' : '') +
      (canSay(w) ? '<div class="wc-tools"><button class="btn btn-ghost btn-sm" data-act="sayWord" data-arg="' + w.id + '">' + KT.ui.ic.sound + 'Nghe</button></div>' : '') +
      '</div>';
  }

  KT.wordCard = { html: cardHTML, canSay };
  KT.challenges.intro = {
    render(q) {
      return '<div class="intro"><div class="word-card card intro-card"><span class="intro-flag">Từ mới</span>' + cardHTML(q.word) +
        '<button class="btn btn-primary btn-lg btn-block" data-act="introDone">Đã xem, thử ngay' + KT.ui.ic.arrow + '</button></div>' +
        '<div class="intro-cat" aria-hidden="true">' + KT.sprites.cat('happy') + '<p class="cat-say">Nhìn kỹ cách đọc và nghĩa, rồi mình thử ngay nhé!</p></div></div>';
    },
  };

  /* ---------- feedback sheet ---------- */
  const PRAISE = ['Chính xác!', 'Đúng rồi!', 'Tuyệt!', 'Nhớ chuẩn!'];
  const wordLine = (w) => '<span class="fb-jp">' + KT.jp.html(w, { ruby: true }) + '</span>' +
    (w.kana !== w.jp ? ' <span class="fb-kana jp" lang="ja">' + esc(w.kana) + '</span>' : '') + ' <span class="fb-vi">· ' + esc(w.vi) + '</span>';

  KT.feedback = {
    show(q, res, gain, assisted) {
      const el = U.$('#play-feedback');
      const w = q.word, ok = res.correct;
      let msg;
      if (ok) {
        msg = '<p class="fb-title">' + U.pick(PRAISE) + '</p><p class="fb-word">' + wordLine(w) + '</p>' +
          '<p class="fb-gain">+' + gain.pts + ' điểm · +1 mảnh ký ức' + (gain.streak >= 3 && gain.streak % 3 === 0 ? ' · chuỗi ' + gain.streak + ' câu đúng' : '') + '</p>' +
          (assisted ? '<p class="fb-note">Câu này không tính vào “Đã nhớ” vì bạn vừa xem đáp án hoặc dùng gợi ý.</p>' : '');
      } else {
        const wrongs = res.perWord ? res.perWord.filter((x) => !x.correct).map((x) => KT.WORD[x.id]) : [w];
        msg = '<p class="fb-title">' + (res.timeout ? 'Hết giờ!' : 'Chưa đúng') + '</p>' +
          (res.built ? '<p class="fb-note">Bạn ghép: <span class="jp" lang="ja">' + esc(res.built) + '</span></p>' : '') +
          wrongs.map((x) => '<p class="fb-word">Đáp án: ' + wordLine(x) + '</p>').join('') +
          '<p class="fb-note">' + (res.requeued ? 'Từ này sẽ quay lại sau vài câu.' : 'Từ này đã vào mục Ôn từ sai.') + '</p>';
      }
      el.className = 'feedback ' + (ok ? 'is-good' : 'is-bad');
      el.innerHTML = '<div class="fb-in wrap"><div class="fb-msg" role="status">' + msg + '</div><div class="fb-actions">' +
        (canSay(w) ? '<button class="icon-btn" data-act="sayWord" data-arg="' + w.id + '" aria-label="Nghe từ ' + esc(w.kana) + '">' + KT.ui.ic.sound + '</button>' : '') +
        '<button class="btn ' + (ok ? 'btn-primary' : 'btn-accent') + ' btn-lg" data-act="nextQuestion">' + (ok ? 'Tiếp tục' : 'Đã hiểu') + '</button></div></div>';
      el.hidden = false;
      const btn = U.$('[data-act="nextQuestion"]', el);
      if (btn) btn.focus({ preventScroll: true });
    },
  };

  /* ---------- stage reactions ---------- */
  function particles(stage, kind, n) {
    const fx = U.$('.stage-fx', stage);
    if (!fx) return;
    let html = '';
    for (let i = 0; i < n; i++) {
      html += '<span class="ptc ptc-' + kind + '" style="left:' + (5 + Math.random() * 90).toFixed(1) + '%;top:' + (kind === 'z' || kind === 'note' ? 55 + Math.random() * 20 : -8 + Math.random() * 20).toFixed(1) +
        '%;--d:' + (Math.random() * 0.6).toFixed(2) + 's;--dx:' + (Math.random() * 60 - 30).toFixed(0) + 'px">' + (kind === 'z' ? 'z' : kind === 'note' ? '♪' : '') + '</span>';
    }
    fx.insertAdjacentHTML('beforeend', html);
    setTimeout(() => { fx.innerHTML = ''; }, 2800);
  }
  const KIND = { petals: 'petal', leaves: 'leaf', snow: 'snow', confetti: 'confetti', fireworks: 'fw', notes: 'note', waves: 'ripple' };

  KT.fx = {
    react(stage, q, res) {
      if (!stage) return;
      const cat = U.$('.cat', stage);
      if (cat) cat.classList.add(res.correct ? 'happy' : 'sad');
      if (!res.correct) { stage.classList.add('shake-soft'); return; }
      const orbEl = U.$('.obj-orb', stage), ic = U.$('.obj-icon', stage);
      if (orbEl) orbEl.classList.add('gone');
      if (ic) ic.classList.remove('is-hidden', 'ghost');
      stage.classList.add('restored');
      const fx = q.word.fx, calm = U.calm();
      if (fx === 'night') stage.classList.add('is-night');
      if (fx === 'sunrise') stage.classList.remove('is-night');
      if (q.word.season) { KT.stage.SEASONS.forEach((s) => stage.classList.remove('season-' + s)); stage.classList.add('season-' + q.word.season); }
      if (q.type === 'bus' || q.type === 'busRev') { const b = U.$('.stage-bus', stage); if (b) b.classList.add('drive'); }
      if (q.type === 'deliver' || q.type === 'deliverRev') { if (ic) ic.classList.add('hop'); }
      if (fx === 'clock') { const c = U.$('.obj-clock', stage); if (c) c.classList.add('spin'); }
      if (fx === 'calendar' && ic) ic.classList.add('flip');
      if (q.zone === 6) {
        const off = U.$$('.s-lantern', stage).find((l) => !l.classList.contains('on'));
        if (off) off.classList.add('on');
      }
      if (calm) return;
      particles(stage, 'spark', 8);
      if (fx === 'night') particles(stage, 'z', 3);
      else if (KIND[fx]) particles(stage, KIND[fx], fx === 'fireworks' ? 3 : 14);
      if (q.zone === 6 && fx !== 'fireworks') particles(stage, 'fw', 2);
    },
  };

  KT.actions.sayWord = (el) => {
    const w = KT.WORD[el.dataset.arg];
    if (w) KT.speech.sayWord(w, null, () => KT.app.toast('Thiết bị chưa có giọng đọc tiếng Nhật nên không phát được âm thanh.'));
  };
})();