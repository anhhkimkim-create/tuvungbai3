/* Start screen (title, illustrated city, "Bắt đầu hành trình" / "Tiếp tục")
   and the three-panel story intro. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;

  const STORY = [
    { title: 'Một cơn gió lạ', art: ['house', 'bus', 'sakura'], ghost: true,
      text: 'Đêm qua, một cơn gió lạ thổi qua thành phố Kotoba và cuốn mất tên gọi của mọi thứ: đồ vật, địa điểm, cả những việc người ta làm mỗi ngày.' },
    { title: 'Thành phố nhạt màu', art: ['clockface', 'festival', 'milk'], ghost: true,
      text: 'Không còn tên gọi, đồ vật chỉ còn lại nét viền mờ. Xe buýt đứng yên, tháp đồng hồ ngừng chạy, lễ hội tắt đèn.' },
    { title: 'Người giao thư ký ức', art: ['package'], ghost: false, cat: true,
      text: 'Bạn là người giao thư ký ức. Cùng mèo Mochi, nhớ đúng từ tiếng Nhật để trả tên cho từng vật. Mỗi từ nhớ đúng, một góc thành phố sáng lại.' },
  ];

  function summary() {
    const met = KT.WORDS.filter((w) => KT.learn.peek(w.id).in).length;
    const restored = KT.WORDS.filter((w) => KT.learn.peek(w.id).c > 0).length;
    return 'Đã gặp ' + met + '/' + KT.WORDS.length + ' từ · khôi phục ' + restored + ' vật thể · ' + KT.store.S.score + ' điểm';
  }

  KT.screens.start = {
    render() {
      const has = KT.store.S.started;
      const warn = KT.store.persistent ? '' :
        '<p class="warn">Trình duyệt đang chặn lưu trữ, nên tiến độ sẽ mất khi tải lại trang. Hãy mở game ở cửa sổ thường để lưu.</p>';
      return '<section class="start">' +
        '<div class="start-art">' + KT.cityMap.render({ cls: 'hero-map', label: 'Thành phố Kotoba, nhiều vật thể chỉ còn nét viền' }) + '</div>' +
        '<div class="start-copy">' +
        '<p class="eyebrow">Trò chơi từ vựng tiếng Nhật · Bài 3</p>' +
        '<h1 class="title"><span class="title-k">KOTOBA</span><span class="title-sub">Thành phố thất lạc ký ức</span></h1>' +
        '<p class="lede">Một cơn gió đã cuốn mất tên gọi của mọi thứ trong thành phố. Cùng mèo Mochi trả lại tên cho từng vật bằng ' +
        KT.WORDS.length + ' từ vựng trong bài học.</p>' +
        '<div class="start-actions"><button class="btn btn-accent btn-lg" data-act="startJourney">Bắt đầu hành trình</button>' +
        '<button class="btn btn-ghost btn-lg" data-act="continueJourney"' + (has ? '' : ' disabled') + '>Tiếp tục</button>' +
        '<button class="btn btn-quiet btn-lg" data-act="go" data-arg="contest">' + KT.ui.ic.trophy + 'Thi đấu cùng bạn bè</button></div>' +
        '<p class="start-meta">' + (has ? U.esc(summary()) : 'Không cần đăng nhập. Tiến độ lưu trên thiết bị này.') + '</p>' + warn +
        '</div><div class="start-cat" aria-hidden="true">' + KT.sprites.cat() + '</div></section>';
    },
  };

  KT.screens.story = {
    render(p) {
      const i = U.clamp(Number(p.i) || 0, 0, STORY.length - 1), s = STORY[i];
      const art = s.art.map((k) => '<span class="story-ic' + (s.ghost ? ' ghost' : '') + '">' + KT.icons.svg(k) + '</span>').join('') +
        (s.cat ? '<span class="story-catwrap">' + KT.sprites.cat('happy') + '</span>' : '');
      const dots = STORY.map((_, k) => '<i class="' + (k === i ? 'on' : '') + '"></i>').join('');
      return '<section class="story"><div class="story-card card">' +
        '<div class="story-art' + (s.ghost ? ' windy' : '') + '" aria-hidden="true">' + art + '</div>' +
        '<p class="eyebrow">Mở đầu · ' + (i + 1) + '/' + STORY.length + '</p><h1>' + s.title + '</h1>' +
        '<p class="story-text">' + s.text + '</p><div class="story-dots" aria-hidden="true">' + dots + '</div>' +
        '<div class="story-actions"><button class="btn btn-quiet" data-act="storySkip">Bỏ qua</button>' +
        '<button class="btn btn-primary btn-lg" data-act="storyNext" data-arg="' + i + '">' + (i < STORY.length - 1 ? 'Tiếp' : 'Vào thành phố') + '</button></div>' +
        '</div></section>';
    },
  };

  function enterCity() {
    KT.store.S.started = true;
    KT.store.save();
    KT.app.go('map', { first: true });
  }

  KT.actions.startJourney = async () => {
    KT.sfx.play('tap');
    if (!KT.store.S.started) { KT.app.go('story', { i: 0 }); return; }
    const v = await KT.app.dialog({
      title: 'Bắt đầu hành trình mới?',
      body: 'Bạn đang có tiến độ (' + summary() + '). Bắt đầu lại sẽ xóa tiến độ này, cài đặt được giữ nguyên.',
      actions: [
        { label: 'Hủy', cls: 'btn-quiet', value: null },
        { label: 'Xem lại phần mở đầu', cls: 'btn-ghost', value: 'story' },
        { label: 'Xóa và bắt đầu lại', cls: 'btn-danger', value: 'reset' },
      ],
      focus: 1,
    });
    if (v === 'story') KT.app.go('story', { i: 0 });
    if (v === 'reset') { KT.store.reset(); KT.app.go('story', { i: 0 }); }
  };
  KT.actions.continueJourney = () => { KT.sfx.play('tap'); KT.app.go('map'); };
  KT.actions.storyNext = (el) => {
    const i = Number(el.dataset.arg);
    KT.sfx.play('tap');
    if (i < STORY.length - 1) KT.app.go('story', { i: i + 1 }); else enterCity();
  };
  KT.actions.storySkip = () => enterCity();
})();