/* Thi đấu — waiting room. Host: room code, invite link (copy / share / QR code), live player
   list with "mời ra", question count, Start and Close. Player: who is here, waiting for the
   host; the race opens by itself when the host presses Start. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const X = () => KT.contest;
  let unsub = null;

  const avatar = (name) => { let h = 0; for (const ch of String(name)) h = (h * 31 + ch.codePointAt(0)) >>> 0; return 'av' + (h % 6); };
  const initial = (name) => (Array.from(String(name).trim())[0] || '?').toLocaleUpperCase('vi');
  const mySid = () => (X().me() ? X().me().sid : 0);

  function rosterHTML(list, me, canKick) {
    if (!list.length) return '<li class="ct-empty muted">Chưa có ai vào phòng. Gửi link cho mọi người nhé!</li>';
    return list.map((p) => '<li class="ct-player' + (p.sid === me ? ' is-me' : '') + '"><span class="ct-avatar ' + avatar(p.name) + '" aria-hidden="true">' +
      esc(initial(p.name)) + '</span><span class="ct-pname">' + esc(p.name) + '</span>' + (p.host ? '<span class="ct-badge">Chủ phòng</span>' : '') +
      (p.sid === me ? '<span class="ct-badge me">Bạn</span>' : '') +
      (canKick && !p.host ? '<button class="icon-btn ct-kick" data-act="ctKick" data-arg="' + p.sid + '" aria-label="Mời ' + esc(p.name) +
        ' ra khỏi phòng" title="Mời ra khỏi phòng">' + KT.ui.ic.close + '</button>' : '') + '</li>').join('');
  }
  const meta = (R) => (R.groups.length ? 'Nhóm ' + R.groups.join(', ') : 'Tất cả nhóm từ') + ' · Chống bấm bừa: ' + (R.guard ? 'bật' : 'tắt') +
    ' · Trận kết thúc khi hết giờ, hoặc 3 giây sau người về đích đầu tiên.';
  const waitMeta = (s) => (s.room ? s.room.n + ' câu · ' + KT.contestRoom.limitText(s.room.n) + ' · ' : '') +
    'Trận kết thúc khi hết giờ, hoặc 3 giây sau khi người đầu tiên làm xong.';
  const waitMsg = (s) => (s.offline ? 'Mất kết nối, đang thử kết nối lại…' : 'Bạn là <strong>' + esc(s.name) + '</strong>. Chờ chủ phòng bấm Bắt đầu nhé!');

  function hostView(R) {
    const link = X().inviteLink(R.code), list = R.roster();
    const sizes = KT.contestQuestions.SIZES.map((n) => '<button data-act="ctLobbySize" data-arg="' + n + '" aria-pressed="' + (R.n === n) + '">' + n + ' câu · ' + KT.contestRoom.limitText(n) + '</button>').join('');
    const share = link ? '<div class="ct-link"><input id="ct-link" readonly value="' + esc(link) + '" aria-label="Link mời vào phòng">' +
      '<button class="btn btn-primary" data-act="ctCopy">' + KT.ui.ic.link + 'Sao chép link</button>' +
      (navigator.share ? '<button class="btn btn-ghost" data-act="ctShare">' + KT.ui.ic.share + 'Chia sẻ</button>' : '') + '</div>' +
      '<div class="ct-qr" id="ct-qr" role="img" aria-label="Mã QR của link mời"></div>' :
      '<p class="ct-note">Game đang mở từ file trên máy nên chưa có link để gửi. Hãy đưa game lên mạng (xem HUONG-DAN-THI-DAU.md), ' +
      'hoặc cho mọi người nhập mã phòng ở mục Thi đấu của bản online.</p>';
    const relayNote = KT.net.hasRelay() ? '' : '<p class="ct-note" id="ct-relay-note">Game chưa cài máy chuyển tiếp: người chơi cần dùng <strong>chung Wi-Fi</strong> ' +
      'với máy này mới vào được. Muốn chơi khác mạng (4G, nhà khác nhau), làm theo mục “Chơi khác mạng” trong HUONG-DAN-THI-DAU.md.</p>';
    return '<section class="contest-lobby wrap"><header class="nb-head"><p class="eyebrow">Phòng chờ · bạn là chủ phòng</p><h1>' + esc(R.name) + '</h1></header>' + relayNote +
      '<div class="ct-lobby-grid"><section class="card ct-share" aria-label="Mời người chơi"><p class="eyebrow">Mã phòng</p>' +
      '<p class="ct-code" id="ct-code-big">' + esc(R.code) + '</p>' + share +
      '<p class="muted ct-small">Người chơi mở link (hoặc nhập mã ở mục Thi đấu), đặt tên là vào phòng.</p></section>' +
      '<section class="card ct-roster-card"><h2>' + KT.ui.ic.users + 'Người chơi <span class="ct-count tnum" id="ct-count">' + list.length + '</span></h2>' +
      '<ul class="ct-roster" id="ct-roster">' + rosterHTML(list, mySid(), true) + '</ul>' +
      '<div class="field"><span id="ct-ls-l">Số câu hỏi</span><div class="seg" role="group" aria-labelledby="ct-ls-l">' + sizes + '</div></div>' +
      '<p class="muted ct-small">' + esc(meta(R)) + '</p>' +
      '<div class="ct-lobby-actions"><button class="btn btn-accent btn-lg" id="ct-start" data-act="ctStart"' + (list.length ? '' : ' disabled') + '>' +
      KT.ui.ic.play + 'Bắt đầu</button><button class="btn btn-quiet" data-act="ctClose">Đóng phòng</button></div></section></div></section>';
  }

  function playerView(s) {
    return '<section class="contest-lobby wrap"><div class="card ct-wait"><div class="ct-wait-cat" aria-hidden="true">' + KT.sprites.cat('happy') + '</div>' +
      '<div class="ct-wait-text"><p class="eyebrow">Phòng ' + esc(s.code) + (s.room ? ' · ' + esc(s.room.name) : '') + '</p><h1>Đã vào phòng!</h1>' +
      '<p class="muted" id="ct-wait-msg">' + waitMsg(s) + '</p></div></div>' +
      '<section class="card ct-roster-card"><h2>' + KT.ui.ic.users + 'Người chơi <span class="ct-count tnum" id="ct-count">' + s.players.length + '</span></h2>' +
      '<ul class="ct-roster" id="ct-roster">' + rosterHTML(s.players, s.sid, false) + '</ul>' +
      '<p class="muted ct-small" id="ct-wait-meta">' + waitMeta(s) + '</p>' +
      '<div class="ct-lobby-actions"><button class="btn btn-quiet" data-act="ctLeave">Rời phòng</button></div></section></section>';
  }

  function refresh() {
    const x = X(), ul = U.$('#ct-roster');
    if (!ul) return;
    if (x.role === 'host' && x.room) {
      const list = x.room.roster();
      ul.innerHTML = rosterHTML(list, mySid(), true);
      U.$('#ct-count').textContent = list.length;
      const b = U.$('#ct-start');
      if (b) b.disabled = !list.length;
      U.$$('[data-act="ctLobbySize"]').forEach((btn) => btn.setAttribute('aria-pressed', String(Number(btn.dataset.arg) === x.room.n)));
    } else if (x.me()) {
      const s = x.me();
      ul.innerHTML = rosterHTML(s.players, s.sid, false);
      U.$('#ct-count').textContent = s.players.length;
      U.$('#ct-wait-msg').innerHTML = waitMsg(s);
      U.$('#ct-wait-meta').textContent = waitMeta(s);
    }
  }

  function drawQR() {
    const box = U.$('#ct-qr'), x = X();
    if (!box || !x.room) return;
    const link = x.inviteLink(x.room.code);
    KT.net.loadVendor('qrcode.min.js', 'QRCode').then((QR) => {
      if (!document.body.contains(box)) return;
      box.innerHTML = '';
      new QR(box, { text: link, width: 168, height: 168, colorDark: '#1F2350', colorLight: '#FFFFFF', correctLevel: QR.CorrectLevel.M });
      box.removeAttribute('title');
    }).catch(() => box.remove());
  }

  KT.screens.contestLobby = {
    render() {
      const x = X();
      if (x.role === 'host' && x.room) return hostView(x.room);
      const s = x.me();
      if (!s || !x.role) {
        return '<section class="contest wrap"><p class="muted">Bạn chưa ở trong phòng nào.</p><div><button class="btn btn-primary" data-act="go" data-arg="contest">Về Thi đấu</button></div></section>';
      }
      return playerView(s);
    },
    mount() {
      unsub = X().sub((k) => { if (/^(host:(roster|settings)|client:(lobby|welcome|offline))$/.test(k)) refresh(); });
      drawQR();
    },
    leave() { if (unsub) unsub(); unsub = null; },
  };

  KT.actions.ctStart = () => {
    const R = X().room;
    if (!R) return;
    if (!R.start()) { KT.app.toast('Chưa có người chơi nào trong phòng.'); return; }
    KT.sfx.play('tap');
  };
  KT.actions.ctLobbySize = (el) => { const R = X().room; if (R && R.setSize(Number(el.dataset.arg))) refresh(); };
  KT.actions.ctKick = async (el) => {
    const R = X().room;
    const p = R && R.roster().find((x) => x.sid === Number(el.dataset.arg));
    if (!p) return;
    const v = await KT.app.dialog({ title: 'Mời ' + p.name + ' ra khỏi phòng?', body: 'Thiết bị này sẽ không vào lại được phòng này nữa.',
      actions: [{ label: 'Hủy', cls: 'btn-primary', value: null }, { label: 'Mời ra', cls: 'btn-danger', value: 'kick' }] });
    if (v === 'kick' && X().room === R) R.kick(p.sid);
  };
  KT.actions.ctCopy = async () => {
    const input = U.$('#ct-link');
    if (!input) return;
    let done = false;
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(input.value); done = true; } } catch (e) { /* fall back below */ }
    if (!done) { input.select(); try { done = document.execCommand('copy'); } catch (e) { done = false; } }
    KT.app.toast(done ? 'Đã sao chép link mời. Dán vào Zalo, Messenger… để gửi mọi người.' : 'Chưa sao chép được, hãy chọn link rồi sao chép thủ công.');
  };
  KT.actions.ctShare = () => {
    const R = X().room;
    if (!R || !navigator.share) return;
    navigator.share({ title: 'KOTOBA · ' + R.name, text: 'Vào thi từ vựng Bài 3 với mình! Mã phòng ' + R.code, url: X().inviteLink(R.code) }).catch(() => {});
  };
  KT.actions.ctClose = async () => {
    const v = await KT.app.dialog({ title: 'Đóng phòng?', body: 'Mọi người trong phòng sẽ bị ngắt kết nối. Kết quả trận vừa rồi vẫn nằm trong mục “Trận gần đây” của từng người.',
      actions: [{ label: 'Hủy', cls: 'btn-primary', value: null }, { label: 'Đóng phòng', cls: 'btn-danger', value: 'close' }] });
    if (v !== 'close') return;
    X().leaveRoom();
    KT.app.toast('Đã đóng phòng.');
    KT.app.go('contest');
  };
  KT.actions.ctLeave = async () => {
    const v = await KT.app.dialog({ title: 'Rời phòng?', body: 'Bạn có thể vào lại bằng link mời khi trận chưa bắt đầu.',
      actions: [{ label: 'Ở lại', cls: 'btn-primary', value: null }, { label: 'Rời phòng', cls: 'btn-danger', value: 'leave' }] });
    if (v !== 'leave') return;
    X().leaveRoom();
    KT.app.go('contest');
  };
})();