/* City map screen: isometric map with zone pins, the selected zone's panel
   (mission, progress, Explore / Challenge buttons) and a compact zone list. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;

  function defaultZone() {
    const last = Number(KT.store.S.lastZone);
    if (last && KT.learn.unlocked(last)) return last;
    let best = 1;
    KT.ZONES.forEach((z) => { if (KT.learn.unlocked(z.id) && KT.learn.zoneStats(z.id).met < z.order.length) best = Math.max(best, z.id); });
    return best;
  }

  function canChallenge(zid) {
    return (zid === 6 ? KT.learn.metWords().length : KT.learn.zoneStats(zid).met) >= 4;
  }

  function pin(z, sel) {
    const pos = KT.cityMap.pinPos(z), locked = !KT.learn.unlocked(z.id);
    return '<button class="pin' + (locked ? ' locked' : '') + (z.id === sel ? ' is-sel' : '') + '" style="left:' + pos.left.toFixed(2) +
      '%;top:' + pos.top.toFixed(2) + '%" data-act="selectZone" data-arg="' + z.id + '" aria-label="Khu ' + z.id + ': ' + z.name +
      (locked ? ' (đang khóa)' : '') + '"><span class="pin-n">' + (locked ? KT.ui.ic.lock : z.id) + '</span><span class="pin-name">' + z.name + '</span></button>';
  }

  function row(z, sel) {
    const st = KT.learn.zoneStats(z.id), locked = !KT.learn.unlocked(z.id);
    return '<li><button class="zone-row' + (z.id === sel ? ' is-sel' : '') + (locked ? ' locked' : '') + '" data-act="selectZone" data-arg="' + z.id + '">' +
      '<span class="zr-n">' + (locked ? KT.ui.ic.lock : z.id) + '</span><span class="zr-main"><span class="zr-name">' + z.name + '</span>' +
      '<span class="bar coral"><i style="--p:' + st.pct + '%"></i></span></span><span class="zr-pct tnum">' + st.pct + '%</span></button></li>';
  }

  function panel(zid) {
    const z = KT.zoneOf(zid), st = KT.learn.zoneStats(zid), locked = !KT.learn.unlocked(zid);
    const rounds = (KT.store.S.zones[zid] || { rounds: 0 }).rounds;
    let body;
    if (locked) {
      const prev = KT.zoneOf(zid - 1), done = Math.min((KT.store.S.zones[zid - 1] || { rounds: 0 }).rounds, KT.UNLOCK_ROUNDS);
      body = '<div class="zp-lock">' + KT.ui.ic.lock + '<p>Hoàn thành ' + KT.UNLOCK_ROUNDS + ' lượt ở <strong>' + prev.name +
        '</strong> để mở khu này (' + done + '/' + KT.UNLOCK_ROUNDS + ').</p></div>';
    } else {
      const ch = canChallenge(zid);
      body = '<div class="zp-actions"><button class="btn btn-accent btn-lg btn-block" data-act="playZone" data-arg="' + zid + '">' +
        KT.ui.ic.play + 'Khám phá: lượt mới</button><button class="btn btn-ghost btn-block" data-act="challengeZone" data-arg="' + zid + '"' +
        (ch ? '' : ' disabled') + '>' + KT.ui.ic.timer + 'Thử thách tính giờ</button></div>' +
        '<p class="zp-note">' + (ch ? 'Thử thách chỉ dùng các từ bạn đã gặp.' : 'Gặp ít nhất 4 từ để mở chế độ Thử thách.') +
        ' Mỗi lượt 8–10 câu, khoảng 3–5 phút. Đã chơi ' + rounds + ' lượt.</p>';
    }
    return '<div class="zp card"><div class="zp-top"><span class="zp-badge zb' + zid + '">' + zid + '</span><div><p class="eyebrow">Khu ' + zid +
      '</p><h2>' + z.name + '</h2></div></div><p class="zp-mission">' + z.mission + '</p><p class="muted zp-topic">' + z.topic + '</p>' +
      '<div class="zp-progress"><div class="bar coral"><i style="--p:' + st.pct + '%"></i></div><span class="tnum">Khôi phục ' + st.pct + '%</span></div>' +
      '<p class="zp-counts tnum">Đã gặp ' + st.met + '/' + st.total + ' từ · Đã nhớ ' + st.mastered + ' · Cần ôn ' + st.review + '</p>' + body + '</div>';
  }

  function catSpot(zid) {
    const p = KT.cityMap.pinPos(KT.zoneOf(zid));
    return 'left:' + U.clamp(p.left + 5, 4, 92).toFixed(2) + '%;top:' + U.clamp(p.top + 4, 4, 90).toFixed(2) + '%';
  }

  function select(zid) {
    KT.store.S.lastZone = zid;
    const pnl = U.$('#zone-panel');
    if (!pnl) return;
    pnl.innerHTML = panel(zid);
    U.$$('.pin, .zone-row').forEach((b) => b.classList.toggle('is-sel', Number(b.dataset.arg) === zid));
    const cat = U.$('.map-cat');
    if (cat) cat.setAttribute('style', catSpot(zid));
    KT.sfx.play('tap');
    if (window.matchMedia('(max-width: 899px)').matches) pnl.scrollIntoView({ behavior: U.calm() ? 'auto' : 'smooth', block: 'nearest' });
  }

  KT.screens.map = {
    render() {
      const sel = defaultZone();
      const restored = KT.WORDS.filter((w) => KT.learn.peek(w.id).c > 0).length;
      return '<section class="map-screen wrap"><header class="map-head"><p class="eyebrow">Bản đồ thành phố</p>' +
        '<h1>Thành phố đã sáng lại <span class="tnum">' + U.pct(restored, KT.WORDS.length) + '%</span></h1>' +
        '<p class="muted">' + restored + '/' + KT.WORDS.length + ' vật thể đã có lại tên. Vật thể chỉ còn nét viền là từ bạn chưa trả lời đúng lần nào.</p></header>' +
        '<div class="map-layout"><div class="map-box">' + KT.cityMap.render() + KT.ZONES.map((z) => pin(z, sel)).join('') +
        '<div class="map-cat" style="' + catSpot(sel) + '" aria-hidden="true">' + KT.sprites.cat() + '</div></div>' +
        '<aside class="zone-panel" id="zone-panel" aria-live="polite">' + panel(sel) + '</aside></div>' +
        '<ol class="zone-list" aria-label="Sáu khu vực">' + KT.ZONES.map((z) => row(z, sel)).join('') + '</ol></section>';
    },
    mount(root, p) {
      const svg = U.$('.map-box svg', root);
      if (svg) svg.addEventListener('click', (e) => { const g = e.target.closest('[data-zone]'); if (g) select(Number(g.dataset.zone)); });
      if (p && p.first) KT.app.toast('Chạm vào Khu 1 · Ngôi nhà thức giấc rồi chọn “Khám phá” để bắt đầu.', 5000);
    },
  };

  KT.actions.selectZone = (el) => select(Number(el.dataset.arg));
  KT.actions.playZone = (el) => {
    const zid = Number(el.dataset.arg);
    if (!KT.learn.unlocked(zid)) return;
    KT.store.S.lastZone = zid;
    KT.play.start(KT.planner.explore(zid));
  };
  KT.actions.challengeZone = (el) => {
    const zid = Number(el.dataset.arg);
    const round = KT.planner.challenge(zid);
    if (!round) { KT.app.toast('Cần gặp ít nhất 4 từ trước khi chơi Thử thách.'); return; }
    KT.store.S.lastZone = zid;
    KT.play.start(round);
  };
})();