/* Sổ tay từ vựng (all 111 entries, filters by group / learning state / search,
   word detail card) and the "Ôn từ sai" screen. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const F = { g: 'all', st: 'all', q: '' };
  const STATES = ['n', 'l', 'r', 'm'];

  function matches(w) {
    if (F.g !== 'all' && w.g !== F.g) return false;
    if (F.st !== 'all' && KT.learn.peek(w.id).st !== F.st) return false;
    if (!F.q) return true;
    const s = F.q.toLowerCase();
    return [w.jp, w.kana, w.vi, w.q || ''].concat(w.alt || []).some((x) => String(x).toLowerCase().includes(s));
  }

  function rowHTML(w) {
    const p = KT.learn.peek(w.id);
    return '<li class="nb-row"><button class="nb-main" data-act="wordDetail" data-arg="' + w.id + '"><span class="nb-ic">' + KT.icons.forWord(w) +
      '</span><span class="nb-jp">' + KT.jp.html(w) + '</span><span class="nb-vi">' + esc(w.vi) + '</span></button>' +
      '<span class="st st-' + p.st + '">' + KT.learn.STATE_LABEL[p.st] + '</span>' +
      '<span class="nb-count tnum">' + p.c + ' đúng · ' + p.w + ' sai</span>' +
      (KT.wordCard.canSay(w) ? '<button class="icon-btn nb-say" data-act="sayWord" data-arg="' + w.id + '" aria-label="Nghe ' + esc(w.kana) + '">' +
        KT.ui.ic.sound + '</button>' : '<span class="nb-say" aria-hidden="true"></span>') + '</li>';
  }

  function listHTML() {
    const list = KT.WORDS.filter(matches);
    if (!list.length) return '<p class="nb-empty muted">Không có từ nào khớp bộ lọc.</p>';
    if (F.g !== 'all') return '<ul class="nb-list">' + list.map(rowHTML).join('') + '</ul>';
    return Object.keys(KT.GROUPS).map((g) => {
      const ws = list.filter((w) => w.g === g);
      return ws.length ? '<h2 class="nb-group">Nhóm ' + g + ' · ' + esc(KT.GROUPS[g]) + ' <span class="muted tnum">' + ws.length + '</span></h2>' +
        '<ul class="nb-list">' + ws.map(rowHTML).join('') + '</ul>' : '';
    }).join('');
  }

  function chips() {
    const c = KT.learn.counts();
    return {
      g: '<button class="chip" data-act="nbGroup" data-arg="all" aria-pressed="' + (F.g === 'all') + '">Tất cả nhóm</button>' +
        Object.keys(KT.GROUPS).map((k) => '<button class="chip" data-act="nbGroup" data-arg="' + k + '" aria-pressed="' + (F.g === k) + '">' +
          k + ' · ' + esc(KT.GROUPS[k]) + '</button>').join(''),
      s: '<button class="chip" data-act="nbState" data-arg="all" aria-pressed="' + (F.st === 'all') + '">Mọi trạng thái</button>' +
        STATES.map((k) => '<button class="chip" data-act="nbState" data-arg="' + k + '" aria-pressed="' + (F.st === k) + '">' +
          KT.learn.STATE_LABEL[k] + ' <span class="n">' + c[k] + '</span></button>').join(''),
    };
  }

  function refresh(focusSel) {
    const ch = chips();
    U.$('#nb-g').innerHTML = ch.g;
    U.$('#nb-s').innerHTML = ch.s;
    U.$('#nb-list').innerHTML = listHTML();
    const f = focusSel && U.$(focusSel);
    if (f) f.focus();
  }

  KT.notebook = { rowHTML };
  KT.screens.notebook = {
    render() {
      const c = KT.learn.counts(), ch = chips();
      return '<section class="notebook wrap"><header class="nb-head"><p class="eyebrow">Sổ tay từ vựng</p><h1>' + KT.WORDS.length + ' từ trong bài</h1>' +
        '<p class="muted">Đã nhớ ' + c.m + ' · Đang học ' + c.l + ' · Cần ôn ' + c.r + ' · Chưa gặp ' + c.n + '. Chạm vào một từ để xem thẻ từ.</p></header>' +
        '<div class="nb-filters"><label class="nb-search"><span class="sr-only">Tìm từ</span><input id="nb-q" type="search" ' +
        'placeholder="Tìm chữ Nhật, cách đọc hoặc nghĩa" value="' + esc(F.q) + '" autocomplete="off"></label>' +
        '<div class="chips" role="group" aria-label="Lọc theo nhóm" id="nb-g">' + ch.g + '</div>' +
        '<div class="chips" role="group" aria-label="Lọc theo trạng thái" id="nb-s">' + ch.s + '</div></div>' +
        '<div id="nb-list">' + listHTML() + '</div></section>';
    },
    mount(root) {
      const input = U.$('#nb-q', root);
      let t = null;
      input.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { F.q = input.value.trim(); refresh(); }, 120); });
    },
  };

  KT.screens.review = {
    render() {
      const list = KT.learn.reviewWords();
      if (!list.length) {
        return '<section class="review wrap"><header class="nb-head"><p class="eyebrow">Ôn từ sai</p><h1>Không có từ nào cần ôn</h1>' +
          '<p class="muted">Từ trả lời sai sẽ nằm ở đây cho tới khi bạn trả lời đúng ở một lượt sau.</p></header>' +
          '<div class="empty card">' + KT.sprites.cat('happy') + '<p>Mochi chưa thấy từ nào bị nhầm. Hãy tiếp tục khám phá thành phố!</p>' +
          '<button class="btn btn-primary" data-act="go" data-arg="map">' + KT.ui.ic.map + 'Về bản đồ</button></div></section>';
      }
      return '<section class="review wrap"><header class="nb-head"><p class="eyebrow">Ôn từ sai</p><h1>' + list.length + ' từ cần ôn</h1>' +
        '<p class="muted">Mỗi lượt ôn tối đa 8 từ, từ hay sai được ưu tiên. Một từ rời danh sách khi bạn trả lời đúng ở một lượt sau, không tính lần trả lời ngay sau khi xem đáp án.</p>' +
        '<div><button class="btn btn-accent btn-lg" data-act="startReview">' + KT.ui.ic.review + 'Ôn ngay ' + Math.min(list.length, 8) + ' từ</button></div></header>' +
        '<ul class="nb-list">' + list.map(rowHTML).join('') + '</ul></section>';
    },
  };

  KT.actions.nbGroup = (el) => { F.g = el.dataset.arg; refresh('[data-act="nbGroup"][data-arg="' + F.g + '"]'); };
  KT.actions.nbState = (el) => { F.st = el.dataset.arg; refresh('[data-act="nbState"][data-arg="' + F.st + '"]'); };
  KT.actions.startReview = () => { const r = KT.planner.review(); if (r) KT.play.start(r); };
  KT.actions.wordDetail = (el) => {
    const w = KT.WORD[el.dataset.arg], p = KT.learn.peek(w.id);
    const fams = KT.learn.families(w.id).map((f) => KT.FAMILIES[f]).join(', ') || 'chưa có';
    KT.app.dialog({
      title: KT.jp.plain(w),
      html: '<div class="word-card in-dialog">' + KT.wordCard.html(w) + '</div><p class="wc-progress"><span class="st st-' + p.st + '">' +
        KT.learn.STATE_LABEL[p.st] + '</span> Đúng cách quãng ' + Math.min(p.cr.length, 3) + '/3 lượt · dạng: ' + esc(fams) +
        ' · tổng ' + p.c + ' đúng, ' + p.w + ' sai.</p>',
      actions: [{ label: 'Đóng', cls: 'btn-primary', value: null }],
    });
  };
})();