/* "Xưởng ghép chữ" (C): build the reading from kana tiles. Tap a tile or drag it
   into the answer bar; tap a placed tile to remove it; Hoàn tác / Xóa / Gợi ý / Kiểm tra.
   Small kana, ー and dakuten must be exact. A hint makes the answer "assisted". */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;

  KT.challenges.workshop = {
    render(q) {
      const w = q.word;
      q.ws = KT.tiles.build(w);
      q.placed = [];
      q.hints = 0;
      const hint = U.hasKanji(w.jp) || w.q || w.jp !== w.kana ? '<span class="kanji-hint">' + esc(w.jp) + '</span>' : '';
      const tiles = q.ws.tiles.map((t) => '<button class="tile jp" lang="ja" data-tile="' + t.id + '">' + esc(t.text) + '</button>').join('');
      return '<div class="challenge ch-workshop">' +
        KT.challenges.stage(q, '<span class="obj-icon ghost">' + KT.icons.forWord(w) + '</span>') +
        '<div class="q-panel"><p class="q-kicker">' + KT.FAMILIES.C + ' · ' + KT.zoneOf(q.zone).name + '</p>' +
        '<h2 class="q-title" id="q-title">Ghép các mảnh kana thành từ tiếng Nhật có nghĩa:</h2>' +
        '<div class="q-prompt"><div class="prompt-vi"><span class="tag">Nghĩa</span>' + esc(w.vi) + hint + '</div></div>' +
        '<div class="ws-answer" data-drop="answer" aria-label="Từ đang ghép" aria-live="polite"><span class="ws-empty">Chạm hoặc kéo mảnh kana vào đây</span></div>' +
        '<div class="ws-pool" role="group" aria-label="Các mảnh kana">' + tiles + '</div>' +
        '<div class="ws-tools"><button class="btn btn-ghost btn-sm" data-ws="undo">' + KT.ui.ic.undo + 'Hoàn tác</button>' +
        '<button class="btn btn-ghost btn-sm" data-ws="clear">' + KT.ui.ic.trash + 'Xóa</button>' +
        '<button class="btn btn-quiet btn-sm" data-ws="hint">' + KT.ui.ic.bulb + 'Gợi ý</button>' +
        '<button class="btn btn-primary" data-ws="check" disabled>' + KT.ui.ic.check + 'Kiểm tra</button></div></div></div>';
    },

    mount(root, q, done) {
      const ans = U.$('.ws-answer', root), pool = U.$('.ws-pool', root), checkBtn = U.$('[data-ws="check"]', root);
      const textOf = (id) => q.ws.tiles.find((t) => t.id === id).text;
      const draw = () => {
        ans.innerHTML = q.placed.length ? q.placed.map((id) => '<button class="tile placed jp" lang="ja" data-placed="' + id +
          '" aria-label="Bỏ mảnh ' + esc(textOf(id)) + '">' + esc(textOf(id)) + '</button>').join('') :
          '<span class="ws-empty">Chạm hoặc kéo mảnh kana vào đây</span>';
        U.$$('[data-tile]', pool).forEach((b) => {
          const used = q.placed.includes(b.dataset.tile);
          b.classList.toggle('used', used);
          b.disabled = used || q.answered;
        });
        checkBtn.disabled = !q.placed.length || q.answered;
      };
      const place = (id) => {
        if (q.answered || q.placed.includes(id)) return;
        q.placed.push(id); KT.sfx.play('tile'); draw();
      };
      q.check = () => {
        if (q.answered || !q.placed.length) return;
        const text = q.placed.map(textOf).join('');
        done({ correct: KT.tiles.check(q.word, text), built: text, assisted: q.hints > 0 });
      };

      let suppress = false;
      pool.addEventListener('click', (e) => {
        const b = e.target.closest('[data-tile]');
        if (!b) return;
        if (suppress) { suppress = false; return; }
        place(b.dataset.tile);
      });
      ans.addEventListener('click', (e) => {
        const b = e.target.closest('[data-placed]');
        if (!b || q.answered) return;
        q.placed = q.placed.filter((x) => x !== b.dataset.placed); draw();
      });
      root.addEventListener('click', (e) => {
        const b = e.target.closest('[data-ws]');
        if (!b || q.answered) return;
        const act = b.dataset.ws;
        if (act === 'undo') { q.placed.pop(); draw(); }
        else if (act === 'clear') { q.placed = []; draw(); }
        else if (act === 'check') q.check();
        else if (act === 'hint') {
          q.hints += 1;
          const want = q.ws.answer.slice(0, Math.min(q.hints, q.ws.answer.length));
          const free = q.ws.tiles.filter((t) => t.real);
          q.placed = want.map((txt) => { const t = free.find((x) => x.text === txt); free.splice(free.indexOf(t), 1); return t.id; });
          draw();
          KT.app.toast('Gợi ý đã đặt sẵn ' + want.length + ' mảnh đầu. Câu có gợi ý không tính vào “Đã nhớ”.');
        }
      });

      // Drag from the pool into the answer bar (pointer events; works with touch and mouse).
      let drag = null;
      pool.addEventListener('pointerdown', (e) => {
        const b = e.target.closest('[data-tile]');
        if (!b || b.disabled || q.answered) return;
        drag = { id: b.dataset.tile, x: e.clientX, y: e.clientY, el: null, src: b };
      });
      window.addEventListener('pointermove', q.onMove = (e) => {
        if (!drag) return;
        if (!drag.el && Math.hypot(e.clientX - drag.x, e.clientY - drag.y) > 8) {
          drag.el = drag.src.cloneNode(true);
          drag.el.classList.add('tile-ghost');
          document.body.appendChild(drag.el);
        }
        if (drag.el) {
          drag.el.style.left = e.clientX + 'px'; drag.el.style.top = e.clientY + 'px';
          const r = ans.getBoundingClientRect();
          ans.classList.toggle('drop-hover', e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom);
        }
      });
      window.addEventListener('pointerup', q.onUp = (e) => {
        if (!drag) return;
        if (drag.el) {
          const r = ans.getBoundingClientRect();
          if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) place(drag.id);
          drag.el.remove();
          ans.classList.remove('drop-hover');
          suppress = true;
          setTimeout(() => { suppress = false; }, 50);
        }
        drag = null;
      });
      q.cleanup = () => { window.removeEventListener('pointermove', q.onMove); window.removeEventListener('pointerup', q.onUp); };
      draw();
    },

    reveal(root, q, res) {
      U.$$('[data-tile], [data-ws], [data-placed]', root).forEach((b) => { b.disabled = true; });
      const ans = U.$('.ws-answer', root);
      ans.classList.add(res.correct ? 'is-right' : 'is-wrong');
      if (!res.correct) {
        ans.insertAdjacentHTML('afterend', '<div class="ws-solution">Đáp án: <span class="jp" lang="ja">' +
          q.ws.answer.map((t) => '<span class="tile placed solution">' + esc(t) + '</span>').join('') + '</span></div>');
      }
    },
    key(root, q, e) {
      if (e.key === 'Enter' && q.check) { e.preventDefault(); q.check(); return true; }
      if (e.key === 'Backspace' && !q.answered) { e.preventDefault(); U.$('[data-ws="undo"]', root).click(); return true; }
      return false;
    },
  };
})();