/* Settings: sound, Japanese voice status, motion, furigana, theme, challenge timer,
   unlock-all, and a confirmed progress reset. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const S = () => KT.store.S;

  const sw = (key, label, desc) => '<div class="set-row"><div class="set-text"><strong id="lbl-' + key + '">' + label + '</strong><p>' + desc + '</p></div>' +
    '<button class="switch" role="switch" aria-checked="' + !!S().settings[key] + '" aria-labelledby="lbl-' + key + '" data-act="setToggle" data-arg="' + key + '"><span></span></button></div>';
  const seg = (key, label, desc, opts) => '<div class="set-row col"><div class="set-text"><strong id="lbl-' + key + '">' + label + '</strong><p>' + desc + '</p></div>' +
    '<div class="seg" role="group" aria-labelledby="lbl-' + key + '">' + opts.map((o) => '<button data-act="setValue" data-key="' + key + '" data-arg="' + o[0] +
      '" aria-pressed="' + (String(S().settings[key]) === String(o[0])) + '">' + o[1] + '</button>').join('') + '</div></div>';

  function voiceRow() {
    const ok = KT.speech.ok();
    const desc = ok ? 'Đang dùng giọng: ' + esc(KT.speech.name()) + '. Âm thanh chỉ phát khi bạn bấm nút.' :
      KT.speech.supported ? 'Thiết bị chưa có giọng tiếng Nhật. Thử thách nghe được thay bằng thử thách nhìn chữ và game vẫn hoàn thành được. Muốn nghe phát âm, hãy cài giọng tiếng Nhật trong phần ngôn ngữ của máy rồi tải lại trang.' :
        'Trình duyệt này không hỗ trợ đọc văn bản. Thử thách nghe được thay bằng thử thách nhìn chữ.';
    return '<div class="set-row"><div class="set-text"><strong>Giọng đọc tiếng Nhật</strong><p>' + desc + '</p></div>' +
      (ok ? '<button class="btn btn-ghost btn-sm" data-act="testVoice">' + KT.ui.ic.sound + 'Nghe thử</button>' : '<span class="st st-n">Không có</span>') + '</div>';
  }

  KT.screens.settings = {
    render() {
      return '<section class="settings wrap"><header class="nb-head"><p class="eyebrow">Cài đặt</p><h1>Tùy chỉnh trò chơi</h1></header>' +
        '<div class="card set-list">' + sw('sound', 'Âm thanh hiệu ứng', 'Tiếng chuông nhỏ khi trả lời đúng hoặc sai.') + voiceRow() +
        seg('motion', 'Chuyển động', 'Giảm chuyển động sẽ tắt hiệu ứng hoa rơi, pháo hoa, xe chạy.', [['auto', 'Theo thiết bị'], ['reduce', 'Giảm'], ['full', 'Đầy đủ']]) +
        sw('furigana', 'Hiện cách đọc trên chữ Hán', 'Kana nhỏ phía trên chữ Hán. Câu hỏi kiểm tra cách đọc luôn ẩn phần này cho tới khi bạn trả lời.') +
        seg('theme', 'Giao diện', 'Ban ngày nền kem, ban đêm xanh tím đậm.', [['auto', 'Theo thiết bị'], ['light', 'Ban ngày'], ['dark', 'Ban đêm']]) +
        seg('timer', 'Đồng hồ ở chế độ Thử thách', 'Thời gian cho mỗi câu. Ghép chữ và ghép cặp được gấp đôi.', [['0', 'Tắt'], ['10', '10 giây'], ['20', '20 giây'], ['30', '30 giây']]) +
        sw('unlockAll', 'Mở tất cả khu vực', 'Dành cho người đã học bài và muốn luyện ngay một chủ đề bất kỳ.') + '</div>' +
        '<div class="card set-list danger"><div class="set-row"><div class="set-text"><strong>Đặt lại tiến độ</strong><p>Xóa điểm, mảnh ký ức, trạng thái từng từ, ' +
        'vật thể đã khôi phục và khu vực đã mở. Cài đặt được giữ nguyên.</p></div><button class="btn btn-danger" data-act="askReset">' + KT.ui.ic.trash + 'Đặt lại…</button></div></div>' +
        '<p class="muted set-foot">' + (KT.store.persistent ? 'Tiến độ được lưu tự động trên thiết bị này, không cần đăng nhập.' :
          'Trình duyệt đang chặn lưu trữ: tiến độ sẽ mất khi tải lại trang.') + '</p></section>';
    },
  };

  KT.actions.setToggle = (el) => {
    const k = el.dataset.arg;
    S().settings[k] = !S().settings[k];
    KT.store.save();
    KT.app.applySettings();
    el.setAttribute('aria-checked', S().settings[k]);
    if (k === 'sound' && S().settings.sound) KT.sfx.play('tap');
  };
  KT.actions.setValue = (el) => {
    const k = el.dataset.key, v = k === 'timer' ? Number(el.dataset.arg) : el.dataset.arg;
    S().settings[k] = v;
    KT.store.save();
    KT.app.applySettings();
    U.$$('[data-key="' + k + '"]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.arg) === String(v)));
  };
  KT.actions.testVoice = () => KT.speech.say('さくら', null, () => KT.app.toast('Không phát được giọng đọc trên thiết bị này.'));
  KT.actions.askReset = async () => {
    const v = await KT.app.dialog({
      title: 'Đặt lại toàn bộ tiến độ?',
      body: 'Mọi từ trở về “Chưa gặp”, thành phố trở lại nét viền và chỉ còn Khu 1 được mở. Không thể hoàn tác.',
      actions: [{ label: 'Hủy', cls: 'btn-primary', value: null }, { label: 'Xóa tiến độ', cls: 'btn-danger', value: 'reset' }],
    });
    if (v !== 'reset') return;
    KT.store.reset();
    KT.app.applySettings();
    KT.app.toast('Đã đặt lại tiến độ.');
    KT.app.go('start');
  };
  KT.on('voices', () => { if (KT.app.screen === 'settings') KT.app.refresh(); });
})();