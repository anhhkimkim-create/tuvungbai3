/* "Ghép cặp" (F): match 4 Vietnamese meanings with 4 Japanese words
   (weekdays, o'clock readings, or any pool). Tap one card on each side.
   A word whose first pick was wrong counts as a mistake for that word. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;

  const leftLabel = (w) => (w.k === 'hour' ? '<span class="m-clock">' + KT.icons.clock(w.h, 0) + '</span>' : '') + '<span>' + esc(w.vi) + '</span>';
  const rightLabel = (w) => (w.k === 'hour' || w.k === 'minute' ? '<span class="jp" lang="ja">' + esc(w.kana) + '</span>' : KT.jp.html(w, { quiz: true }));

  KT.challenges.match = {
    render(q) {
      q.set = [q.word].concat((q.item.mates || []).map((id) => KT.WORD[id]));
      q.mistakes = {};
      q.matched = {};
      const L = U.shuffle(q.set), R = U.shuffle(q.set);
      const col = (list, side, fn) => '<div class="match-col" data-side="' + side + '">' + list.map((w) =>
        '<button class="m-card side-' + side + '" data-side="' + side + '" data-id="' + w.id + '">' + fn(w) + '</button>').join('') + '</div>';
      return '<div class="challenge ch-match">' +
        KT.challenges.stage(q, '<span class="obj-icon">' + KT.icons.svg(q.zone === 4 ? 'clockface' : 'festival') + '</span>') +
        '<div class="q-panel"><p class="q-kicker">' + KT.FAMILIES.F + ' · ' + KT.zoneOf(q.zone).name + '</p>' +
        '<h2 class="q-title" id="q-title">Ghép mỗi nghĩa tiếng Việt với từ tiếng Nhật đúng.</h2>' +
        '<div class="match-grid" role="group" aria-labelledby="q-title">' + col(L, 'L', leftLabel) + col(R, 'R', rightLabel) + '</div>' +
        '<p class="match-note muted">Chọn một thẻ bên trái rồi một thẻ bên phải.</p></div></div>';
    },

    mount(root, q, done) {
      let sel = null;
      const grid = U.$('.match-grid', root);
      grid.addEventListener('click', (e) => {
        const b = e.target.closest('.m-card');
        if (!b || b.disabled || q.answered) return;
        if (!sel || sel.dataset.side === b.dataset.side) {
          if (sel) sel.classList.remove('is-sel');
          sel = b; b.classList.add('is-sel'); KT.sfx.play('tap');
          return;
        }
        const a = sel; sel = null; a.classList.remove('is-sel');
        if (a.dataset.id === b.dataset.id) {
          [a, b].forEach((x) => { x.classList.add('is-matched'); x.disabled = true; });
          q.matched[a.dataset.id] = true;
          KT.sfx.play('ok');
          if (Object.keys(q.matched).length === q.set.length) {
            const perWord = q.set.map((w) => ({ id: w.id, correct: !q.mistakes[w.id] }));
            done({ correct: perWord.every((x) => x.correct), perWord });
          }
        } else {
          q.mistakes[a.dataset.id] = true;
          KT.sfx.play('bad');
          [a, b].forEach((x) => { x.classList.remove('shake'); void x.offsetWidth; x.classList.add('shake'); });
        }
      });
    },

    reveal(root) { U.$$('.m-card', root).forEach((b) => { b.disabled = true; }); },
    key() { return false; },
  };
})();