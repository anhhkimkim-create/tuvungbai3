/* Thi đấu — hub (create a room, join with a code, Mochi's ranking rules, this device's recent
   matches) and the join screen that an invite link opens (?phong=CODE). */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const X = () => KT.contest;
  const NET_HELP = 'Không kết nối được tới chủ phòng. Mạng có thể đang chặn kết nối trực tiếp: thử đổi Wi-Fi hoặc 4G rồi vào lại.';
  const ERR = {
    'name-empty': 'Hãy nhập tên để mọi người nhận ra bạn.',
    'name-taken': 'Tên này đã có người dùng trong phòng. Thêm họ hoặc một con số nhé.',
    'not-found': 'Không tìm thấy phòng này. Kiểm tra lại mã, hoặc chủ phòng đã đóng trang.',
    started: 'Trận đang diễn ra. Chờ ván sau rồi vào lại nhé.',
    full: 'Phòng đã đủ người.',
    kicked: 'Chủ phòng đã mời bạn ra khỏi phòng này.',
    timeout: NET_HELP,
    connect: NET_HELP,
    network: 'Không kết nối được máy chủ ghép phòng. Kiểm tra mạng rồi thử lại.',
    load: 'Không tải được phần kết nối của game. Tải lại trang rồi thử lại.',
    browser: 'Trình duyệt này không hỗ trợ thi đấu trực tuyến. Hãy dùng Chrome, Edge, Safari hoặc Firefox bản mới.',
    norelay: 'Không nối được tới chủ phòng. Có lẽ bạn đang dùng mạng khác với chủ phòng: game chưa cài máy chuyển tiếp nên hiện chỉ chơi được ' +
      'khi dùng chung Wi-Fi với chủ phòng. Hãy vào cùng Wi-Fi rồi thử lại.',
  };
  function errText(e) {
    const c = (e && e.code) || 'network';
    let t = (c === 'timeout' || c === 'connect') && !KT.net.hasRelay() ? ERR.norelay : ERR[c] || ERR.network;
    if (/^(network|load|timeout)$/.test(c) && window.claude) {
      t += ' Nếu bạn đang mở game trong claude.ai: phần thi đấu cần mở từ trang riêng của game (xem HUONG-DAN-THI-DAU.md).';
    }
    return t;
  }

  /* ---------- create-room form state (remembered on this device) ---------- */
  let F = null;
  function form() {
    if (!F) {
      const p = X().prefs;
      F = { n: KT.contestQuestions.SIZES.includes(p.n) ? p.n : 15, groups: Array.isArray(p.groups) ? p.groups.filter((g) => KT.GROUPS[g]) : [],
        plays: p.plays !== false, guard: p.guard !== false };
    }
    return F;
  }
  const sw = (key, label, desc, on) => '<div class="set-row"><div class="set-text"><strong id="ctl-' + key + '">' + label + '</strong><p>' + desc + '</p></div>' +
    '<button class="switch" role="switch" aria-checked="' + on + '" aria-labelledby="ctl-' + key + '" data-act="ctToggle" data-arg="' + key + '"><span></span></button></div>';
  const groupChips = () => '<button class="chip" data-act="ctGroup" data-arg="all" aria-pressed="' + !form().groups.length + '">Tất cả</button>' +
    Object.keys(KT.GROUPS).map((g) => '<button class="chip" data-act="ctGroup" data-arg="' + g + '" aria-pressed="' + form().groups.includes(g) + '">' +
      g + ' · ' + esc(KT.contestQuestions.shortGroup(g)) + '</button>').join('');
  const wordCount = () => KT.contestQuestions.eligible(form().groups).length + ' từ trong các nhóm đã chọn';

  function createCard() {
    const f = form(), p = X().prefs;
    const sizes = KT.contestQuestions.SIZES.map((n) => '<button data-act="ctSize" data-arg="' + n + '" aria-pressed="' + (f.n === n) + '">' + n + ' câu · ' + KT.contestRoom.limitText(n) + '</button>').join('');
    return '<section class="card ct-card" aria-labelledby="ct-create-h"><h2 id="ct-create-h">' + KT.ui.ic.trophy + 'Tạo phòng mới</h2>' +
      '<p class="muted">Bạn là chủ phòng: gửi link cho mọi người, chờ đủ người rồi bấm Bắt đầu.</p>' +
      '<label class="field"><span>Tên phòng</span><input id="ct-room" maxlength="40" autocomplete="off" placeholder="Thi từ vựng Bài 3" value="' + esc(p.roomName || '') + '"></label>' +
      '<div class="field"><span id="ct-n-l">Số câu hỏi và thời gian làm bài</span><div class="seg" role="group" aria-labelledby="ct-n-l">' + sizes + '</div></div>' +
      '<div class="field"><span id="ct-g-l">Nhóm từ</span><div class="chips" role="group" aria-labelledby="ct-g-l" id="ct-groups">' + groupChips() + '</div>' +
      '<span class="ct-hint" id="ct-wc">' + wordCount() + '</span></div>' +
      sw('plays', 'Chủ phòng cùng chơi', 'Tắt nếu bạn chỉ chiếu tiến độ của cả phòng lên màn hình lớn.', f.plays) +
      '<label class="field" id="ct-host-name-f"' + (f.plays ? '' : ' hidden') + '><span>Tên của bạn</span><input id="ct-host-name" maxlength="20" autocomplete="nickname" value="' + esc(p.name || '') + '"></label>' +
      sw('guard', 'Chống bấm bừa', 'Trận chỉ kết thúc sớm khi người về đích đầu tiên đúng ít nhất một nửa số câu.', f.guard) +
      '<button class="btn btn-accent btn-lg btn-block" data-act="ctCreate">' + KT.ui.ic.play + 'Tạo phòng</button>' +
      '<p class="ct-err" id="ct-create-err" role="alert" hidden></p></section>';
  }
  function joinCard() {
    return '<section class="card ct-card" aria-labelledby="ct-join-h"><h2 id="ct-join-h">' + KT.ui.ic.users + 'Vào phòng</h2>' +
      '<p class="muted">Nhập mã 5 ký tự chủ phòng gửi, hoặc mở thẳng link mời.</p>' +
      '<label class="field"><span>Mã phòng</span><input id="ct-code" class="ct-code-input" maxlength="5" autocomplete="off" autocapitalize="characters" spellcheck="false"></label>' +
      '<label class="field"><span>Tên của bạn</span><input id="ct-name" maxlength="20" autocomplete="nickname" value="' + esc(X().prefs.name || '') + '"></label>' +
      '<button class="btn btn-primary btn-lg btn-block" data-act="ctJoin">' + KT.ui.ic.arrow + 'Vào phòng</button>' +
      '<p class="ct-err" id="ct-join-err" role="alert" hidden></p></section>';
  }
  function rulesCard() {
    const R = KT.contestRank;
    const li = (k) => '<li><span class="ct-tier tier-' + k + '">' + R.TIERS[k].range + '</span><span class="ct-say">“' + R.sayHTML(k) + '”</span>' +
      (k === 'ga' ? '<span class="ct-mini-chicken" aria-hidden="true">' + R.CHICKEN + '</span>' : '') + '</li>';
    return '<section class="card ct-rules"><div class="ct-rules-cat" aria-hidden="true">' + KT.sprites.cat('happy') + '</div><div class="ct-rules-text">' +
      '<h2>Mochi chấm điểm</h2><ul class="ct-tiers">' + li('top') + li('mid') + li('ga') + '</ul>' +
      '<p class="muted ct-small">Ai cũng làm cùng một bộ câu hỏi. Mỗi câu đúng được 100 điểm, trả lời càng nhanh càng được thêm (tối đa +50). ' +
      'Mỗi trận có giờ: 12 giây cho mỗi câu (10 câu = 2 phút … 30 câu = 6 phút). Trận kết thúc khi hết giờ, ' +
      'hoặc 3 giây sau khi người đầu tiên làm xong tất cả các câu.</p></div></section>';
  }
  function historyCard() {
    const h = X().prefs.history || [];
    if (!h.length) return '';
    return '<section class="card ct-history"><h2>Trận gần đây trên máy này</h2><ul>' + h.map((x) => '<li><span><strong>Hạng ' + x.rank + '/' + x.total +
      '</strong> · ' + esc(x.room || x.code) + '</span><span class="muted tnum">' + Number(x.score || 0).toLocaleString('vi-VN') + ' điểm · ' +
      x.correct + '/' + x.n + ' câu đúng</span></li>').join('') + '</ul></section>';
  }
  function activeCard() {
    const x = X();
    if (!x.role) return '';
    const code = x.role === 'host' && x.room ? x.room.code : (x.me() ? x.me().code : '');
    return '<section class="card ct-active"><div><p class="eyebrow">' + (x.role === 'host' ? 'Bạn đang mở phòng' : 'Bạn đang ở trong phòng') + '</p>' +
      '<p class="ct-active-code">' + esc(code) + '</p></div><button class="btn btn-primary" data-act="ctBack">Về phòng' + KT.ui.ic.arrow + '</button></section>';
  }
  function enter(root, sel, act) {
    const el = U.$(sel, root);
    if (el) el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const b = U.$('[data-act="' + act + '"]', root); if (b && !b.disabled) b.click(); } });
  }

  KT.screens.contest = {
    render() {
      return '<section class="contest wrap"><header class="nb-head"><p class="eyebrow">Thi đấu</p><h1>Đấu trường từ vựng Bài 3</h1>' +
        '<p class="muted">Tạo phòng và gửi link cho mọi người. Ai vào thì đặt tên, chủ phòng bấm bắt đầu, cả phòng làm cùng một bộ câu hỏi. ' +
        'Chơi xong, bảng xếp hạng hiện ngay trong game.</p></header>' + activeCard() +
        '<div class="ct-grid">' + createCard() + joinCard() + '</div>' + rulesCard() + historyCard() +
        '<p class="muted ct-small">Máy của chủ phòng chính là “máy chủ” của phòng: giữ trang mở và màn hình sáng tới khi xong trận.</p></section>';
    },
    mount(root) {
      enter(root, '#ct-code', 'ctJoin'); enter(root, '#ct-name', 'ctJoin');
      enter(root, '#ct-room', 'ctCreate'); enter(root, '#ct-host-name', 'ctCreate');
      const code = U.$('#ct-code', root);
      if (code) code.addEventListener('input', () => { const v = KT.net.cleanCode(code.value); if (code.value !== v) code.value = v; });
    },
  };

  KT.screens.contestJoin = {
    render(p) {
      const code = KT.net.cleanCode(p.code);
      return '<section class="contest-join"><div class="card ct-join-box"><div class="ct-join-cat" aria-hidden="true">' + KT.sprites.cat('happy') + '</div>' +
        '<p class="eyebrow">Lời mời thi đấu · KOTOBA Bài 3</p><h1>Vào phòng <span class="ct-code-inline">' + esc(code) + '</span></h1>' +
        '<p class="muted">Đặt tên để mọi người nhận ra bạn trên bảng xếp hạng.</p>' +
        '<label class="field"><span>Tên của bạn</span><input id="ctj-name" maxlength="20" autocomplete="nickname" value="' + esc(X().prefs.name || '') + '"></label>' +
        '<button class="btn btn-accent btn-lg btn-block" data-act="ctJoinGo" data-arg="' + esc(code) + '">' + KT.ui.ic.arrow + 'Vào phòng</button>' +
        '<p class="ct-err" id="ctj-err" role="alert" hidden></p>' +
        '<button class="btn btn-quiet" data-act="go" data-arg="start">Chưa muốn thi? Khám phá thành phố</button></div></section>';
    },
    mount(root) {
      enter(root, '#ctj-name', 'ctJoinGo');
      const i = U.$('#ctj-name', root);
      if (i && !i.value) i.focus();
    },
  };

  /* ---------- actions ---------- */
  function busy(btn, on, label) {
    if (!btn) return;
    if (on) { btn.dataset.label = btn.innerHTML; btn.innerHTML = label; btn.disabled = true; }
    else { if (btn.dataset.label) btn.innerHTML = btn.dataset.label; btn.disabled = false; }
  }
  function showErr(sel, msg) { const el = U.$(sel); if (el) { el.textContent = msg; el.hidden = !msg; } }

  async function joinWith(code, name, btn, errSel) {
    showErr(errSel, '');
    if (!KT.net.validCode(code)) { showErr(errSel, 'Mã phòng gồm 5 ký tự, ví dụ K7P2Q.'); return; }
    if (!KT.contestRoom.cleanName(name)) { showErr(errSel, ERR['name-empty']); return; }
    busy(btn, true, 'Đang vào phòng…');
    try { await X().join(code, name); KT.sfx.play('unlock'); KT.app.go(X().screenFor()); }
    catch (e) { busy(btn, false); showErr(errSel, errText(e)); }
  }
  KT.actions.ctJoin = (el) => joinWith(KT.net.cleanCode(U.$('#ct-code').value), U.$('#ct-name').value, el, '#ct-join-err');
  KT.actions.ctJoinGo = (el) => joinWith(el.dataset.arg, U.$('#ctj-name').value, el, '#ctj-err');

  KT.actions.ctCreate = async (el) => {
    const f = form(), p = X().prefs;
    const roomName = U.$('#ct-room').value, name = U.$('#ct-host-name').value;
    showErr('#ct-create-err', '');
    if (f.plays && !KT.contestRoom.cleanName(name)) { showErr('#ct-create-err', 'Nhập tên của bạn (hoặc tắt “Chủ phòng cùng chơi”).'); return; }
    Object.assign(p, { roomName: roomName.trim(), n: f.n, groups: f.groups, plays: f.plays, guard: f.guard });
    if (f.plays) p.name = KT.contestRoom.cleanName(name);
    X().save();
    busy(el, true, 'Đang tạo phòng…');
    try {
      await X().create({ roomName, name, n: f.n, groups: f.groups, plays: f.plays, guard: f.guard });
      KT.sfx.play('unlock');
      KT.app.go('contestLobby');
    } catch (e) { busy(el, false); showErr('#ct-create-err', errText(e)); }
  };
  KT.actions.ctSize = (el) => {
    form().n = Number(el.dataset.arg);
    U.$$('[data-act="ctSize"]').forEach((b) => b.setAttribute('aria-pressed', String(b === el)));
  };
  KT.actions.ctGroup = (el) => {
    const f = form(), g = el.dataset.arg;
    if (g === 'all') f.groups = [];
    else f.groups = f.groups.includes(g) ? f.groups.filter((x) => x !== g) : f.groups.concat(g);
    if (f.groups.length === Object.keys(KT.GROUPS).length) f.groups = [];
    U.$('#ct-groups').innerHTML = groupChips();
    U.$('#ct-wc').textContent = wordCount();
    const again = U.$('[data-act="ctGroup"][data-arg="' + g + '"]');
    if (again) again.focus();
  };
  KT.actions.ctToggle = (el) => {
    const f = form(), k = el.dataset.arg;
    f[k] = !f[k];
    el.setAttribute('aria-checked', String(f[k]));
    if (k === 'plays') U.$('#ct-host-name-f').hidden = !f.plays;
  };
  KT.actions.ctBack = () => KT.app.go(X().screenFor());
})();