/* Round results: words just learned, words still confused, what the city got back,
   newly opened zones, and the two next steps "Ôn từ sai" / "Tiếp tục khám phá". */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const uniq = (a) => Array.from(new Set(a));
  const stillWrong = (r) => uniq(r.wrongIds).filter((id) => KT.learn.peek(id).st === 'r');

  const chip = (id) => {
    const w = KT.WORD[id];
    return '<li class="wchip"><span class="wchip-ic">' + KT.icons.forWord(w) + '</span><span class="wchip-t"><span class="wchip-jp">' +
      KT.jp.html(w) + '</span><span class="wchip-vi">' + esc(w.vi) + '</span></span></li>';
  };
  const block = (title, ids, empty) => '<section class="card res-block"><h2>' + title + '</h2>' +
    (ids.length ? '<ul class="wchips">' + ids.map(chip).join('') + '</ul>' : '<p class="muted">' + empty + '</p>') + '</section>';

  KT.screens.result = {
    render(p) {
      const r = p.round;
      if (!r) return '<section class="wrap"><p class="muted">Chưa có lượt chơi nào.</p></section>';
      const confused = stillWrong(r), restored = uniq(r.restored);
      const acc = U.pct(r.correct, r.answered);
      const place = r.mode === 'review' ? 'Ôn từ sai' : (r.mode === 'challenge' ? 'Thử thách · ' : '') + KT.zoneOf(r.zone).name;
      const title = acc >= 80 ? 'Thành phố sáng thêm một góc!' : acc >= 50 ? 'Hoàn thành lượt chơi!' : 'Xong một lượt, ôn lại chút nhé';
      let zoneBar = '';
      if (r.zone) {
        const after = KT.learn.zoneStats(r.zone).pct;
        zoneBar = '<div class="res-zone"><span>' + esc(KT.zoneOf(r.zone).name) + '</span><div class="bar coral"><i style="--p:' + after +
          '%"></i></div><span class="tnum">' + r.pctBefore + '% → ' + after + '%</span></div>';
      }
      const unlocked = (r.newlyUnlocked || []).map((id) => '<div class="unlock-banner">' + KT.ui.ic.star +
        '<span>Khu vực mới đã mở: <strong>' + esc(KT.zoneOf(id).name) + '</strong></span></div>').join('');
      const tiles = restored.map((id) => '<li title="' + esc(KT.WORD[id].vi) + '">' + KT.icons.forWord(KT.WORD[id]) +
        '<span>' + KT.jp.html(KT.WORD[id]) + '</span></li>').join('');
      const anyReview = confused.length || KT.learn.reviewWords().length;
      return '<section class="result wrap"><div class="res-hero card"><div class="res-cat" aria-hidden="true">' + KT.sprites.cat(acc >= 50 ? 'happy' : '') + '</div>' +
        '<div class="res-head"><p class="eyebrow">' + esc(place) + '</p><h1>' + title + '</h1><p class="res-score"><strong class="tnum">' + r.correct + '/' + r.answered +
        '</strong> câu đúng · <span class="tnum">+' + r.gainScore + '</span> điểm · <span class="tnum">+' + r.gainShards + '</span> mảnh ký ức</p>' +
        (r.mastered.length ? '<p class="res-master">Đã nhớ thêm: ' + uniq(r.mastered).map((id) => KT.jp.html(KT.WORD[id])).join(', ') + '</p>' : '') +
        '</div></div>' + unlocked + '<div class="res-grid">' +
        block('Từ vừa học', uniq(r.introduced), 'Lượt này chỉ ôn lại các từ đã gặp.') +
        block('Từ còn nhầm', confused, 'Không còn từ nào nhầm. Giỏi lắm!') +
        '<section class="card res-block"><h2>Thành phố vừa khôi phục</h2>' + (tiles ? '<ul class="restore-tiles">' + tiles + '</ul>' :
          '<p class="muted">Lượt này không có vật thể mới. Những vật đã sáng vẫn giữ màu.</p>') + zoneBar + '</section></div>' +
        '<div class="res-actions"><button class="btn btn-accent btn-lg" data-act="reviewWrong"' + (anyReview ? '' : ' disabled') + '>' + KT.ui.ic.review + 'Ôn từ sai</button>' +
        '<button class="btn btn-primary btn-lg" data-act="go" data-arg="map">' + KT.ui.ic.map + 'Tiếp tục khám phá</button>' +
        (r.mode !== 'review' ? '<button class="btn btn-quiet" data-act="playAgain">Chơi thêm một lượt ở khu này</button>' : '') + '</div></section>';
    },
  };

  KT.actions.reviewWrong = () => {
    const r = KT.play.round, confused = r ? stillWrong(r) : [];
    const round = KT.planner.review(confused.length ? confused : null);
    if (round) KT.play.start(round); else KT.app.toast('Không còn từ nào cần ôn.');
  };
  KT.actions.playAgain = () => {
    const r = KT.play.round;
    if (!r || !r.zone) return;
    const next = r.mode === 'challenge' ? KT.planner.challenge(r.zone) : KT.planner.explore(r.zone);
    if (next) KT.play.start(next);
  };
})();