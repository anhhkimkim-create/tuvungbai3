/* Thi đấu — the final ranking everyone in the room sees, with tier badges, then (right after)
   Mochi's comment on this player's place: top 1–5 / 6–12 / 13 and below. Host: a new match with
   the same players, or close the room. Players who stay here are pulled into the next match. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const X = () => KT.contest;
  const CR = () => KT.contestRank;
  const MOCHI_DELAY = 900;
  const SOUND = { top: 'win', mid: 'tap', ga: 'bad' };
  let timer = null;
  const fmt = (n) => Number(n || 0).toLocaleString('vi-VN');
  const clock = (ms) => { const t = Math.max(0, Math.round(ms / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };

  /** What to show: the host's own board when only watching, else this player's copy. */
  function data() {
    const x = X();
    if (x.role === 'host' && !x.plays && x.room) {
      const R = x.room;
      return { board: R.board || [], n: R.specs ? R.specs.length : R.n, reason: R.reason, by: R.ending ? R.ending.name : '', room: R.info(), mySid: 0, host: true };
    }
    const s = x.me();
    if (!s) return null;
    return { board: s.board || [], n: s.n || (s.specs ? s.specs.length : 0), reason: s.reason, by: s.by, room: s.room, mySid: s.sid, host: x.role === 'host' };
  }

  const tierChip = (k) => '<span class="ct-tier tier-' + k + '">' + (k === 'ga' ? CR().CHICKEN + CR().sayHTML('ga') : esc(CR().TIERS[k].label)) + '</span>';
  function row(r, n, mySid) {
    const me = !!mySid && r.sid === mySid;
    return '<li class="ct-row tier-' + r.tier + (me ? ' is-me' : '') + '"><span class="ct-rank r' + Math.min(r.rank, 4) + ' tnum">' + r.rank + '</span>' +
      '<span class="ct-who"><span class="ct-pname">' + esc(r.name) + '</span><span class="ct-tags">' + tierChip(r.tier) +
      (me ? '<span class="ct-badge me">Bạn</span>' : '') + (r.off ? '<span class="ct-badge off">Mất kết nối</span>' : '') + '</span></span>' +
      '<span class="ct-stat"><strong class="tnum">' + fmt(r.score) + '</strong><span class="tnum">' + r.correct + '/' + n + ' đúng · ' +
      (r.done ? clock(r.timeMs) : 'làm ' + r.answered + ' câu') + '</span></span></li>';
  }
  function reasonText(d) {
    if (d.reason === 'first') return '<strong>' + esc(d.by) + '</strong> về đích đầu tiên, trận kết thúc sau 3 giây.';
    if (d.reason === 'all') return 'Mọi người đã làm xong.';
    if (d.reason === 'host') return 'Chủ phòng đã kết thúc trận.';
    return 'Hết giờ làm bài.';
  }
  function mochi(me, d) {
    let k, say, sub;
    if (me) {
      k = me.tier; say = CR().sayHTML(k);
      sub = 'Mochi nhận xét · bạn hạng ' + me.rank + '/' + d.board.length;
    } else {
      k = 'top'; say = 'Quán quân: ' + esc(d.board[0].name) + '!';
      sub = 'Top 1–5 xuất khẩu vô tư · top 6–12 bình thường · từ hạng 13 là <span class="jp" lang="ja">とり</span> / gà';
    }
    return '<div class="ct-mochi tier-' + k + '" id="ct-mochi" data-tier="' + k + '" hidden><div class="ct-mochi-cat" aria-hidden="true">' +
      KT.sprites.cat(CR().TIERS[k].mood) + '</div><div class="ct-mochi-bubble" role="status"><p class="ct-mochi-say">' + say + '</p>' +
      '<p class="ct-mochi-sub">' + sub + '</p></div>' + (k === 'ga' ? '<div class="ct-mochi-chicken" aria-hidden="true">' + CR().CHICKEN + '</div>' : '') + '</div>';
  }

  KT.screens.contestRank = {
    render() {
      const d = data();
      if (!d || !d.board.length) {
        return '<section class="contest-rank wrap"><p class="muted">Chưa có bảng xếp hạng.</p><div><button class="btn btn-primary" data-act="go" data-arg="contest">Về Thi đấu</button></div></section>';
      }
      const me = d.mySid ? d.board.find((r) => r.sid === d.mySid) : null;
      const acts = d.host ?
        '<button class="btn btn-accent btn-lg" data-act="ctRematch">' + KT.ui.ic.play + 'Ván mới</button><button class="btn btn-quiet" data-act="ctClose">Đóng phòng</button>' +
          '<span class="muted ct-small">Ván mới giữ người chơi đang kết nối và tạo bộ câu hỏi khác.</span>' :
        '<button class="btn btn-primary btn-lg" data-act="ctLeaveToCity">' + KT.ui.ic.map + 'Về thành phố</button>' +
          '<span class="muted ct-small">Ở lại trang này để chơi ván tiếp theo khi chủ phòng mở.</span>';
      return '<section class="contest-rank wrap"><header class="card ct-rank-head"><p class="eyebrow">Bảng xếp hạng · ' + esc(d.room ? d.room.name : '') + '</p>' +
        '<h1>' + (me ? 'Bạn hạng ' + me.rank + '/' + d.board.length : 'Kết quả trận đấu') + '</h1>' +
        (me ? '<p class="ct-mine tnum">' + fmt(me.score) + ' điểm · ' + me.correct + '/' + d.n + ' câu đúng</p>' : '') +
        '<p class="muted">' + reasonText(d) + '</p></header>' + mochi(me, d) +
        '<ol class="ct-board" aria-label="Bảng xếp hạng">' + d.board.map((r) => row(r, d.n, d.mySid)).join('') + '</ol>' +
        '<div class="res-actions">' + acts + '</div></section>';
    },
    mount() {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const m = U.$('#ct-mochi');
        if (!m) return;
        m.hidden = false;
        KT.sfx.play(SOUND[m.dataset.tier] || 'tap');
      }, MOCHI_DELAY);
    },
    leave() { clearTimeout(timer); },
  };

  KT.actions.ctRematch = () => {
    const R = X().room;
    if (!R || !R.reset()) KT.app.toast('Chưa mở được ván mới.');
  };
  KT.actions.ctLeaveToCity = () => {
    X().leaveRoom();
    KT.app.go(KT.store.S.started ? 'map' : 'start');
  };
})();