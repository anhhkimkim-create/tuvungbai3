/* Single-answer challenges with a scene: A (giao hàng, xe buýt), B (khôi phục / nghĩa),
   D (đồng hồ, lịch), E (nghe) and kanji reading. Each question = stage + prompt + options. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, J = KT.jp, esc = U.esc;

  const MEANING_TITLE = {
    1: 'Cư dân quên mất từ này. Nó nghĩa là gì?',
    2: 'Mảnh giấy trên kệ hàng ghi từ này. Nó nghĩa là gì?',
    3: 'Biển báo bên đường ghi từ này. Nó nghĩa là gì?',
    4: 'Trang lịch cũ ghi từ này. Nó nghĩa là gì?',
    5: 'Tấm bảng trong công viên ghi từ này. Nó nghĩa là gì?',
    6: 'Đèn lồng ký ức ghi từ này. Chọn nghĩa đúng để thắp sáng nó.',
  };

  /** Shared scene: zone backdrop, optional actor, the object being restored, fx layer, Mochi. */
  function stage(q, objHtml, actorHtml) {
    const cls = ['stage', 'z' + q.zone];
    if (q.season) cls.push('season-' + q.season);
    if (q.night) cls.push('is-night');
    if (!U.calm()) cls.push('anim-on');
    return '<div class="' + cls.join(' ') + '">' + KT.stage.backdrop(q.zone) + (actorHtml || '') +
      '<div class="stage-object">' + (objHtml || '') + '</div><div class="stage-fx" aria-hidden="true"></div>' +
      '<div class="stage-cat" aria-hidden="true">' + KT.sprites.cat() + '</div></div>';
  }
  const actor = (bubble, variant) => '<div class="stage-actor"><div class="bubble">' + bubble + '</div><div class="actor-person">' +
    KT.sprites.person(variant) + '</div></div>';
  const objIcon = (svg, ghost) => '<span class="obj-icon' + (ghost ? ' ghost' : '') + '">' + svg + '</span>';
  const orb = (w) => '<span class="obj-orb">' + KT.icons.svg('orb') + '</span><span class="obj-icon is-hidden">' + KT.icons.forWord(w) + '</span>';

  function spec(q) {
    const w = q.word, jq = J.html(w, { quiz: true });
    const pkg = objIcon(KT.icons.svg('package'));
    switch (q.type) {
      case 'restore':
        return { title: 'Một vật thể bị mất màu. Chọn từ tiếng Nhật để khôi phục nó.', obj: objIcon(KT.icons.forWord(w), true),
          prompt: '<div class="prompt-vi"><span class="tag">Vật thể</span>' + esc(w.vi) + '</div>', lay: 'list' };
      case 'deliver':
        return { title: 'Khách đưa đơn hàng bằng tiếng Nhật. Chọn đúng món để giao.', obj: pkg, actor: actor('<span class="bubble-jp">' + jq + '</span>', q.variant), lay: 'cards' };
      case 'deliverRev':
        return { title: 'Khách nói bằng tiếng Việt. Chọn nhãn tiếng Nhật đúng để dán lên gói hàng.', obj: pkg,
          actor: actor('<span class="bubble-vi">Cho tôi: <strong>' + esc(w.vi) + '</strong></span>', q.variant), lay: 'tags' };
      case 'bus':
        return { title: 'Hành khách đưa vé ghi điểm đến. Chọn đúng bến để đưa khách tới nơi.', obj: '<span class="stage-bus">' + KT.icons.svg('bus') + '</span>',
          actor: actor('<span class="ticket">' + jq + '</span>', q.variant), lay: 'cards' };
      case 'busRev':
        return { title: 'Hành khách nói điểm đến bằng tiếng Việt. Chọn biển bến xe đúng.', obj: '<span class="stage-bus">' + KT.icons.svg('bus') + '</span>',
          actor: actor('<span class="bubble-vi">Cho tôi đến: <strong>' + esc(w.vi) + '</strong></span>', q.variant), lay: 'signs' };
      case 'clock':
        if (w.k === 'hour') {
          return { title: 'Tháp đồng hồ đang chỉ mốc giờ này. Đọc thế nào?', obj: '<span class="obj-clock">' + KT.icons.clock(w.h, 0, '', true) + '</span>',
            prompt: '<div class="prompt-time"><span class="digital tnum">' + w.h + ':00</span><span>' + esc(w.vi) + ' · mốc giờ trên đồng hồ</span></div>', lay: 'list' };
        }
        return { title: 'Chọn cách đọc đúng của số phút này.', obj: objIcon(KT.icons.forWord(w)),
          prompt: '<div class="prompt-time"><span class="digital tnum">' + w.m + '</span><span>phút</span></div>', lay: 'list' };
      case 'clockRev':
        if (w.k === 'weekday') {
          return { title: 'Trang lịch ghi tên ngày bằng tiếng Nhật. Đó là thứ mấy?', obj: objIcon(KT.icons.forWord(w), true),
            prompt: '<div class="prompt-jp">' + J.html(w) + '</div>', lay: 'list' };
        }
        return { title: w.k === 'hour' ? 'Chỉnh lại đồng hồ: chọn mặt đồng hồ đúng với cách đọc này.' : 'Chọn số phút đúng với cách đọc này.',
          obj: objIcon(KT.icons.svg(w.k === 'hour' ? 'clockface' : 'stopwatch'), true),
          prompt: '<div class="prompt-jp"><span class="jp" lang="ja">' + esc(w.kana) + '</span></div>', lay: 'cards' };
      case 'calendar':
        return { title: 'Trang lịch bị mất tên. Chọn tên ngày tiếng Nhật đúng.', obj: objIcon(KT.icons.forWord(w), true),
          prompt: '<div class="prompt-vi"><span class="tag">Lịch</span>' + esc(w.vi) + '</div>', lay: 'list' };
      case 'read':
        return { title: 'Chữ Hán này đọc thế nào?', obj: orb(w), prompt: '<div class="prompt-jp kanji">' + J.html(w, { hide: true }) + '</div>', lay: 'list' };
      case 'listen':
        return { title: 'Nghe từ tiếng Nhật rồi chọn đúng.', obj: objIcon(KT.icons.svg('speaker')), lay: 'cards',
          prompt: '<div class="listen-box"><button class="btn btn-primary btn-lg" data-listen>' + KT.ui.ic.sound + '<span>Nghe từ</span></button>' +
            '<p class="listen-note" data-listen-note>Âm thanh chỉ phát khi bạn bấm nút.</p>' +
            '<button class="btn btn-quiet btn-sm" data-show-text>' + KT.ui.ic.eye + 'Không nghe được? Xem chữ</button>' +
            '<div class="listen-text prompt-jp" hidden>' + jq + '</div></div>' };
      default:
        return { title: MEANING_TITLE[q.zone] || MEANING_TITLE[1], obj: orb(w), prompt: '<div class="prompt-jp">' + jq + '</div>', lay: 'list' };
    }
  }

  function label(w, mode) {
    if (mode === 'vi') return '<span class="opt-text">' + esc(w.vi) + '</span>';
    if (mode === 'kana') return '<span class="opt-text jp" lang="ja">' + esc(w.kana) + '</span>';
    if (mode === 'jp') return '<span class="opt-text">' + J.html(w, { quiz: true }) + '</span>';
    return '<span class="opt-pic">' + KT.icons.forWord(w) + '</span><span class="opt-cap">' + esc(w.vi) + '</span>';
  }

  KT.challenges = KT.challenges || {};
  KT.challenges.stage = stage;
  KT.challenges.choice = {
    render(q) {
      const sp = spec(q);
      const opts = q.options.map((w, i) => '<button class="opt opt-' + sp.lay + '" data-opt="' + w.id + '"><span class="opt-key" aria-hidden="true">' +
        (i + 1) + '</span>' + label(w, q.mode) + '</button>').join('');
      return '<div class="challenge ch-' + q.type + '">' + stage(q, sp.obj, sp.actor) +
        '<div class="q-panel"><p class="q-kicker">' + KT.FAMILIES[KT.TYPES[q.type].fam] + ' · ' + KT.zoneOf(q.zone).name + '</p>' +
        '<h2 class="q-title" id="q-title">' + sp.title + '</h2>' + (sp.prompt ? '<div class="q-prompt">' + sp.prompt + '</div>' : '') +
        '<div class="q-options lay-' + sp.lay + '" role="group" aria-labelledby="q-title">' + opts + '</div></div></div>';
    },
    mount(root, q, done) {
      U.$('.q-options', root).addEventListener('click', (e) => {
        const b = e.target.closest('[data-opt]');
        if (!b || q.answered) return;
        done({ correct: b.dataset.opt === q.word.id, picked: b.dataset.opt });
      });
      const listen = U.$('[data-listen]', root), note = U.$('[data-listen-note]', root), show = U.$('[data-show-text]', root);
      if (listen) {
        listen.addEventListener('click', () => {
          KT.speech.sayWord(q.word, null, () => {
            note.textContent = 'Thiết bị không phát được giọng tiếng Nhật. Bấm “Xem chữ” để chuyển sang nhìn chữ.';
            show.classList.add('btn-ghost');
          });
          listen.querySelector('span').textContent = 'Nghe lại';
        });
      }
      if (show) {
        show.addEventListener('click', () => {
          q.assisted = true; q.switched = true;
          U.$('.listen-text', root).hidden = false;
          show.hidden = true;
        });
      }
    },
    /** Mark the right / wrong options and lock them. */
    reveal(root, q, res) {
      U.$$('[data-opt]', root).forEach((b) => {
        b.disabled = true;
        if (b.dataset.opt === q.word.id) b.classList.add('is-right');
        else if (b.dataset.opt === res.picked) b.classList.add('is-wrong');
        else b.classList.add('is-dim');
      });
      const pr = U.$('.prompt-jp.kanji', root);
      if (pr) pr.innerHTML = J.html(q.word, { ruby: true });
      const lt = U.$('.listen-text', root);
      if (lt) lt.hidden = false;
    },
    pick(root, n) { const b = U.$$('[data-opt]', root)[n]; if (b && !b.disabled) b.click(); },
  };
})();