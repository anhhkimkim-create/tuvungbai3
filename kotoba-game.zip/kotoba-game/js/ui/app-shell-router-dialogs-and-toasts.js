/* App shell: navigation bars, HUD, screen router, settings application,
   accessible dialogs (no window.confirm — it is blocked in embedded viewers) and toasts. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;
  const NAV = [
    ['map', 'Bản đồ', 'map'], ['notebook', 'Sổ tay', 'book'], ['review', 'Ôn từ sai', 'review'], ['contest', 'Thi đấu', 'trophy'], ['settings', 'Cài đặt', 'gear'],
  ];
  const FULLSCREEN = { start: 1, story: 1, play: 1, contestJoin: 1, contestPlay: 1 };
  /** The "Thi đấu" tab stays highlighted on every contest screen. */
  const navFor = (name) => (/^contest/.test(name) ? 'contest' : name);

  const navButtons = (cls) => NAV.map(([id, label, icon]) =>
    '<button class="nav-btn ' + cls + '" data-act="go" data-arg="' + id + '" data-nav="' + id + '">' + KT.ui.ic[icon] +
    '<span>' + label + '</span>' + (id === 'review' ? '<span class="badge" data-badge hidden></span>' : '') + '</button>').join('');

  const app = (KT.app = {
    screen: null,
    params: null,
    renderShell() {
      U.$('#topbar').innerHTML = '<div class="topbar-in wrap"><button class="brand" data-act="go" data-arg="map" aria-label="KOTOBA, về bản đồ">' +
        '<span class="brand-mark" aria-hidden="true">K</span><span class="brand-name">KOTOBA</span></button>' +
        '<nav class="topnav" aria-label="Điều hướng chính">' + navButtons('') + '</nav><div class="hud" id="hud"></div></div>';
      U.$('#tabbar').innerHTML = navButtons('');
    },
    hud() {
      const S = KT.store.S, n = KT.learn.reviewWords().length;
      const hud = U.$('#hud');
      if (hud) {
        hud.innerHTML = '<span class="pill" title="Điểm">' + KT.ui.ic.star + '<span class="tnum">' + S.score + '</span></span>' +
          '<span class="pill shard" title="Mảnh ký ức">' + KT.ui.ic.shard + '<span class="tnum">' + S.shards + '</span><span class="pill-lbl">mảnh ký ức</span></span>';
      }
      U.$$('[data-badge]').forEach((b) => { b.textContent = n; b.hidden = !n; });
    },
    go(name, params) {
      const scr = KT.screens[name];
      if (!scr) return;
      if (this.screen && KT.screens[this.screen] && KT.screens[this.screen].leave) KT.screens[this.screen].leave();
      this.screen = name;
      this.params = params || {};
      const root = U.$('#screen');
      const full = !!FULLSCREEN[name];
      U.$('#topbar').hidden = full;
      U.$('#tabbar').hidden = full;
      root.classList.toggle('no-nav', full);
      root.dataset.screen = name;
      root.innerHTML = scr.render(this.params);
      U.$$('[data-nav]').forEach((b) => {
        if (b.dataset.nav === navFor(name)) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
      });
      this.hud();
      if (scr.mount) scr.mount(root, this.params);
      window.scrollTo(0, 0);
      try { root.focus({ preventScroll: true }); } catch (e) { root.focus(); }
    },
    refresh() { if (this.screen) this.go(this.screen, this.params); },
    applySettings() {
      const st = KT.store.S.settings, html = document.documentElement;
      if (st.theme === 'light' || st.theme === 'dark') html.setAttribute('data-theme', st.theme);
      else html.removeAttribute('data-theme');
      html.classList.toggle('motion-full', st.motion === 'full');
      html.classList.toggle('calm', U.calm());
      html.classList.toggle('no-furi', !st.furigana);
    },
    toast(msg, ms) {
      const el = document.createElement('div');
      el.className = 'toast';
      el.textContent = msg;
      U.$('#toast-root').appendChild(el);
      setTimeout(() => el.remove(), ms || 3200);
    },
    /**
     * Modal dialog. actions: [{ label, cls, value }]. Resolves with the chosen value
     * (or null on Escape / backdrop). Focus is trapped while open and restored afterwards.
     */
    dialog(opts) {
      return new Promise((resolve) => {
        const prev = document.activeElement;
        const wrap = document.createElement('div');
        wrap.className = 'dialog-backdrop';
        wrap.innerHTML = '<div class="dialog-box" role="dialog" aria-modal="true" aria-labelledby="dlg-title">' +
          '<h2 id="dlg-title">' + U.esc(opts.title) + '</h2>' + (opts.html || '<p class="muted">' + U.esc(opts.body || '') + '</p>') +
          '<div class="dialog-actions">' + (opts.actions || []).map((a, i) =>
            '<button class="btn ' + (a.cls || 'btn-ghost') + '" data-dlg="' + i + '">' + U.esc(a.label) + '</button>').join('') + '</div></div>';
        const close = (val) => {
          document.removeEventListener('keydown', onKey, true);
          wrap.remove();
          if (prev && prev.focus) { try { prev.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
          resolve(val);
        };
        const onKey = (e) => {
          if (e.key === 'Escape') { e.preventDefault(); close(null); return; }
          if (e.key !== 'Tab') return;
          const f = U.$$('button, [href], input, [tabindex]:not([tabindex="-1"])', wrap).filter((x) => !x.disabled);
          if (!f.length) return;
          const first = f[0], last = f[f.length - 1];
          if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
          else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        };
        wrap.addEventListener('click', (e) => {
          const b = e.target.closest('[data-dlg]');
          if (b) close((opts.actions[Number(b.dataset.dlg)] || {}).value);
          else if (e.target === wrap) close(null);
        });
        document.addEventListener('keydown', onKey, true);
        U.$('#dialog-root').appendChild(wrap);
        const focusBtn = U.$('[data-dlg="' + (opts.focus || 0) + '"]', wrap);
        if (focusBtn) focusBtn.focus();
        if (opts.onOpen) opts.onOpen(wrap);
      });
    },
  });

  KT.actions.go = (el) => app.go(el.dataset.arg);
  KT.on('saved', () => app.hud());
})();