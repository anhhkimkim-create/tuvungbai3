/* Thi đấu — the race. Each player answers the shared questions at their own pace, with the same
   scenes and options as the city game, a short reveal after each answer and no waiting for
   others. Once someone finishes, a banner counts down the last 3 seconds. A host who does not
   play sees everyone's live progress instead and can end the match early. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util, esc = U.esc;
  const X = () => KT.contest;
  const PAUSE_OK = 650, PAUSE_BAD = 1500;
  const st = { q: null, shownAt: 0, tick: null, next: null, unsub: null, watch: false, done: false, dirty: true, drawn: 0 };
  const clock = (ms) => { const t = Math.max(0, Math.floor(ms / 1000)); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
  const fmt = (n) => Number(n || 0).toLocaleString('vi-VN');
  const wordLine = (w) => '<span class="fb-jp">' + KT.jp.html(w, { ruby: true }) + '</span> · ' + esc(w.vi);

  function raceHTML(s) {
    return '<section class="play contest-race"><header class="play-top"><div class="play-top-in wrap">' +
      '<button class="icon-btn" data-act="ctQuitRace" aria-label="Rời trận">' + KT.ui.ic.close + '</button>' +
      '<div class="play-progress"><div class="play-title">Thi đấu · ' + esc(s.room ? s.room.name : s.code) + '</div><div class="bar"><i id="ct-bar"></i></div></div>' +
      '<span class="play-count tnum" id="ct-count">1/' + s.specs.length + '</span><span class="play-timer tnum" id="ct-clock" aria-label="Thời gian còn lại">0:00</span>' +
      '<span class="pill ct-score" title="Điểm">' + KT.ui.ic.star + '<span class="tnum" id="ct-score">' + fmt(s.score) + '</span></span></div></header>' +
      '<div class="ct-ending" id="ct-ending" role="status" hidden></div>' +
      '<div class="ct-offline" id="ct-offline" role="status" hidden>Mất kết nối, đang thử lại… Cứ làm tiếp, câu trả lời sẽ được gửi khi có mạng.</div>' +
      '<div class="play-body wrap" id="ct-body"></div><div class="ct-fb" id="ct-fb" aria-live="polite" hidden></div>' +
      '<div class="ct-count3" id="ct-count3" aria-live="assertive" hidden></div></section>';
  }
  function watchHTML(R) {
    return '<section class="contest-watch wrap"><header class="nb-head"><p class="eyebrow">Đang thi · ' + esc(R.name) + '</p><h1>Trận đấu đang diễn ra</h1>' +
      '<p class="muted">Còn <span class="tnum" id="ct-clock">0:00</span> · ' + R.specs.length + ' câu · <span class="tnum" id="ct-donecount">0</span>/' +
      '<span class="tnum" id="ct-total">' + R.players.length + '</span> người đã xong</p></header>' +
      '<div class="ct-ending" id="ct-ending" role="status" hidden></div><ol class="ct-progress" id="ct-progress"></ol>' +
      '<div class="res-actions"><button class="btn btn-danger" data-act="ctEndNow">' + KT.ui.ic.flag + 'Kết thúc trận ngay</button></div>' +
      '<div class="ct-count3" id="ct-count3" aria-live="assertive" hidden></div></section>';
  }
  const empty = () => '<section class="contest wrap"><p class="muted">Không có trận nào đang diễn ra.</p>' +
    '<div><button class="btn btn-primary" data-act="go" data-arg="contest">Về Thi đấu</button></div></section>';

  /** Rewrite a live region only when its content changes (screen readers announce every rewrite). */
  const put = (el, html) => { if (el._v !== html) { el._v = html; el.innerHTML = html; } };
  /** 3-2-1 overlay; true while the match has not started yet. */
  function countdown(startAt, now, label) {
    const el = U.$('#ct-count3');
    if (!el) return false;
    if (now < startAt) {
      el.hidden = false;
      put(el, '<div><p>' + esc(label) + '</p><strong class="tnum">' + Math.ceil((startAt - now) / 1000) + '</strong><p>Chuẩn bị…</p></div>');
      return true;
    }
    el.hidden = true;
    return false;
  }
  /** Clock = time left (red in the last 10 s) and the banner: "X đã về đích! … sau N giây", "Sắp hết giờ",
      "Hết giờ!". finishAt: 3 s after the first finisher (0 = nobody yet). Returns seconds until the end. */
  function timing(startAt, limitMs, finishAt, by, myName, now) {
    const limitAt = limitMs ? startAt + limitMs : Infinity, clk = U.$('#ct-clock'), el = U.$('#ct-ending');
    if (clk) {
      clk.textContent = limitMs ? clock(Math.max(0, limitAt - now) + 999) : clock(now - startAt);
      clk.classList.toggle('low', limitAt - now <= 10000);
    }
    const left = Math.ceil((Math.min(finishAt || Infinity, limitAt) - now) / 1000), finishing = !!finishAt && finishAt <= limitAt;
    if (!el || (!finishing && left > 10)) { if (el) el.hidden = true; return left; }
    const who = by && by === myName ? 'Bạn' : esc(by || 'Một bạn');
    el.hidden = false;
    put(el, KT.ui.ic.flag + (left <= 0 ? '<span>Hết giờ! Đang tổng kết…</span>' : finishing ? '<span><strong>' + who +
      '</strong> đã về đích! Trận kết thúc sau <strong class="tnum">' + left + '</strong> giây</span>' :
      '<span>Sắp hết giờ: còn <strong class="tnum">' + left + '</strong> giây!</span>'));
    return left;
  }
  const lock = () => U.$$('#ct-q [data-opt]').forEach((b) => { b.disabled = true; });

  function tick() {
    const s = X().me();
    if (!s || !s.specs || !U.$('#ct-body')) return;
    const now = Date.now();
    if (countdown(s.startLocal, now, s.room ? s.room.name : '')) return;
    U.$('#ct-offline').hidden = !s.offline;
    if (timing(s.startLocal, s.room ? s.room.limit : 0, s.endLocal, s.by, s.name, now) <= 0) { lock(); return; }
    if (!st.q && !st.next && !st.done) show(s);
  }

  function show(s) {
    if (s.idx >= s.specs.length) { doneView(s); return; }
    const i = s.idx, spec = s.specs[i];
    if (!KT.contestQuestions.valid(spec)) { X().client.answer('', 0); show(s); return; }   // unknown word on an old cached copy
    const q = (st.q = KT.contestQuestions.toQuestion(spec, i));
    U.$('#ct-body').innerHTML = '<div class="play-q" id="ct-q">' + KT.challenges.choice.render(q) + '</div>';
    const root = U.$('#ct-q');
    KT.challenges.choice.mount(root, q, (res) => answer(s, q, res));
    U.$('#ct-count').textContent = (i + 1) + '/' + s.specs.length;
    U.$('#ct-bar').style.setProperty('--p', U.pct(i, s.specs.length) + '%');
    if (root.getBoundingClientRect().top < 0) window.scrollTo(0, 0);
    const title = U.$('.q-title', root);
    if (title) { title.setAttribute('tabindex', '-1'); title.focus({ preventScroll: true }); }
    st.shownAt = performance.now();
  }

  function answer(s, q, res) {
    if (q.answered || st.q !== q) return;
    const out = X().client.answer(res.picked, performance.now() - st.shownAt);
    if (!out) { lock(); return; }                         // the match is already over
    q.answered = true;
    const root = U.$('#ct-q');
    KT.challenges.choice.reveal(root, q, res);
    KT.fx.react(U.$('.stage', root), q, res);
    KT.sfx.play(out.ok ? 'ok' : 'bad');
    U.$('#ct-score').textContent = fmt(s.score);
    U.$('#ct-bar').style.setProperty('--p', U.pct(s.idx, s.specs.length) + '%');
    const fb = U.$('#ct-fb');
    fb.className = 'ct-fb ' + (out.ok ? 'is-good' : 'is-bad');
    fb.innerHTML = out.ok ? '<strong>Đúng!</strong> +' + out.pts + ' điểm' : '<strong>Chưa đúng.</strong> Đáp án: ' + wordLine(q.word);
    fb.hidden = false;
    st.next = setTimeout(() => {
      st.next = null; st.q = null; fb.hidden = true;
      if (X().me() === s && KT.app.screen === 'contestPlay') show(s);
    }, out.ok ? PAUSE_OK : PAUSE_BAD);
  }

  const doneMsg = (s) => (s.endLocal ? 'Chờ một chút, bảng xếp hạng sắp hiện…' :
    s.room && s.room.guard && s.correct * 2 < s.specs.length ? 'Bạn đúng chưa tới một nửa nên trận chưa kết thúc. Chờ người khác về đích nhé.' :
      'Chờ những người khác về đích hoặc hết giờ…');
  function doneView(s) {
    st.done = true; st.q = null;
    U.$('#ct-count').textContent = s.specs.length + '/' + s.specs.length;
    U.$('#ct-bar').style.setProperty('--p', '100%');
    U.$('#ct-body').innerHTML = '<div class="card ct-done"><div class="ct-done-cat" aria-hidden="true">' + KT.sprites.cat('happy') + '</div>' +
      '<h2>Bạn đã làm xong!</h2><p class="ct-mine tnum">' + s.correct + '/' + s.specs.length + ' câu đúng · ' + fmt(s.score) + ' điểm</p>' +
      '<p class="muted" id="ct-done-msg">' + doneMsg(s) + '</p></div>';
  }

  /* ---------- host who only watches ---------- */
  function progressHTML(R) {
    const n = R.specs.length;
    return R.progress().map((p) => '<li class="ct-prow' + (p.done ? ' is-done' : '') + (p.on ? '' : ' is-off') + '"><span class="ct-pname">' + esc(p.name) + '</span>' +
      '<span class="bar mint"><i style="--p:' + U.pct(p.answered, n) + '%"></i></span><span class="ct-pstat tnum">' + p.answered + '/' + n + ' · ' + p.correct + ' đúng' +
      (p.done ? ' <span class="ct-badge done">Xong</span>' : p.on ? '' : ' <span class="ct-badge off">Mất kết nối</span>') + '</span></li>').join('');
  }
  function watchTick() {
    const R = X().room;
    if (!R || !R.specs || !U.$('#ct-progress')) return;
    const now = Date.now();
    if (st.dirty && now - st.drawn > 300) {
      st.dirty = false; st.drawn = now;
      U.$('#ct-progress').innerHTML = progressHTML(R);
      U.$('#ct-donecount').textContent = R.players.filter((p) => p.done).length;
      U.$('#ct-total').textContent = R.players.length;
    }
    if (countdown(R.startAt, now, R.name)) return;
    timing(R.startAt, R.limitMs, R.ending ? R.endAt : 0, R.ending ? R.ending.name : '', '', now);
  }

  function onChange(kind) {
    if (st.watch) { if (/^host:(progress|roster|phase)$/.test(kind)) st.dirty = true; return; }
    const s = X().me();
    if (!s || !U.$('#ct-body')) return;
    if (kind === 'client:ending') { tick(); const m = U.$('#ct-done-msg'); if (m) m.textContent = doneMsg(s); }
    if (kind === 'client:offline' || kind === 'client:welcome') U.$('#ct-offline').hidden = !s.offline;
  }
  function onKey(e) {
    if (st.watch || KT.app.screen !== 'contestPlay' || U.$('.dialog-backdrop')) return;
    if (st.q && !st.q.answered && /^[1-9]$/.test(e.key)) { e.preventDefault(); KT.challenges.choice.pick(U.$('#ct-q'), Number(e.key) - 1); }
  }

  KT.screens.contestPlay = {
    render() {
      const x = X();
      st.watch = x.role === 'host' && !x.plays;
      if (st.watch) return x.room && x.room.specs ? watchHTML(x.room) : empty();
      const s = x.me();
      return s && s.specs ? raceHTML(s) : empty();
    },
    mount() {
      Object.assign(st, { q: null, next: null, done: false, dirty: true, drawn: 0 });
      st.unsub = X().sub(onChange);
      document.addEventListener('keydown', onKey);
      const fn = st.watch ? watchTick : tick;
      st.tick = setInterval(fn, 200);
      fn();
    },
    leave() {
      clearInterval(st.tick); clearTimeout(st.next);
      Object.assign(st, { tick: null, next: null, q: null });
      if (st.unsub) st.unsub();
      st.unsub = null;
      document.removeEventListener('keydown', onKey);
    },
  };

  KT.actions.ctQuitRace = async () => {
    const x = X();
    if (x.role === 'host') {
      const v = await KT.app.dialog({ title: 'Kết thúc trận cho cả phòng?', body: 'Bạn là chủ phòng. Kết thúc bây giờ thì bảng xếp hạng tính theo số câu mỗi người đã làm.',
        actions: [{ label: 'Chơi tiếp', cls: 'btn-primary', value: null }, { label: 'Kết thúc trận', cls: 'btn-danger', value: 'end' }] });
      if (v === 'end' && x.room) x.room.endNow();
      return;
    }
    const v = await KT.app.dialog({ title: 'Rời trận?', body: 'Các câu đã làm vẫn được tính trên bảng xếp hạng, nhưng bạn không làm tiếp được.',
      actions: [{ label: 'Chơi tiếp', cls: 'btn-primary', value: null }, { label: 'Rời trận', cls: 'btn-danger', value: 'quit' }] });
    if (v === 'quit') { x.leaveRoom(); KT.app.go('contest'); }
  };
  KT.actions.ctEndNow = async () => {
    const R = X().room;
    if (!R) return;
    const v = await KT.app.dialog({ title: 'Kết thúc trận ngay?', body: 'Bảng xếp hạng sẽ tính theo số câu mỗi người đã làm tới lúc này.',
      actions: [{ label: 'Hủy', cls: 'btn-primary', value: null }, { label: 'Kết thúc', cls: 'btn-danger', value: 'end' }] });
    if (v === 'end' && X().room === R) R.endNow();
  };
})();