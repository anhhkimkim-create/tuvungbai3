/* Six map zones, the challenge-type catalogue and the content-safety rules
   (pairs that must never sit in the same single-answer question). */
(function () {
  'use strict';
  const KT = window.KT;

  /** Rounds a zone needs before the next zone opens. */
  KT.UNLOCK_ROUNDS = 2;

  /** Challenge families — "Đã nhớ" needs correct answers from at least two of them. */
  KT.FAMILIES = {
    A: 'Giao hàng ký ức', B: 'Khôi phục cảnh vật', C: 'Xưởng ghép chữ',
    D: 'Sửa tháp đồng hồ', E: 'Nghe và tìm', F: 'Ghép cặp', R: 'Đọc chữ Hán',
  };

  KT.ZONES = [
    { id: 1, name: 'Ngôi nhà thức giấc', mission: 'Khôi phục sinh hoạt của cư dân',
      topic: 'Hoạt động hằng ngày, đồ dùng, các buổi trong ngày', newPer: 3, pin: [3, 11, 4.2],
      types: { meaning: 3, restore: 2, workshop: 2, listen: 1, deliver: 1, deliverRev: 1, read: 1, match: 1 },
      order: ['okimasu', 'asa', 'asagohan', 'tabemasu', 'nomimasu', 'uchi', 'watashi', 'shinbun', 'yomimasu',
        'terebi', 'mimasu', 'yoru', 'nemasu', 'kikimasu', 'cd', 'dvd', 'intaanetto', 'shimasu',
        'mainichi', 'maiasa', 'maiban'] },
    { id: 2, name: 'Cửa hàng thất lạc', mission: 'Đọc đơn hàng, chọn đúng món và giao cho khách',
      topic: 'Đồ ăn, thức uống, mua sắm, quần áo', newPer: 3, pin: [10.3, 10.3, 3.4],
      types: { deliver: 4, deliverRev: 3, workshop: 2, listen: 1, meaning: 1, restore: 1, read: 1, match: 1 },
      order: ['konbini', 'gyuunyuu', 'chiizu', 'sarada', 'kudamono', 'kaimasu', 'okane', 'osushi', 'obentou',
        'osake', 'suupaa', 'kutsu', 'tshatsu'] },
    { id: 3, name: 'Chuyến xe ký ức', mission: 'Chọn điểm đến theo từ tiếng Nhật, đưa khách tới nơi',
      topic: 'Địa điểm, di chuyển, trường học, công việc', newPer: 3, pin: [6.3, 9.1, 2.6],
      types: { bus: 4, busRev: 3, meaning: 2, restore: 2, workshop: 2, read: 1, listen: 1, deliverRev: 1, match: 1 },
      order: ['basu', 'gakkou', 'kaisha', 'ikimasu', 'kimasu', 'kaerimasu', 'kouen', 'umi', 'benkyoushimasu',
        'eigo', 'nihongo', 'hatarakimasu', 'arubaito', 'sukejuuru', 'hoomusutei'] },
    { id: 4, name: 'Tháp đồng hồ', mission: 'Sửa lịch, ghép nhãn giờ và khôi phục đồng hồ',
      topic: 'Ngày trong tuần, mốc giờ, số phút', newPer: 4, pin: [3.5, 3.3, 8.3],
      types: { clock: 4, clockRev: 3, calendar: 4, read: 3, match: 2, workshop: 1, meaning: 1, restore: 1 },
      order: ['ji', 'ichiji', 'niji', 'sanji', 'yoji', 'getsuyoubi', 'kayoubi', 'suiyoubi', 'goji', 'rokuji',
        'shichiji', 'mokuyoubi', 'kinyoubi', 'hachiji', 'kuji', 'juuji', 'doyoubi', 'nichiyoubi', 'gozen',
        'gogo', 'fun', 'ippun', 'nifun', 'sanpun', 'yonpun', 'gofun', 'roppun', 'nanafun', 'happun',
        'kyuufun', 'juppun', 'nijuugofun', 'han', 'ima', 'jikan'] },
    { id: 5, name: 'Công viên bốn mùa', mission: 'Khôi phục cảnh vật, mỗi mùa đổi một cảnh',
      topic: 'Thiên nhiên, các mùa, hoạt động vui chơi', newPer: 3, pin: [11.4, 3.6, 2.8],
      types: { restore: 3, meaning: 2, listen: 1, workshop: 2, read: 2, deliver: 1, deliverRev: 1, match: 1 },
      order: ['hi_sun', 'tsuki', 'ki', 'mizu', 'hi_fire', 'tsuchi', 'sakura', 'haru', 'natsu', 'aki', 'fuyu',
        'ichinen', 'ohanami', 'tenisu', 'sukii', 'baabekyuu', 'paatii', 'eiga', 'gooruden'] },
    { id: 6, name: 'Lễ hội ánh sáng', mission: 'Dùng mọi từ đã học để thắp lại lễ hội',
      topic: 'Ôn tập tất cả nhóm, từ hỏi và câu cảm thán', newPer: 2, pin: [14.2, 12, 3.2], night: true,
      types: { meaning: 3, restore: 2, match: 2, listen: 1, workshop: 2, deliverRev: 1, deliver: 1, read: 1,
        bus: 1, clock: 1, clockRev: 1, calendar: 1 },
      order: ['omatsuri', 'hanabi', 'nani', 'doko', 'nanji', 'iidesune', 'hee', 'e'] },
  ];

  /* ---------- challenge types ---------- */
  const GOODS = { food: 1, item: 1, place: 1, nature: 1, season: 1, activity: 1 };
  const isClock = (w) => w.k === 'hour' || w.k === 'minute';
  KT.TYPES = {
    meaning: { fam: 'B', ok: () => true },                       // JP word -> VI meaning
    restore: { fam: 'B', ok: () => true },                       // faded object + VI -> JP word
    deliver: { fam: 'A', ok: (w) => !!GOODS[w.k] },              // JP order -> pick the item
    deliverRev: { fam: 'A', ok: (w) => !!GOODS[w.k] || w.k === 'abstract' }, // VI order -> JP label
    bus: { fam: 'A', ok: (w) => w.k === 'place' },               // JP ticket -> pick the stop
    busRev: { fam: 'A', ok: (w) => w.k === 'place' },            // VI request -> JP stop sign
    clock: { fam: 'D', ok: isClock },                            // clock / minutes -> reading
    clockRev: { fam: 'D', ok: (w) => isClock(w) || w.k === 'weekday' }, // reading -> clock / VI day
    calendar: { fam: 'D', ok: (w) => w.k === 'weekday' },        // VI weekday -> JP name
    read: { fam: 'R', ok: (w) => KT.util.hasKanji(w.jp) },       // kanji (reading hidden) -> kana
    listen: { fam: 'E', ok: (w, ctx) => !w.nl && !!(ctx && ctx.speech) },
    workshop: { fam: 'C', ok: (w) => !w.nw && Array.from(w.kana).length >= 2 },
    match: { fam: 'F', ok: (w, ctx) => !!(ctx && ctx.allowMatch) },
  };

  /* ---------- content-safety rules ---------- */
  // Pairs whose meanings overlap or that sound identical: never answer + distractor together.
  const PAIRS = [
    ['ikimasu', 'kimasu'], ['hi_fire', 'hi_sun'], ['e', 'hee'], ['iidesune', 'hee'], ['e', 'nani'],
    ['mimasu', 'ohanami'], ['sakura', 'ohanami'], ['gogo', 'yoru'], ['gozen', 'asa'],
    ['paatii', 'baabekyuu'], ['hatarakimasu', 'arubaito'], ['shimasu', 'hatarakimasu'],
    ['ji', 'nanji'], ['ji', 'jikan'],
  ];
  const EX = new Set();
  PAIRS.forEach(([a, b]) => { EX.add(a + '|' + b); EX.add(b + '|' + a); });
  KT.confusable = (a, b) => EX.has(a + '|' + b);

  /** Where to look for distractors when a pool is too small. */
  KT.POOL_FALLBACK = {
    place: ['item', 'abstract'], food: ['item'], item: ['food', 'place'], verb: [],
    nature: ['season', 'activity'], season: ['nature', 'activity'], activity: ['season', 'nature'],
    abstract: ['item', 'place'], weekday: [], time: ['question', 'abstract'], hour: [], minute: [],
    question: ['time', 'phrase'], phrase: ['question', 'time'],
  };

  /* ---------- lookups ---------- */
  KT.WORD = {};
  KT.WORDS.forEach((w) => { KT.WORD[w.id] = w; });
  KT.zoneOf = (id) => KT.ZONES.find((z) => z.id === Number(id));
  KT.zoneWords = (zid) => KT.zoneOf(zid).order.map((id) => KT.WORD[id]);
})();