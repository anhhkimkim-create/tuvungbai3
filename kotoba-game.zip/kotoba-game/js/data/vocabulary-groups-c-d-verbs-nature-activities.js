/* Vocabulary bank — groups C (verbs, kept in ます form) and D (nature, seasons, activities). */
(function () {
  'use strict';
  const KT = window.KT;
  const W = KT.defWord;

  KT.WORDS = KT.WORDS.concat([
    // ---- Nhóm C — động từ (giữ nguyên dạng ます)
    W('kaimasu', 'かいます', '', 'mua', 'C', 2, 'verb', 'buy'),
    W('kikimasu', 'ききます', '', 'nghe; hỏi', 'C', 1, 'verb', 'listen',
      { fx: 'notes', note: 'Nghĩa “nghe” hoặc “hỏi” tùy ngữ cảnh.' }),
    W('hatarakimasu', 'はたらきます', '', 'làm việc', 'C', 3, 'verb', 'work'),
    W('yomimasu', 'よみます', '', 'đọc', 'C', 1, 'verb', 'read'),
    W('nemasu', 'ねます', '', 'ngủ; đi ngủ', 'C', 1, 'verb', 'sleep', { fx: 'night' }),
    W('benkyoushimasu', 'べんきょうします', '', 'học', 'C', 3, 'verb', 'study',
      { tiles: ['べん', 'きょう', 'し', 'ます'] }),
    W('okimasu', 'おきます', '', 'thức dậy', 'C', 1, 'verb', 'wake', { fx: 'sunrise' }),
    W('ikimasu', 'いきます', '', 'đi', 'C', 3, 'verb', 'go'),
    W('kimasu', 'きます', '', 'đến', 'C', 3, 'verb', 'come'),
    W('kaerimasu', 'かえります', '', 'trở về', 'C', 3, 'verb', 'return'),
    W('nomimasu', 'のみます', '', 'uống', 'C', 1, 'verb', 'drink'),
    W('tabemasu', 'たべます', '', 'ăn', 'C', 1, 'verb', 'eat'),
    W('mimasu', 'みます', '', 'xem; nhìn; ngắm', 'C', 1, 'verb', 'see'),
    W('shimasu', 'します', '', 'làm; chơi một hoạt động', 'C', 1, 'verb', 'do'),

    // ---- Nhóm D — thiên nhiên, mùa, hoạt động
    W('tsuki', '月', 'つき', 'mặt trăng', 'D', 5, 'nature', 'moon', { fx: 'night' }),
    W('hi_fire', '火', 'ひ', 'lửa', 'D', 5, 'nature', 'fire',
      { nl: 1, note: 'Đọc giống 日 (ひ, mặt trời). Phân biệt bằng chữ Hán.' }),
    W('mizu', '水', 'みず', 'nước', 'D', 5, 'nature', 'water'),
    W('ki', '木', 'き', 'cây', 'D', 5, 'nature', 'tree', { nl: 1 }),
    W('tsuchi', '土', 'つち', 'đất', 'D', 5, 'nature', 'soil'),
    W('hi_sun', '日', 'ひ', 'mặt trời', 'D', 5, 'nature', 'sun',
      { nl: 1, fx: 'sunrise', note: 'Đọc giống 火 (ひ, lửa). Phân biệt bằng chữ Hán.' }),
    W('sakura', 'さくら', '', 'hoa anh đào', 'D', 5, 'nature', 'sakura', { fx: 'petals' }),
    W('haru', 'はる', '', 'mùa xuân', 'D', 5, 'season', 'spring', { fx: 'petals', season: 'spring' }),
    W('natsu', 'なつ', '', 'mùa hè', 'D', 5, 'season', 'summer', { fx: 'sunrise', season: 'summer' }),
    W('aki', 'あき', '', 'mùa thu', 'D', 5, 'season', 'autumn', { fx: 'leaves', season: 'autumn' }),
    W('fuyu', 'ふゆ', '', 'mùa đông', 'D', 5, 'season', 'winter', { fx: 'snow', season: 'winter' }),
    W('ichinen', 'いちねん', '', 'một năm', 'D', 5, 'abstract', 'year'),
    W('sukii', 'スキー', '', 'trượt tuyết', 'D', 5, 'activity', 'ski', { fx: 'snow' }),
    W('paatii', 'パーティー', '', 'bữa tiệc', 'D', 5, 'activity', 'party', { fx: 'confetti' }),
    W('baabekyuu', 'バーベキュー', '', 'tiệc nướng; BBQ', 'D', 5, 'activity', 'bbq'),
    W('hanabi', 'はなび', '', 'pháo hoa', 'D', 6, 'activity', 'fireworks', { fx: 'fireworks' }),
    W('ohanami', 'おはなみ', '', 'ngắm hoa anh đào', 'D', 5, 'activity', 'hanami',
      { fx: 'petals', alt: ['はなみ'], note: 'Biến thể: はなみ (không có お), cùng một từ.' }),
    W('omatsuri', 'おまつり', '', 'lễ hội', 'D', 6, 'activity', 'festival',
      { fx: 'fireworks', alt: ['まつり'], note: 'Biến thể: まつり (không có お), cùng một từ.' }),
    W('gooruden', 'ゴールデンウィーク', '', 'Tuần lễ Vàng', 'D', 5, 'abstract', 'goldenweek',
      { tiles: ['ゴール', 'デン', 'ウィー', 'ク'], note: 'Chuỗi ngày nghỉ dài đầu tháng 5 ở Nhật.' }),
    W('tenisu', 'テニス', '', 'quần vợt; tennis', 'D', 5, 'activity', 'tennis'),
    W('eiga', 'えいが', '', 'phim; điện ảnh', 'D', 5, 'activity', 'movie'),
  ]);
})();