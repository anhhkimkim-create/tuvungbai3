/* Vocabulary bank — taken ONLY from the learner's notebook photos (Bài 3).
   Entry: id, jp (display form), kana (reading), vi (meaning), g (group), z (home zone),
   k (pool used for distractors), ic (illustration key), extra flags:
   alt   accepted variants (same entry, never shown as a wrong option)
   q     form used inside quizzes (CD -> シーディー)
   rb    furigana markup "お{金|かね}"     tiles  custom kana chunks for the workshop
   nl    never used in sound-only challenges   nw  never used in the kana workshop
   fx    scene effect on success           note   extra hint shown on the word card */
(function () {
  'use strict';
  const KT = window.KT;
  KT.defWord = (id, jp, kana, vi, g, z, k, ic, x) =>
    Object.assign({ id, jp, kana: kana || jp, vi, g, z, k, ic }, x || {});
  const W = KT.defWord;

  KT.GROUPS = {
    A: 'Địa điểm, di chuyển, học tập',
    B: 'Đồ ăn, đồ uống, đồ dùng',
    C: 'Động từ',
    D: 'Thiên nhiên, mùa, hoạt động',
    E: 'Ngày trong tuần',
    F: 'Thời gian, tần suất',
    G: 'Mốc giờ',
    H: 'Đếm phút',
    I: 'Từ hỏi, cảm thán',
  };
  KT.GROUP_NOTES = {
    C: 'Động từ giữ nguyên dạng ます như trong bài.',
    G: 'Mốc giờ trên mặt đồng hồ (vd 4:00), không phải khoảng thời gian kéo dài.',
    H: 'Số phút: đọc ふん hay ぷん tùy số đứng trước.',
    I: 'Cụm từ cố định: học nghĩa, không học ngữ pháp.',
  };

  KT.WORDS = (KT.WORDS || []).concat([
    // ---- Nhóm A — địa điểm, di chuyển, học tập
    W('uchi', 'うち', '', 'nhà; nhà mình', 'A', 1, 'place', 'house'),
    W('kaisha', 'かいしゃ', '', 'công ty', 'A', 3, 'place', 'office'),
    W('gakkou', '学校', 'がっこう', 'trường học', 'A', 3, 'place', 'school'),
    W('konbini', 'コンビニ', '', 'cửa hàng tiện lợi', 'A', 2, 'place', 'konbini'),
    W('suupaa', 'スーパー', '', 'siêu thị', 'A', 2, 'place', 'supermarket'),
    W('kouen', 'こうえん', '', 'công viên', 'A', 3, 'place', 'park'),
    W('umi', 'うみ', '', 'biển', 'A', 3, 'place', 'sea', { fx: 'waves' }),
    W('basu', 'バス', '', 'xe buýt', 'A', 3, 'item', 'bus', { fx: 'bus' }),
    W('watashi', '私', 'わたし', 'tôi', 'A', 1, 'abstract', 'me'),
    W('eigo', '英語', 'えいご', 'tiếng Anh', 'A', 3, 'abstract', 'english'),
    W('nihongo', '日本語', 'にほんご', 'tiếng Nhật', 'A', 3, 'abstract', 'japanese'),
    W('sukejuuru', 'スケジュール', '', 'lịch; lịch trình; kế hoạch', 'A', 3, 'abstract', 'schedule'),
    W('arubaito', 'アルバイト', '', 'việc làm thêm', 'A', 3, 'abstract', 'parttime'),
    W('hoomusutei', 'ホームステイ', '', 'ở cùng gia đình bản xứ', 'A', 3, 'abstract', 'homestay'),

    // ---- Nhóm B — đồ ăn, đồ uống, đồ dùng
    W('gyuunyuu', 'ぎゅうにゅう', '', 'sữa bò', 'B', 2, 'food', 'milk'),
    W('kudamono', 'くだもの', '', 'trái cây', 'B', 2, 'food', 'fruit'),
    W('sarada', 'サラダ', '', 'salad', 'B', 2, 'food', 'salad'),
    W('chiizu', 'チーズ', '', 'phô mai', 'B', 2, 'food', 'cheese'),
    W('asagohan', 'あさごはん', '', 'bữa sáng', 'B', 1, 'food', 'breakfast'),
    W('osake', 'おさけ', '', 'rượu; đồ uống có cồn', 'B', 2, 'food', 'sake',
      { alt: ['さけ'], note: 'Biến thể: さけ (không có お), cùng một từ.' }),
    W('osushi', 'おすし', '', 'sushi', 'B', 2, 'food', 'sushi',
      { alt: ['すし'], note: 'Biến thể: すし (không có お), cùng một từ.' }),
    W('obentou', 'おべんとう', '', 'cơm hộp', 'B', 2, 'food', 'bento',
      { alt: ['べんとう'], note: 'Biến thể: べんとう (không có お), cùng một từ.' }),
    W('intaanetto', 'インターネット', '', 'Internet', 'B', 1, 'item', 'internet',
      { tiles: ['イン', 'ター', 'ネッ', 'ト'] }),
    W('shinbun', 'しんぶん', '', 'báo; tờ báo', 'B', 1, 'item', 'newspaper'),
    W('terebi', 'テレビ', '', 'tivi', 'B', 1, 'item', 'tv'),
    W('cd', 'CD', 'シーディー', 'đĩa CD', 'B', 1, 'item', 'cd',
      { q: 'シーディー', alt: ['CD'], note: 'Viết CD, đọc シーディー. Cùng một từ.' }),
    W('dvd', 'DVD', 'ディーブイディー', 'đĩa DVD', 'B', 1, 'item', 'dvd',
      { q: 'ディーブイディー', alt: ['DVD'], tiles: ['ディー', 'ブイ', 'ディー'], note: 'Viết DVD, đọc ディーブイディー. Cùng một từ.' }),
    W('kutsu', 'くつ', '', 'giày', 'B', 2, 'item', 'shoes'),
    W('tshatsu', 'Tシャツ', 'ティーシャツ', 'áo thun', 'B', 2, 'item', 'tshirt', { note: 'Đọc là ティーシャツ.' }),
    W('okane', 'お金', 'おかね', 'tiền', 'B', 2, 'item', 'money', { rb: 'お{金|かね}' }),
  ]);
})();