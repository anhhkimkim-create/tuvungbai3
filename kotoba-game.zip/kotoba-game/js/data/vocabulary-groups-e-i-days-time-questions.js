/* Vocabulary bank — groups E (weekdays), F (time words), G (o'clock readings),
   H (minute readings) and I (question words, fixed exclamations). */
(function () {
  'use strict';
  const KT = window.KT;
  const W = KT.defWord;
  const list = [];

  // ---- Nhóm E — ngày trong tuần
  [
    ['getsuyoubi', '月曜日', 'げつようび', 'thứ Hai'], ['kayoubi', '火曜日', 'かようび', 'thứ Ba'],
    ['suiyoubi', '水曜日', 'すいようび', 'thứ Tư'], ['mokuyoubi', '木曜日', 'もくようび', 'thứ Năm'],
    ['kinyoubi', '金曜日', 'きんようび', 'thứ Sáu'], ['doyoubi', '土曜日', 'どようび', 'thứ Bảy'],
    ['nichiyoubi', '日曜日', 'にちようび', 'Chủ nhật'],
  ].forEach((r, i) => list.push(W(r[0], r[1], r[2], r[3], 'E', 4, 'weekday', 'cal', { wd: i + 1, fx: 'calendar' })));

  // ---- Nhóm F — thời gian, tần suất
  list.push(
    W('ji', '時', 'じ', 'giờ; hậu tố chỉ mốc giờ', 'F', 4, 'time', 'clockface',
      { nl: 1, note: 'Gắn sau số để chỉ mốc giờ trên đồng hồ: 四時 = 4 giờ.' }),
    W('fun', '分', 'ふん／ぷん', 'phút; cách đọc thay đổi theo số đi kèm', 'F', 4, 'time', 'stopwatch',
      { nl: 1, nw: 1, note: 'Đọc ふん hay ぷん tùy số đứng trước: いっぷん, にふん, さんぷん…' }),
    W('jikan', '時間', 'じかん', 'thời gian', 'F', 4, 'time', 'hourglass'),
    W('asa', 'あさ', '', 'buổi sáng', 'F', 1, 'time', 'morning', { fx: 'sunrise' }),
    W('yoru', 'よる', '', 'buổi tối; ban đêm', 'F', 1, 'time', 'night', { fx: 'night' }),
    W('mainichi', 'まいにち', '', 'mỗi ngày', 'F', 1, 'time', 'everyday'),
    W('maiasa', 'まいあさ', '', 'mỗi sáng', 'F', 1, 'time', 'everymorning', { fx: 'sunrise' }),
    W('maiban', 'まいばん', '', 'mỗi tối', 'F', 1, 'time', 'everynight', { fx: 'night' }),
    W('gozen', '午前', 'ごぜん', 'trước buổi trưa; AM', 'F', 4, 'time', 'am'),
    W('gogo', '午後', 'ごご', 'sau buổi trưa; PM', 'F', 4, 'time', 'pm',
      { note: 'Dùng cho mọi giờ sau 12 giờ trưa, gồm cả chiều và tối (ごご九時 = 9 giờ tối).' }),
    W('ima', 'いま', '', 'bây giờ', 'F', 4, 'time', 'now'),
    W('han', '半', 'はん', 'nửa; rưỡi khi nói giờ', 'F', 4, 'time', 'half',
      { note: 'Đứng sau mốc giờ để nói “rưỡi”: よじはん = 4 giờ rưỡi.' })
  );

  // ---- Nhóm G — mốc giờ (cách đọc trong bài)
  const tricky = { 4: 1, 7: 1, 9: 1 };
  [
    ['ichiji', '一時', 'いちじ'], ['niji', '二時', 'にじ'], ['sanji', '三時', 'さんじ'], ['yoji', '四時', 'よじ'],
    ['goji', '五時', 'ごじ'], ['rokuji', '六時', 'ろくじ'], ['shichiji', '七時', 'しちじ'],
    ['hachiji', '八時', 'はちじ'], ['kuji', '九時', 'くじ'], ['juuji', '十時', 'じゅうじ'],
  ].forEach((r, i) => {
    const h = i + 1;
    const x = { h, fx: 'clock' };
    if (tricky[h]) x.note = 'Chú ý cách đọc: ' + r[2] + '.';
    list.push(W(r[0], r[1], r[2], h + ' giờ', 'G', 4, 'hour', 'clock', x));
  });

  // ---- Nhóm H — đếm phút
  [
    ['ippun', '一分', 'いっぷん', 1], ['nifun', '二分', 'にふん', 2], ['sanpun', '三分', 'さんぷん', 3],
    ['yonpun', '四分', 'よんぷん', 4], ['gofun', '五分', 'ごふん', 5], ['roppun', '六分', 'ろっぷん', 6],
    ['nanafun', '七分', 'ななふん', 7], ['happun', '八分', 'はっぷん', 8], ['kyuufun', '九分', 'きゅうふん', 9],
    ['juppun', '十分', 'じゅっぷん', 10, { alt: ['じっぷん'], note: 'Cũng đọc じっぷん. Cả hai cách đều đúng.' }],
    ['nijuugofun', '二十五分', 'にじゅうごふん', 25, { tiles: ['に', 'じゅう', 'ご', 'ふん'] }],
  ].forEach((r) => list.push(W(r[0], r[1], r[2], r[3] + ' phút', 'H', 4, 'minute', 'mins',
    Object.assign({ m: r[3], fx: 'clock' }, r[4] || {}))));

  // ---- Nhóm I — từ hỏi, cụm cảm thán (cụm cố định)
  list.push(
    W('nani', 'なに', '', 'cái gì', 'I', 6, 'question', 'what'),
    W('doko', 'どこ', '', 'ở đâu; đâu', 'I', 6, 'question', 'where'),
    W('nanji', '何時', 'なんじ', 'mấy giờ', 'I', 6, 'question', 'whattime'),
    W('iidesune', 'いいですね', '', 'hay nhỉ; tốt nhỉ', 'I', 6, 'phrase', 'nice',
      { note: 'Cụm từ cố định để khen, tán thưởng.' }),
    W('e', 'えっ', '', 'ơ; hả; thể hiện ngạc nhiên', 'I', 6, 'phrase', 'surprise',
      { nl: 1, note: 'Cụm cảm thán cố định.' }),
    W('hee', 'へえ', '', 'ồ; ra vậy; thể hiện ngạc nhiên hoặc thích thú', 'I', 6, 'phrase', 'wow',
      { note: 'Cụm cảm thán cố định.' })
  );

  KT.WORDS = KT.WORDS.concat(list);
})();