/* Boot: load saved progress, find a Japanese voice, apply settings, show the start screen
   (or the join screen of a contest room when the page was opened from an invite link). */
(function () {
  'use strict';
  const KT = window.KT;
  function boot() {
    if (!document.documentElement.lang) document.documentElement.lang = 'vi';
    KT.store.load();
    KT.speech.init();
    KT.app.applySettings();
    KT.app.renderShell();
    // An invite link (?phong=K7P2Q) opens the room's join screen straight away.
    const code = KT.contest ? KT.contest.codeFromUrl() : '';
    if (code) KT.app.go('contestJoin', { code }); else KT.app.go('start');
    try {
      window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', () => KT.app.applySettings());
    } catch (e) { /* older browsers */ }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();