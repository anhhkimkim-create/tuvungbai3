/* Illustrations part 3 — time words, question words, exclamations, UI objects,
   plus generated pictures: clock faces (o'clock), minute dials and calendar pages. */
(function () {
  'use strict';
  const KT = window.KT;
  const I = KT.icons, T = I.T, PAL = I.PAL;
  const BUBBLE = (fill) => '<path d="M8 12h48v30H28l-11 10V42H8z" fill="{' + fill + '}"/>';
  Object.assign(KT.ICON_SRC, {
    clockface: '<circle cx="32" cy="32" r="24" fill="{wh}"/><path d="M32 12v4M32 48v4M12 32h4M48 32h4"/><path d="M32 32V20M32 32l9 6" stroke="{co}" stroke-width="3"/><circle cx="32" cy="32" r="2.5" fill="{k}"/>',
    stopwatch: '<rect x="27" y="4" width="10" height="5" rx="1.5" fill="{co}"/><path d="M32 9v4M48 14l4-4"/><circle cx="32" cy="36" r="22" fill="{wh}"/><path d="M32 36V18a18 18 0 0 1 16 10z" fill="{sk}"/><path d="M32 36V22" stroke="{co}" stroke-width="3"/><circle cx="32" cy="36" r="2.5" fill="{k}"/>',
    hourglass: '<path d="M16 8h32M16 56h32"/><path d="M20 8c0 12 12 16 12 24S20 44 20 56h24c0-12-12-16-12-24S44 20 44 8z" fill="{cr}"/><path d="M24 50c2-6 6-8 8-8s6 2 8 8z" fill="{b2}"/><path d="M26 16h12c-2 4-4 6-6 7-2-1-4-3-6-7z" fill="{b2}"/>',
    morning: '<path d="M32 8v8M12 18l5 5M52 18l-5 5" stroke="{b2}" stroke-width="3"/><path d="M8 44a24 24 0 0 1 48 0z" fill="{bu}"/><path d="M4 44h56"/><path d="M12 52h40" stroke="{sk}" stroke-width="3"/>',
    night: '<rect x="4" y="4" width="56" height="56" rx="12" fill="{ng}"/><path d="M38 14a16 16 0 1 0 12 26 14 14 0 0 1-12-26z" fill="{bu}"/><path d="M16 15l1.5 3 3 1.5-3 1.5-1.5 3-1.5-3-3-1.5 3-1.5z" fill="{wh}" stroke="none"/><circle cx="18" cy="44" r="1.8" fill="{wh}" stroke="none"/>',
    everyday: '<rect x="8" y="12" width="48" height="44" rx="5" fill="{cr}"/><rect x="8" y="12" width="48" height="10" rx="4" fill="{cb}"/><path d="M18 8v8M46 8v8"/><path d="M14 32l3 3 5-6M28 32l3 3 5-6M42 32l3 3 5-6M14 46l3 3 5-6M28 46l3 3 5-6M42 46l3 3 5-6" stroke="{m2}" stroke-width="2.4"/>',
    everymorning: '<path d="M8 44a18 18 0 0 1 36 0z" fill="{bu}"/><path d="M4 44h44"/><path d="M52 16a10 10 0 1 1-10-6" stroke="{co}" stroke-width="3"/><path d="M40 4l4 5-5 3" stroke="{co}" stroke-width="3"/><path d="M12 52h28" stroke="{sk}" stroke-width="3"/>',
    everynight: '<path d="M28 16a16 16 0 1 0 12 26 14 14 0 0 1-12-26z" fill="{bu}"/><path d="M54 16a10 10 0 1 1-10-6" stroke="{co}" stroke-width="3"/><path d="M42 4l4 5-5 3" stroke="{co}" stroke-width="3"/><circle cx="12" cy="12" r="1.8" fill="{b2}" stroke="none"/>',
    am: '<rect x="6" y="10" width="52" height="44" rx="10" fill="{cr}"/><path d="M32 12v4M19 27h-4M49 27h-4" stroke="{b2}" stroke-width="2.6"/><circle cx="32" cy="27" r="9" fill="{bu}"/>' + T(32, 50, 11, 'cb', 'AM'),
    pm: '<rect x="6" y="10" width="52" height="44" rx="10" fill="{ng}"/><path d="M36 16a10 10 0 1 0 8 15 9 9 0 0 1-8-15z" fill="{bu}"/>' + T(32, 50, 11, 'wh', 'PM'),
    now: '<circle cx="30" cy="34" r="20" fill="{wh}"/><path d="M30 34V22M30 34h9" stroke="{cb}" stroke-width="3"/><circle cx="51" cy="14" r="10" fill="none" stroke="{co}" stroke-width="1.6"/><circle cx="51" cy="14" r="5" fill="{co}"/>',
    half: '<circle cx="32" cy="32" r="22" fill="{wh}"/><path d="M32 10a22 22 0 0 1 0 44z" fill="{bu}"/><path d="M32 32V14M32 32v18" stroke="{co}" stroke-width="3"/><circle cx="32" cy="32" r="2.5" fill="{k}"/>',
    what: BUBBLE('bu') + T(32, 36, 22, 'k', '?'),
    where: '<path d="M32 58C20 42 14 32 14 24a18 18 0 0 1 36 0c0 8-6 18-18 34z" fill="{co}"/><circle cx="32" cy="24" r="10" fill="{wh}"/>' + T(32, 29, 14, 'co', '?'),
    whattime: '<circle cx="28" cy="34" r="20" fill="{wh}"/><path d="M28 34V22M28 34l8 5" stroke="{cb}" stroke-width="3"/><circle cx="50" cy="16" r="10" fill="{bu}"/>' + T(50, 21, 14, 'k', '?'),
    nice: BUBBLE('mi') + '<path d="M32 36c-8-5-12-9-12-13a5 5 0 0 1 12-2 5 5 0 0 1 12 2c0 4-4 8-12 13z" fill="{co}"/>',
    surprise: BUBBLE('sk') + T(32, 35, 18, 'k', '!?'),
    wow: BUBBLE('pk') + '<path d="M32 16l2.5 6.5L41 25l-6.5 2.5L32 34l-2.5-6.5L23 25l6.5-2.5z" fill="{wh}"/><path d="M46 17l1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z" fill="{wh}" stroke="none"/>',
    orb: '<circle cx="32" cy="32" r="22" fill="{sk}"/><circle cx="32" cy="32" r="17" fill="none" stroke="{wh}" stroke-width="1.4" stroke-dasharray="3 4"/><path d="M21 22a14 14 0 0 1 10-5" stroke="{wh}" stroke-width="3"/>' + T(32, 40, 22, 'cb', '?'),
    speaker: '<path d="M10 24h10l14-12v40L20 40H10z" fill="{cb}"/><path d="M42 22a14 14 0 0 1 0 20M48 16a22 22 0 0 1 0 32" stroke="{co}" stroke-width="3"/>',
    package: '<path d="M8 22 32 12l24 10v24L32 56 8 46z" fill="{b2}"/><path d="M8 22l24 10 24-10M32 32v24"/><path d="M20 17l24 10v8" stroke="{cr}" stroke-width="3"/>',
  });

  const WD_COLOR = ['', '#FCE38A', '#F26B4F', '#2E54D6', '#7CC9A2', '#F2C14E', '#B98157', '#E2483A'];
  const wrap = (inner, cls, vb) => '<svg class="ic ' + (cls || '') + '" viewBox="' + (vb || '0 0 64 64') +
    '" aria-hidden="true" focusable="false"><g fill="none" stroke="' + PAL.k +
    '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">' + inner + '</g></svg>';

  /** Analog clock at h:m. big=true adds 12 numbers (used on the clock-tower stage). */
  function clock(h, m, cls, big) {
    const ang = (deg, r) => [32 + r * Math.sin(deg * Math.PI / 180), 32 - r * Math.cos(deg * Math.PI / 180)];
    let marks = '';
    for (let i = 1; i <= 12; i++) {
      if (big) {
        const p = ang(i * 30, 19.5);
        marks += '<text x="' + p[0].toFixed(1) + '" y="' + (p[1] + 2.6).toFixed(1) + '" text-anchor="middle" font-size="7" font-weight="700" font-family="sans-serif" fill="' + PAL.k + '" stroke="none">' + i + '</text>';
      } else {
        const a = ang(i * 30, 22), b = ang(i * 30, i % 3 ? 20.5 : 19);
        marks += '<path d="M' + a[0].toFixed(1) + ' ' + a[1].toFixed(1) + 'L' + b[0].toFixed(1) + ' ' + b[1].toFixed(1) + '" stroke-width="1.6"/>';
      }
    }
    const hp = ang(((h % 12) + m / 60) * 30, 12), mp = ang(m * 6, 18);
    return wrap('<circle cx="32" cy="32" r="26" fill="' + PAL.cr + '"/>' + marks +
      '<path class="hand-h" d="M32 32L' + hp[0].toFixed(1) + ' ' + hp[1].toFixed(1) + '" stroke="' + PAL.cb + '" stroke-width="3.6"/>' +
      '<path class="hand-m" d="M32 32L' + mp[0].toFixed(1) + ' ' + mp[1].toFixed(1) + '" stroke="' + PAL.co + '" stroke-width="2.6"/>' +
      '<circle cx="32" cy="32" r="2.8" fill="' + PAL.k + '"/>', cls);
  }

  /** Minute dial: a stopwatch whose filled sector shows n minutes (a span, not a clock time). */
  function minutes(n, cls) {
    const a = (n / 60) * 2 * Math.PI, r = 20;
    const x = 32 + r * Math.sin(a), y = 36 - r * Math.cos(a);
    const sector = 'M32 36V16A20 20 0 ' + (n > 30 ? 1 : 0) + ' 1 ' + x.toFixed(1) + ' ' + y.toFixed(1) + 'Z';
    return wrap('<rect x="27" y="4" width="10" height="5" rx="1.5" fill="' + PAL.co + '"/><path d="M32 9v4"/>' +
      '<circle cx="32" cy="36" r="23" fill="' + PAL.wh + '"/><path d="' + sector + '" fill="' + PAL.sk + '"/>' +
      '<circle cx="32" cy="36" r="2.5" fill="' + PAL.k + '"/>', cls);
  }

  /** Calendar page for weekday wd (1 = Monday). Colour only, no text, so it never gives the answer away. */
  function calendar(wd, cls) {
    let dots = '';
    for (let i = 0; i < 7; i++) {
      dots += '<circle cx="' + (14 + i * 6) + '" cy="40" r="2.2" fill="' + (i + 1 === wd ? WD_COLOR[wd] : PAL.gr) + '" stroke="none"/>';
    }
    return wrap('<rect x="8" y="12" width="48" height="44" rx="5" fill="' + PAL.cr + '"/>' +
      '<rect x="8" y="12" width="48" height="12" rx="4" fill="' + WD_COLOR[wd || 1] + '"/><path d="M18 8v8M46 8v8"/>' + dots, cls);
  }

  Object.assign(I, {
    clock, minutes, calendar, WD_COLOR,
    /** Illustration for a vocabulary entry. */
    forWord(w, cls) {
      if (w.k === 'hour') return clock(w.h, 0, cls);
      if (w.k === 'minute') return minutes(w.m, cls);
      if (w.k === 'weekday') return calendar(w.wd, cls);
      return I.svg(w.ic, cls);
    },
  });
})();