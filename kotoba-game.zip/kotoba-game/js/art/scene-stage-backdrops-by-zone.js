/* Play-screen stage backdrops, one small scene per zone (viewBox 640×240).
   Colours come from CSS classes (s-*) so the stage follows the theme and
   state classes on the stage element (.is-night, .season-*, lantern .on). */
(function () {
  'use strict';
  const KT = window.KT;

  const room = () =>
    '<rect width="640" height="240" class="s-wall"/><rect y="186" width="640" height="54" class="s-floor"/>' +
    '<path d="M0 186h640M0 206h640M0 224h640" class="s-line"/>' +
    '<rect x="40" y="30" width="158" height="120" rx="12" class="s-frame"/><rect x="50" y="40" width="138" height="100" rx="5" class="s-window"/>' +
    '<circle cx="150" cy="78" r="16" class="s-sun-in"/><path d="M144 66a14 14 0 1 0 12 22a12 12 0 0 1 -12 -22z" class="s-moon-in"/>' +
    '<path d="M119 40v100M50 90h138" class="s-mullion"/>' +
    '<rect x="248" y="74" width="124" height="8" rx="2" class="s-wood"/>' +
    '<rect x="262" y="46" width="12" height="28" rx="2" class="s-book1"/><rect x="277" y="52" width="10" height="22" rx="2" class="s-book2"/>' +
    '<rect x="290" y="42" width="12" height="32" rx="2" class="s-book3"/><circle cx="344" cy="62" r="11" class="s-plant"/>' +
    '<rect x="338" y="62" width="12" height="12" rx="2" class="s-pot"/>' +
    '<path d="M396 186v-46" class="s-pole"/><path d="M380 140h32l-7-22h-18z" class="s-lampshade"/>' +
    '<path d="M384 140 352 186h88l-32-46z" class="s-light"/>' +
    '<rect x="452" y="150" width="172" height="40" rx="10" class="s-bed"/><rect x="460" y="132" width="44" height="22" rx="8" class="s-pillow"/>' +
    '<rect x="508" y="140" width="116" height="26" rx="8" class="s-blanket"/>';

  function shop() {
    let s = '<rect width="640" height="240" class="s-wall2"/><rect width="640" height="26" class="s-awning-a"/>';
    for (let i = 0; i < 16; i += 2) s += '<rect x="' + i * 40 + '" width="40" height="26" class="s-awning-b"/>';
    s += '<path d="M0 26' + 'q20 14 40 0'.repeat(16) + '" class="s-awning-edge"/>';
    const box = ['s-box1', 's-box2', 's-box3', 's-box4'];
    [[24, 64], [24, 110], [372, 64], [372, 110]].forEach(([x, y], r) => {
      s += '<rect x="' + x + '" y="' + y + '" width="244" height="7" rx="2" class="s-wood"/>';
      for (let i = 0; i < 7; i++) {
        const h = 16 + ((i * 7 + r * 5) % 14);
        s += '<rect x="' + (x + 10 + i * 33) + '" y="' + (y - h) + '" width="24" height="' + h + '" rx="3" class="' + box[(i + r) % 4] + '"/>';
      }
    });
    return s + '<rect y="164" width="640" height="12" class="s-counter-top"/><rect y="176" width="640" height="64" class="s-counter"/>';
  }

  const street = () =>
    '<rect width="640" height="240" class="s-sky"/><circle cx="560" cy="44" r="18" class="s-sun"/>' +
    '<path d="M0 150V96h50V72h40v78h30V60h60v90h40V84h50v66h40V52h50v98h40V90h60v60h40V76h50v74z" class="s-city"/>' +
    '<rect y="150" width="640" height="24" class="s-sidewalk"/><rect y="174" width="640" height="66" class="s-road"/>' +
    '<path d="M0 207h640" class="s-roadline"/><path d="M58 174V92" class="s-pole"/><circle cx="58" cy="86" r="15" class="s-stop"/>' +
    '<rect x="48" y="80" width="20" height="12" rx="3" class="s-stop-in"/>';

  function gear(cx, cy, r, cls) {
    let teeth = '';
    for (let a = 0; a < 360; a += 30) teeth += '<rect x="-5" y="' + (-r - 8) + '" width="10" height="12" rx="2" transform="rotate(' + a + ')"/>';
    return '<g transform="translate(' + cx + ' ' + cy + ')"><g class="' + cls + '">' + teeth + '<circle r="' + r + '"/><circle r="' + r * 0.35 + '" class="s-gear-hole"/></g></g>';
  }
  function clockRoom() {
    let cells = '';
    for (let i = 0; i < 7; i++) cells += '<rect x="' + (452 + i * 21) + '" y="98" width="17" height="17" rx="3" class="s-cell"/>';
    return '<rect width="640" height="240" class="s-wall4"/>' + gear(86, 70, 38, 's-gear spin') + gear(150, 150, 24, 's-gear spin-rev') +
      gear(590, 196, 46, 's-gear spin') + '<rect x="440" y="40" width="168" height="112" rx="12" class="s-board"/>' +
      '<rect x="440" y="40" width="168" height="34" rx="12" class="s-board-top"/>' + cells +
      '<rect y="200" width="640" height="40" class="s-floor4"/>';
  }

  const park = () =>
    '<rect width="640" height="240" class="s-sky5"/><circle cx="560" cy="48" r="22" class="s-sun"/>' +
    '<path d="M0 168q160-70 320-10t320-30V240H0z" class="s-hill-b"/><path d="M0 198q200-40 400 0t240-10V240H0z" class="s-hill-f"/>' +
    '<ellipse cx="470" cy="214" rx="74" ry="13" class="s-pond"/>' +
    '<rect x="74" y="122" width="12" height="62" rx="3" class="s-trunk"/><circle cx="80" cy="112" r="38" class="s-crown"/>' +
    '<rect x="586" y="138" width="10" height="50" rx="3" class="s-trunk"/><circle cx="591" cy="128" r="30" class="s-crown"/>';

  function festival() {
    let s = '<rect width="640" height="240" class="s-night"/>';
    [[60, 30], [180, 20], [300, 44], [430, 18], [520, 52], [610, 28], [250, 90], [560, 100]].forEach(([x, y]) => {
      s += '<circle cx="' + x + '" cy="' + y + '" r="1.8" class="s-star"/>';
    });
    s += '<path d="M0 38Q320 104 640 38" class="s-string"/>';
    for (let i = 0; i < 10; i++) {
      const t = (i + 0.5) / 10, u = 1 - t;
      const x = u * u * 0 + 2 * u * t * 320 + t * t * 640, y = u * u * 38 + 2 * u * t * 104 + t * t * 38;
      s += '<g transform="translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"><line x1="0" y1="0" x2="0" y2="8" class="s-string"/>' +
        '<ellipse cy="20" rx="11" ry="14" class="s-lantern" data-i="' + i + '"/><path d="M-10 20h20" class="s-lantern-band"/></g>';
    }
    return s + '<path d="M0 240V186h120v-10h60v10h100v54zM380 240V180h90v-12h70v12h100v60z" class="s-stall"/>' +
      '<path d="M20 186h80l-8-14H28zM400 180h80l-8-14h-64z" class="s-awning-a"/>';
  }

  const SCENES = { 1: room, 2: shop, 3: street, 4: clockRoom, 5: park, 6: festival };

  KT.stage = {
    /** Backdrop SVG for a zone. */
    backdrop(zid) {
      return '<svg class="stage-bg" viewBox="0 0 640 240" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">' +
        (SCENES[zid] || room)() + '</svg>';
    },
    SEASONS: ['spring', 'summer', 'autumn', 'winter'],
  };
})();