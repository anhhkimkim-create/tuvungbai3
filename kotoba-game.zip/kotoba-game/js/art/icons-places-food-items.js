/* Hand-drawn flat SVG illustrations (64×64). {xx} placeholders map to the palette.
   Ghost (faded) state is pure CSS: .ghost turns every shape into a faint outline. */
(function () {
  'use strict';
  const KT = window.KT;
  const PAL = {
    k: '#2A2F55', co: '#F26B4F', cb: '#2E54D6', bu: '#FCE38A', b2: '#F2C14E', cr: '#FFF6E5',
    mi: '#7CC9A2', m2: '#3E9C6E', sk: '#A9C8FF', pk: '#F6A9C1', br: '#B98157', wh: '#FFFFFF',
    gr: '#CBD0E0', rd: '#E2483A', or: '#F39A3D', ng: '#2B2F6B',
  };
  const T = (x, y, size, color, txt, extra) =>
    '<text x="' + x + '" y="' + y + '" text-anchor="middle" font-size="' + size + '" font-weight="800" ' +
    'font-family="sans-serif" fill="{' + color + '}" stroke="none"' + (extra || '') + '>' + txt + '</text>';
  const BUBBLE = '<path d="M8 12h48v30H28l-11 10V42H8z" fill="{FILL}"/>';

  const ICONS = (KT.ICON_SRC = KT.ICON_SRC || {});
  Object.assign(ICONS, {
    house: '<path d="M42 22V13h6v13" fill="{co}"/><path d="M8 31 32 11l24 20z" fill="{cb}"/><rect x="14" y="30" width="36" height="24" fill="{cr}"/><rect x="28" y="39" width="9" height="15" fill="{co}"/><rect x="18" y="36" width="7" height="7" fill="{sk}"/><rect x="40" y="36" width="7" height="7" fill="{sk}"/>',
    office: '<path d="M6 56h52"/><rect x="17" y="8" width="30" height="48" rx="2" fill="{sk}"/><path d="M17 17h30M17 26h30M17 35h30M27 8v38M37 8v38" stroke-width="1.6"/><rect x="27" y="46" width="10" height="10" fill="{cb}"/>',
    school: '<rect x="8" y="28" width="48" height="26" fill="{cr}"/><path d="M22 28V17h20v11" fill="{co}"/><circle cx="32" cy="22" r="3.6" fill="{wh}"/><path d="M32 17V7"/><path d="M32 7h10l-2.5 3 2.5 3H32" fill="{bu}"/><rect x="27" y="41" width="10" height="13" fill="{cb}"/><rect x="13" y="34" width="8" height="6" fill="{sk}"/><rect x="43" y="34" width="8" height="6" fill="{sk}"/>',
    konbini: '<rect x="8" y="20" width="48" height="34" rx="2" fill="{cr}"/><rect x="8" y="20" width="48" height="10" fill="{mi}"/><path d="M8 33h48" stroke="{co}" stroke-width="3"/><rect x="13" y="38" width="17" height="16" fill="{sk}"/><rect x="34" y="38" width="17" height="10" fill="{sk}"/>' + T(32, 28, 8, 'wh', '24h'),
    supermarket: '<path d="M6 14h9l7 28h26l6-20H18" fill="none"/><path d="M18 22h36l-6 20H22z" fill="{bu}"/><path d="M28 22l2 20M38 22l-1 20"/><circle cx="26" cy="50" r="4.5" fill="{cb}"/><circle cx="46" cy="50" r="4.5" fill="{cb}"/>',
    park: '<path d="M4 54h56"/><rect x="17.5" y="32" width="5" height="22" fill="{br}"/><circle cx="20" cy="24" r="12" fill="{mi}"/><rect x="32" y="30" width="24" height="5" rx="2" fill="{co}"/><rect x="32" y="38" width="24" height="5" rx="2" fill="{co}"/><path d="M35 43v11M53 43v11"/>',
    sea: '<circle cx="46" cy="18" r="7" fill="{bu}"/><path d="M4 34c6-5 10-5 15 0s10 5 15 0 10-5 15 0 8 5 11 1v22H4z" fill="{cb}"/><path d="M8 46c5-4 9-4 13 0s9 4 13 0 9-4 13 0" stroke="{wh}"/>',
    bus: '<rect x="5" y="16" width="54" height="30" rx="7" fill="{co}"/><rect x="10" y="21" width="10" height="10" rx="2" fill="{sk}"/><rect x="23" y="21" width="10" height="10" rx="2" fill="{sk}"/><rect x="36" y="21" width="10" height="10" rx="2" fill="{sk}"/><rect x="49" y="21" width="6" height="16" rx="2" fill="{sk}"/><path d="M5 37h44"/><circle cx="18" cy="47" r="5" fill="{k}"/><circle cx="46" cy="47" r="5" fill="{k}"/>',
    me: '<circle cx="28" cy="20" r="10" fill="{bu}"/><circle cx="24.5" cy="19" r="1.4" fill="{k}" stroke="none"/><circle cx="31.5" cy="19" r="1.4" fill="{k}" stroke="none"/><path d="M10 56c0-13 8-21 18-21s18 8 18 21z" fill="{cb}"/><path d="M58 28 46 36M46 36l7 .5M46 36l2.5-6.5" stroke="{co}" stroke-width="3"/>',
    english: BUBBLE.replace('FILL', 'cr') + T(32, 33, 15, 'cb', 'ABC'),
    japanese: BUBBLE.replace('FILL', 'cr') + T(32, 35, 19, 'co', 'あ'),
    schedule: '<rect x="12" y="10" width="40" height="46" rx="4" fill="{cr}"/><rect x="12" y="10" width="40" height="9" rx="3" fill="{co}"/><path d="M20 7v7M44 7v7"/><rect x="18" y="25" width="6" height="6" fill="{wh}"/><rect x="18" y="35" width="6" height="6" fill="{wh}"/><rect x="18" y="45" width="6" height="6" fill="{wh}"/><path d="M19 28l2 2 4-5" stroke="{m2}"/><path d="M28 28h18M28 38h18M28 48h12"/>',
    parttime: '<path d="M20 10h24l7 12-7 4v28H20V26l-7-4z" fill="{mi}"/><path d="M26 10c0 6 12 6 12 0"/><rect x="24" y="30" width="16" height="9" rx="2" fill="{wh}"/><path d="M27 34.5h10" stroke-width="1.6"/><circle cx="48" cy="46" r="9" fill="{bu}"/><path d="M48 41v5l3 2"/>',
    homestay: '<path d="M6 30 26 14l20 16z" fill="{co}"/><rect x="11" y="29" width="30" height="25" fill="{cr}"/><circle cx="21" cy="38" r="3.5" fill="{bu}"/><circle cx="31" cy="38" r="3.5" fill="{bu}"/><path d="M15 54c0-7 3-10 6-10s6 3 6 10M25 54c0-7 3-10 6-10s6 3 6 10" fill="{cb}"/><rect x="46" y="38" width="13" height="16" rx="2" fill="{b2}"/><path d="M50 38v-3h5v3"/>',
    milk: '<path d="M20 22 26 10h12l6 12v34H20z" fill="{wh}"/><path d="M20 22h24M26 10l-6 12M38 10l6 12"/><rect x="20" y="30" width="24" height="16" fill="{cb}"/><path d="M25 38c2-4 4-4 6 0s4 4 6 0" stroke="{wh}" stroke-width="2"/>',
    fruit: '<circle cx="24" cy="36" r="13" fill="{rd}"/><path d="M24 23c0-4 2-7 5-8"/><path d="M26 20c4-4 9-3 10 0-4 2-7 2-10 0z" fill="{mi}"/><circle cx="43" cy="42" r="10" fill="{or}"/><circle cx="19" cy="31" r="2" fill="{wh}" stroke="none"/>',
    salad: '<path d="M12 32c0-9 8-13 13-7 4-8 15-6 15 2 7-4 13 1 11 5z" fill="{mi}"/><circle cx="35" cy="27" r="4" fill="{rd}"/><circle cx="22" cy="28" r="3.2" fill="{rd}"/><path d="M8 32h48c0 12-10 20-24 20S8 44 8 32z" fill="{wh}"/><path d="M14 38h36" stroke="{sk}"/>',
    cheese: '<path d="M8 40 46 20l10 8v12z" fill="{b2}"/><rect x="8" y="40" width="48" height="13" fill="{bu}"/><circle cx="18" cy="46.5" r="2.6" fill="{b2}"/><circle cx="31" cy="47" r="3" fill="{b2}"/><circle cx="45" cy="45.5" r="2.2" fill="{b2}"/>',
    breakfast: '<circle cx="50" cy="13" r="6" fill="{bu}"/><rect x="6" y="40" width="52" height="8" rx="3" fill="{br}"/><path d="M10 28h22c0 8-5 12-11 12s-11-4-11-12z" fill="{wh}"/><path d="M14 27c2-4 4-4 6 0M20 27c2-4 4-4 6 0"/><ellipse cx="45" cy="35" rx="10" ry="5" fill="{wh}"/><circle cx="45" cy="35" r="3" fill="{b2}"/>',
    sake: '<path d="M24 8h8v6c6 4 9 10 9 18v20H15V32c0-8 3-14 9-18z" fill="{wh}"/><path d="M15 36h26" stroke="{cb}" stroke-width="3"/><path d="M44 42h12l-2 12h-8z" fill="{wh}"/><path d="M45 46h10" stroke="{cb}"/>',
    sushi: '<ellipse cx="32" cy="42" rx="22" ry="9" fill="{wh}"/><path d="M10 38c4-10 40-12 44-2-6 6-38 8-44 2z" fill="{co}"/><path d="M20 33l4 5M30 31l4 6M40 31l3 6" stroke="{wh}" stroke-width="2"/><rect x="28" y="32" width="8" height="15" fill="{k}"/>',
    bento: '<rect x="8" y="16" width="48" height="36" rx="5" fill="{co}"/><rect x="12" y="20" width="22" height="28" rx="2" fill="{wh}"/><rect x="38" y="20" width="14" height="13" rx="2" fill="{mi}"/><rect x="38" y="36" width="14" height="12" rx="2" fill="{bu}"/><circle cx="23" cy="34" r="3" fill="{rd}"/>',
    internet: '<circle cx="26" cy="36" r="17" fill="{sk}"/><path d="M9 36h34M26 19c-7 9-7 25 0 34M26 19c7 9 7 25 0 34"/><path d="M44 18c4-4 10-4 14 0M47 22c2-2 6-2 8 0" stroke="{co}"/><circle cx="51" cy="26" r="1.8" fill="{co}" stroke="none"/>',
    newspaper: '<path d="M48 24h6v26a6 6 0 0 1-6 6" fill="{gr}"/><path d="M10 14h38v36a6 6 0 0 1-6 6H14a4 4 0 0 1-4-4z" fill="{wh}"/><rect x="16" y="20" width="26" height="8" fill="{gr}"/><path d="M16 34h12M16 40h12M16 46h12M32 34h10M32 40h10M32 46h10" stroke-width="2"/>',
    tv: '<path d="M24 8l8 8 8-8"/><rect x="8" y="16" width="48" height="34" rx="5" fill="{cb}"/><rect x="13" y="21" width="38" height="24" rx="3" fill="{sk}"/><path d="M22 50l-3 6M42 50l3 6"/>',
    cd: '<circle cx="32" cy="32" r="22" fill="{gr}"/><path d="M15 26a18 18 0 0 1 11-10" stroke="{pk}" stroke-width="3"/><path d="M40 50a18 18 0 0 0 10-9" stroke="{sk}" stroke-width="3"/><circle cx="32" cy="32" r="7" fill="{wh}"/><circle cx="32" cy="32" r="2.5" fill="{k}"/>',
    dvd: '<circle cx="42" cy="28" r="16" fill="{gr}"/><circle cx="42" cy="28" r="4" fill="{wh}"/><rect x="8" y="16" width="30" height="40" rx="3" fill="{ng}"/>' + T(23, 40, 9, 'wh', 'DVD'),
    shoes: '<path d="M8 44c0-8 2-18 4-22h12c2 6 6 9 14 11l14 4c4 1 4 5 4 7v4H8z" fill="{co}"/><path d="M8 48h48v4H8z" fill="{wh}"/><path d="M24 30l4-2M27 34l4-2M31 37l4-2" stroke="{wh}" stroke-width="2"/>',
    tshirt: '<path d="M22 10c2 4 6 6 10 6s8-2 10-6l14 8-5 10-7-3v29H20V25l-7 3-5-10z" fill="{cb}"/>' + T(32, 44, 12, 'wh', 'T'),
    money: '<rect x="6" y="14" width="40" height="24" rx="3" fill="{mi}"/><circle cx="26" cy="26" r="7" fill="{wh}"/>' + T(26, 30.5, 11, 'm2', '¥') + '<ellipse cx="44" cy="48" rx="13" ry="5" fill="{b2}"/><path d="M31 43v5M57 43v5"/><ellipse cx="44" cy="43" rx="13" ry="5" fill="{bu}"/>',
  });

  const paint = (src) => src.replace(/\{(\w+)\}/g, (m, k) => PAL[k] || m);
  KT.icons = KT.icons || {};
  Object.assign(KT.icons, {
    PAL, paint, T,
    /** Full <svg> for a static icon key (falls back to the mystery orb). */
    svg(key, cls) {
      const src = ICONS[key] || ICONS.orb || '';
      return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 64 64" aria-hidden="true" focusable="false">' +
        '<g fill="none" stroke="' + PAL.k + '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">' +
        paint(src) + '</g></svg>';
    },
  });
})();