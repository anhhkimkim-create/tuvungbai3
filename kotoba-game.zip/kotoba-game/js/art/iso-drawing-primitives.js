/* Isometric (oblique 2D) drawing helpers for the city map.
   Grid: gx grows toward the lower right, gy toward the lower left, gz is height.
   Every face gets a CSS class (f-*) so colours follow the day/night theme. */
(function () {
  'use strict';
  const KT = window.KT;
  const OX = 470, OY = 150, HW = 28, HH = 16, ZU = 26;
  const r1 = (n) => Math.round(n * 10) / 10;
  const P = (gx, gy, gz) => [OX + (gx - gy) * HW, OY + (gx + gy) * HH - (gz || 0) * ZU];
  const pts = (arr) => arr.map((p) => r1(p[0]) + ',' + r1(p[1])).join(' ');
  const poly = (arr, cls) => '<polygon class="' + cls + '" points="' + pts(arr) + '"/>';
  const line = (a, b, cls) => '<line class="' + cls + '" x1="' + r1(a[0]) + '" y1="' + r1(a[1]) + '" x2="' + r1(b[0]) + '" y2="' + r1(b[1]) + '"/>';

  KT.iso = {
    OX, OY, HW, HH, ZU, P, pts, poly, line, r1,
    /** Flat rectangle on the ground (or at height z). */
    flat: (gx, gy, w, d, cls, z) =>
      poly([P(gx, gy, z), P(gx + w, gy, z), P(gx + w, gy + d, z), P(gx, gy + d, z)], cls),
    /** Box: left wall (plane y = gy + d), right wall (plane x = gx + w), top. c = { l, r, t, z } */
    box(gx, gy, w, d, h, c) {
      const o = c || {}, z0 = o.z || 0, z1 = z0 + h;
      return poly([P(gx, gy + d, z0), P(gx + w, gy + d, z0), P(gx + w, gy + d, z1), P(gx, gy + d, z1)], o.l || 'f-wall-l') +
        poly([P(gx + w, gy, z0), P(gx + w, gy + d, z0), P(gx + w, gy + d, z1), P(gx + w, gy, z1)], o.r || 'f-wall-r') +
        poly([P(gx, gy, z1), P(gx + w, gy, z1), P(gx + w, gy + d, z1), P(gx, gy + d, z1)], o.t || 'f-wall-t');
    },
    /** Gable roof with the ridge along x. c = { f, b, g } */
    roofX(gx, gy, w, d, z, rh, c) {
      const o = c || {}, m = gy + d / 2, top = z + rh;
      return poly([P(gx, gy, z), P(gx + w, gy, z), P(gx + w, m, top), P(gx, m, top)], o.b || 'f-roof-b') +
        poly([P(gx + w, gy, z), P(gx + w, gy + d, z), P(gx + w, m, top)], o.g || 'f-wall-r') +
        poly([P(gx, m, top), P(gx + w, m, top), P(gx + w, gy + d, z), P(gx, gy + d, z)], o.f || 'f-roof');
    },
    /** Pyramid roof. */
    pyramid(gx, gy, w, d, z, rh, c) {
      const o = c || {}, apex = P(gx + w / 2, gy + d / 2, z + rh);
      return poly([P(gx, gy + d, z), P(gx + w, gy + d, z), apex], o.l || 'f-roof') +
        poly([P(gx + w, gy, z), P(gx + w, gy + d, z), apex], o.r || 'f-roof-b');
    },
    /** Rectangle on a left wall (plane y): u along x from gx, v up. */
    onL: (gx, y, u, v, uw, vh, cls) =>
      poly([P(gx + u, y, v), P(gx + u + uw, y, v), P(gx + u + uw, y, v + vh), P(gx + u, y, v + vh)], cls || 'f-win'),
    /** Rectangle on a right wall (plane x): u along y from gy, v up. */
    onR: (x, gy, u, v, uw, vh, cls) =>
      poly([P(x, gy + u, v), P(x, gy + u + uw, v), P(x, gy + u + uw, v + vh), P(x, gy + u, v + vh)], cls || 'f-win'),
    /** SVG transform: local (u right, v up) units drawn on the left wall plane y, origin at gx. */
    matL(gx, y) { const p = P(gx, y); return 'matrix(' + HW + ' ' + HH + ' 0 ' + -ZU + ' ' + r1(p[0]) + ' ' + r1(p[1]) + ')'; },
    /** Same for a right wall plane x spanning gy..gy+d (origin at its left end on screen, not mirrored). */
    matR(x, gy, d) { const p = P(x, gy + d); return 'matrix(' + HW + ' ' + -HH + ' 0 ' + -ZU + ' ' + r1(p[0]) + ' ' + r1(p[1]) + ')'; },
    /** Upright text inside a wall matrix (local units). */
    wallText(u, v, size, txt, cls) {
      return '<text class="' + (cls || 'f-sign-text') + '" x="' + u + '" y="' + -v + '" font-size="' + size +
        '" text-anchor="middle" transform="scale(1,-1)" lang="ja">' + txt + '</text>';
    },
    /** Round tree; cls sets the crown colour (season aware). */
    tree(gx, gy, s, cls) {
      const p = P(gx, gy), x = r1(p[0]), y = r1(p[1]), k = s || 1;
      return '<g class="tree"><ellipse class="f-shadow" cx="' + x + '" cy="' + y + '" rx="' + r1(12 * k) + '" ry="' + r1(6 * k) + '"/>' +
        '<rect class="f-trunk" x="' + r1(x - 2.5 * k) + '" y="' + r1(y - 18 * k) + '" width="' + r1(5 * k) + '" height="' + r1(18 * k) + '" rx="2"/>' +
        '<circle class="' + (cls || 'f-leaf') + '" cx="' + x + '" cy="' + r1(y - 27 * k) + '" r="' + r1(13 * k) + '"/>' +
        '<circle class="f-hi" cx="' + r1(x - 4 * k) + '" cy="' + r1(y - 31 * k) + '" r="' + r1(5 * k) + '"/></g>';
    },
    /** Ground ellipse for a circle of radius r grid units (ponds, shadows). */
    oval(gx, gy, r, cls) {
      const p = P(gx, gy);
      return '<ellipse class="' + cls + '" cx="' + r1(p[0]) + '" cy="' + r1(p[1]) + '" rx="' + r1(r * HW * 1.41) + '" ry="' + r1(r * HH * 1.41) + '"/>';
    },
    /** Vertical pole. */
    pole: (gx, gy, h, cls, z) => line(P(gx, gy, z || 0), P(gx, gy, (z || 0) + h), cls || 'f-pole'),
    circle(pt, r, cls) { return '<circle class="' + cls + '" cx="' + r1(pt[0]) + '" cy="' + r1(pt[1]) + '" r="' + r + '"/>'; },
  };
})();