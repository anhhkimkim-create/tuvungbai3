/* City map — back half of the island (behind the main road): Tháp đồng hồ (zone 4),
   school + office (zone 3) and Công viên bốn mùa (zone 5), plus sky objects.
   Each object: { zone, word, d (depth), svg }. Objects tied to a word stay a faint
   outline until that word has been answered correctly once. */
(function () {
  'use strict';
  const KT = window.KT;
  const I = KT.iso, P = I.P, r1 = I.r1;
  const o = (zone, word, d, svg) => ({ zone, word, d, svg });
  const HOURS = ['ichiji', 'niji', 'sanji', 'yoji', 'goji', 'rokuji', 'shichiji', 'hachiji', 'kuji', 'juuji'];
  const DAYS = ['getsuyoubi', 'kayoubi', 'suiyoubi', 'mokuyoubi', 'kinyoubi', 'doyoubi', 'nichiyoubi'];
  const VE = ' vector-effect="non-scaling-stroke"';

  /** Clock face on a wall (local units, v up). Each restored o'clock word lights one lamp. */
  function clockFace(mat, cu, cv, ctx) {
    let s = '<g transform="' + mat + '"><g transform="translate(' + cu + ' ' + cv + ')"><circle class="f-clock" r="0.62"' + VE + '/>';
    HOURS.forEach((id, i) => {
      const a = ((i + 1) * 30 * Math.PI) / 180;
      s += '<circle class="f-lamp' + (ctx.on(id) ? ' on' : '') + '" cx="' + (0.48 * Math.sin(a)).toFixed(3) +
        '" cy="' + (0.48 * Math.cos(a)).toFixed(3) + '" r="0.07"' + VE + '/>';
    });
    const spin = ctx.anim && ctx.on('ji')
      ? '<animateTransform attributeName="transform" type="rotate" from="0" to="-360" dur="14s" repeatCount="indefinite"/>' : '';
    return s + '<line class="f-hand" x1="0" y1="0" x2="0" y2="0.3" transform="rotate(-120)"' + VE + '/>' +
      '<line class="f-hand m" x1="0" y1="0" x2="0" y2="0.46"' + VE + '>' + spin + '</line></g></g>';
  }

  function zone4(ctx) {
    const out = [o(4, null, 0, I.flat(0.6, 0.9, 5.8, 5.9, 'f-plaza'))];
    const x = 2.4, y = 2.2, w = 2.2, h = 5.2, ly = y + w, rx = x + w;
    const t = I.box(x, y, w, w, h) +
      I.onL(x, ly, 0, 3.4, w, 0.3, 'f-coral') + I.onR(rx, y, 0, 3.4, w, 0.3, 'f-coral-d') +
      I.onL(x, ly, 0.8, 0, 0.6, 1.15, 'f-door') +
      I.onL(x, ly, 0.3, 1.8, 0.42, 0.7) + I.onL(x, ly, 1.48, 1.8, 0.42, 0.7) +
      I.onR(rx, y, 0.3, 1.8, 0.42, 0.7) + I.onR(rx, y, 1.48, 1.8, 0.42, 0.7) +
      I.pyramid(x, y, w, w, h, 1.8) + I.circle(P(x + w / 2, y + w / 2, h + 1.8), 4, 'f-butter');
    out.push(o(4, null, 6.6, t));
    out.push(o(4, 'ji', 6.65, clockFace(I.matL(x, ly), 1.1, 4.5, ctx) + clockFace(I.matR(rx, y, w), 1.1, 4.5, ctx)));
    DAYS.forEach((id, i) => {
      const gx = 0.9 + i * 0.62, gy = 6.4;
      out.push(o(4, id, gx + gy + 0.4, I.pole(gx, gy, 1.75) +
        I.poly([P(gx, gy, 1.7), P(gx + 0.5, gy, 1.6), P(gx + 0.5, gy, 1.22), P(gx, gy, 1.14)], 'f-wd' + (i + 1))));
    });
    return out;
  }

  function zone3back() {
    const out = [];
    const x = 5.0, y = 0.6, w = 1.7, d = 2.8, h = 2.0;
    let s = I.box(x, y, w, d, h, { t: 'f-roof-flat' });
    [0.45, 1.2].forEach((v) => {
      s += I.onL(x, y + d, 0.2, v, 0.45, 0.5) + I.onL(x, y + d, 1.05, v, 0.45, 0.5);
      [0.2, 0.75, 1.85, 2.35].forEach((u) => { s += I.onR(x + w, y, u, v, 0.38, 0.5); });
    });
    s += I.onR(x + w, y, 1.25, 0, 0.42, 0.95, 'f-door') +
      I.box(5.55, 1.6, 0.6, 0.7, 0.8, { z: h }) + I.pyramid(5.55, 1.6, 0.6, 0.7, h + 0.8, 0.55, { l: 'f-coral', r: 'f-coral-d' }) +
      I.pole(6.45, 0.75, 1.2, 'f-pole', h) +
      I.poly([P(6.45, 0.75, h + 1.2), P(6.95, 0.75, h + 1.08), P(6.45, 0.75, h + 0.92)], 'f-butter');
    out.push(o(3, 'gakkou', x + w / 2 + y + d / 2, s));

    const ox = 5.3, oy = 4.4, ow = 1.4, od = 1.5, oh = 3.6;
    let f = I.box(ox, oy, ow, od, oh, { l: 'f-glass-l', r: 'f-glass-r', t: 'f-glass-t' });
    for (let v = 0.6; v < oh - 0.1; v += 0.6) {
      f += I.line(P(ox, oy + od, v), P(ox + ow, oy + od, v), 'f-gridline') +
        I.line(P(ox + ow, oy, v), P(ox + ow, oy + od, v), 'f-gridline');
    }
    f += I.line(P(ox + ow / 2, oy + od, 0), P(ox + ow / 2, oy + od, oh), 'f-gridline') +
      I.line(P(ox + ow, oy + od / 2, 0), P(ox + ow, oy + od / 2, oh), 'f-gridline') +
      I.onL(ox, oy + od, 0.45, 0, 0.5, 0.55, 'f-door');
    out.push(o(3, 'kaisha', ox + ow / 2 + oy + od / 2, f));
    return out;
  }

  function zone5(ctx) {
    const out = [o(5, null, 0, I.flat(8.6, 3.0, 5.0, 0.5, 'f-path'))];
    out.push(o(5, 'sakura', 11.4, I.tree(9.4, 1.2, 1, 'f-sakura') + I.tree(10.6, 0.8, 0.9, 'f-sakura') + I.tree(11.8, 1.4, 0.95, 'f-sakura')));
    out.push(o(5, 'ohanami', 12.8, I.flat(9.9, 1.9, 1.2, 0.8, 'f-mat') +
      I.box(10.5, 2.2, 0.3, 0.25, 0.12, { l: 'f-coral', r: 'f-coral-d', t: 'f-butter' })));
    const ap = P(13.0, 1.15, 1.4);
    out.push(o(5, 'sukii', 14.1, I.poly([P(13.6, 0.3), P(13.6, 2.0), ap], 'f-snow-r') + I.poly([P(12.4, 2.0), P(13.6, 2.0), ap], 'f-snow-l')));
    out.push(o(5, 'tsuchi', 14.2, I.flat(11.2, 2.3, 0.9, 0.55, 'f-soil') +
      I.circle(P(11.5, 2.55, 0.12), 2.6, 'f-sprout') + I.circle(P(11.85, 2.55, 0.12), 2.6, 'f-sprout')));
    let sign = I.pole(9.0, 3.9, 1.15) + I.poly([P(8.65, 3.9, 1.3), P(9.35, 3.9, 1.3), P(9.35, 3.9, 0.82), P(8.65, 3.9, 0.82)], 'f-board');
    if (ctx.on('kouen')) sign += '<g transform="' + I.matL(8.65, 3.9) + '">' + I.wallText(0.35, 0.95, 0.27, 'こうえん') + '</g>';
    out.push(o(5, 'kouen', 12.9, sign));
    out.push(o(5, 'tenisu', 15.9, I.flat(9.4, 4.4, 2.2, 2.0, 'f-court') + I.flat(9.55, 4.55, 1.9, 1.7, 'f-courtline') +
      I.poly([P(10.5, 4.4), P(10.5, 6.4), P(10.5, 6.4, 0.28), P(10.5, 4.4, 0.28)], 'f-net')));
    out.push(o(5, 'mizu', 18.1, I.oval(12.8, 5.3, 0.85, 'f-water') + I.oval(12.6, 5.1, 0.35, 'f-water-hi')));
    out.push(o(5, 'baabekyuu', 16.2, I.pole(12.0, 4.2, 0.4, 'f-pole-d') + I.pole(12.5, 4.2, 0.4, 'f-pole-d') +
      I.box(11.9, 3.8, 0.7, 0.45, 0.18, { z: 0.38, l: 'f-dark-l', r: 'f-dark-r', t: 'f-grill' })));
    const fp = P(12.25, 4.02, 0.56);
    out.push(o(5, 'hi_fire', 16.3, '<path class="f-flame" d="M' + r1(fp[0] - 5) + ' ' + r1(fp[1]) + 'c0-7 5-9 5-15c1 6 5 8 5 15z"/>' +
      '<path class="f-flame-in" d="M' + r1(fp[0] - 2.5) + ' ' + r1(fp[1]) + 'c0-4 2.5-5 2.5-8c.5 3 2.5 4 2.5 8z"/>'));
    out.push(o(5, 'ki', 20.9, I.tree(14.9, 6.0, 1.3, ctx.leaf)));
    out.push(o(5, null, 15.6, I.tree(9.0, 6.6, 0.6, ctx.leaf)));
    return out;
  }

  function burst(x, y, r, tone, i) {
    let rays = '';
    for (let k = 0; k < 12; k++) rays += '<line x1="0" y1="' + r1(-r * 0.35) + '" x2="0" y2="' + -r + '" transform="rotate(' + k * 30 + ')"/>';
    return '<g transform="translate(' + x + ' ' + y + ')"><g class="fw fw-' + tone + '" style="--fw-delay:' + (i * 0.9) + 's">' +
      rays + '<circle r="' + r1(r * 0.18) + '"/></g></g>';
  }

  function sky() {
    let rays = '';
    for (let a = 0; a < 360; a += 45) rays += '<line x1="0" y1="-33" x2="0" y2="-43" transform="rotate(' + a + ')"/>';
    return [
      o(5, 'hi_sun', 0, '<g transform="translate(860 66)"><g class="sun-rays f-rays">' + rays + '</g><circle class="f-sun" r="25"/></g>'),
      o(5, 'tsuki', 0, '<g transform="translate(86 70)"><path class="f-moon" d="M8 -24a24 24 0 1 0 16 38a20 20 0 0 1 -16 -38z"/></g>'),
      o(6, 'hanabi', 0, burst(640, 70, 26, 'co', 0) + burst(732, 42, 20, 'bu', 1) + burst(792, 118, 22, 'pk', 2)),
    ];
  }

  KT.cityParts = Object.assign(KT.cityParts || {}, { zone4, zone3back, zone5, sky, HOURS, DAYS });
})();