/* Mochi the courier cat (companion) and simple townspeople (customers, passengers,
   residents). Expressions switch with CSS classes: .cat.happy / .cat.sad. */
(function () {
  'use strict';
  const KT = window.KT;
  const K = '#2A2F55';

  function cat(cls) {
    return '<svg class="cat ' + (cls || '') + '" viewBox="0 0 80 80" aria-hidden="true" focusable="false">' +
      '<g class="cat-tail"><path d="M57 63c11-2 17-11 14-22" fill="none" stroke="' + K + '" stroke-width="8" stroke-linecap="round"/>' +
      '<path d="M57 63c11-2 17-11 14-22" fill="none" stroke="#FFF6E5" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M70 46c1-2 1-4 1-5" fill="none" stroke="#F2C14E" stroke-width="4" stroke-linecap="round"/></g>' +
      '<ellipse cx="40" cy="62" rx="20" ry="14" fill="#FFF6E5" stroke="' + K + '" stroke-width="2.5"/>' +
      '<rect x="44" y="55" width="13" height="11" rx="3" fill="#2E54D6" stroke="' + K + '" stroke-width="2"/>' +
      '<path d="M46 58h9" stroke="#FCE38A" stroke-width="1.6"/>' +
      '<g class="cat-ears"><path d="M25 31 27 13l11 11z" fill="#FFF6E5" stroke="' + K + '" stroke-width="2.5" stroke-linejoin="round"/>' +
      '<path d="M55 31 53 13 42 24z" fill="#FFF6E5" stroke="' + K + '" stroke-width="2.5" stroke-linejoin="round"/>' +
      '<path d="M28 26 29 18l5 5zM52 26l-1-8-5 5z" fill="#F6A9C1"/></g>' +
      '<circle cx="40" cy="38" r="17" fill="#FFF6E5" stroke="' + K + '" stroke-width="2.5"/>' +
      '<path d="M34 24c2 3 10 3 12 0" fill="none" stroke="#F2C14E" stroke-width="3" stroke-linecap="round"/>' +
      '<g class="eyes-normal"><ellipse class="blink" cx="33" cy="38" rx="2.4" ry="3.2" fill="' + K + '"/><ellipse class="blink" cx="47" cy="38" rx="2.4" ry="3.2" fill="' + K + '"/></g>' +
      '<g class="eyes-happy" fill="none" stroke="' + K + '" stroke-width="2.4" stroke-linecap="round"><path d="M30 39q3-4 6 0M44 39q3-4 6 0"/></g>' +
      '<g class="eyes-sad" fill="none" stroke="' + K + '" stroke-width="2.4" stroke-linecap="round"><path d="M30 37l6 2M50 37l-6 2"/></g>' +
      '<path d="M38.5 43h3l-1.5 2z" fill="#F26B4F"/>' +
      '<path d="M40 45q-2 3-5 2M40 45q2 3 5 2" fill="none" stroke="' + K + '" stroke-width="1.6" stroke-linecap="round"/>' +
      '<path d="M22 42h7M22 46l7-1M58 42h-7M58 46l-7-1" stroke="' + K + '" stroke-width="1.2" stroke-linecap="round"/>' +
      '<path d="M27 52q13 6 26 0" fill="none" stroke="#F26B4F" stroke-width="3.5" stroke-linecap="round"/>' +
      '<circle cx="40" cy="56" r="3" fill="#FCE38A" stroke="' + K + '" stroke-width="1.6"/></svg>';
  }

  const SKIN = ['#FFD9B8', '#F2C29A', '#E0A97E'];
  const HAIR = ['#2A2F55', '#8B5A3C', '#3B3F7A', '#C98A3D'];
  const SHIRT = ['#F26B4F', '#2E54D6', '#7CC9A2', '#F2C14E', '#F6A9C1'];

  /** A friendly bust-shaped townsperson; variant picks colours and hair. */
  function person(variant, cls) {
    const v = Math.abs(variant || 0);
    const skin = SKIN[v % 3], hair = HAIR[v % 4], shirt = SHIRT[v % 5];
    const longHair = v % 2 === 1;
    return '<svg class="person ' + (cls || '') + '" viewBox="0 0 80 100" aria-hidden="true" focusable="false">' +
      '<path d="M14 100c0-22 11-34 26-34s26 12 26 34z" fill="' + shirt + '" stroke="' + K + '" stroke-width="2.5"/>' +
      (longHair ? '<path d="M20 44c-2 18 4 26 6 28h28c2-2 8-10 6-28z" fill="' + hair + '" stroke="' + K + '" stroke-width="2.5"/>' : '') +
      '<circle cx="40" cy="42" r="20" fill="' + skin + '" stroke="' + K + '" stroke-width="2.5"/>' +
      '<path d="M20 40c0-14 9-20 20-20s20 6 20 20c-6-6-14-8-20-8s-14 2-20 8z" fill="' + hair + '" stroke="' + K + '" stroke-width="2.5" stroke-linejoin="round"/>' +
      '<circle cx="33" cy="45" r="2.4" fill="' + K + '"/><circle cx="47" cy="45" r="2.4" fill="' + K + '"/>' +
      '<path d="M35 53q5 4 10 0" fill="none" stroke="' + K + '" stroke-width="2.2" stroke-linecap="round"/>' +
      '<circle cx="28" cy="51" r="3" fill="#F6A9C1" opacity=".7"/><circle cx="52" cy="51" r="3" fill="#F6A9C1" opacity=".7"/></svg>';
  }

  KT.sprites = { cat, person };
})();