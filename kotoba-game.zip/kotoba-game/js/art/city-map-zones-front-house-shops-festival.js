/* City map — front half of the island (in front of the main road): Ngôi nhà thức giấc
   (zone 1), bus stop (zone 3), Cửa hàng thất lạc (zone 2), Lễ hội ánh sáng (zone 6),
   plus the bus and the sea, which belong to Chuyến xe ký ức (zone 3). */
(function () {
  'use strict';
  const KT = window.KT;
  const I = KT.iso, P = I.P, r1 = I.r1;
  const o = (zone, word, d, svg) => ({ zone, word, d, svg });

  function zone1(ctx) {
    const out = [o(1, null, 0, I.flat(0.6, 9.2, 5.6, 6.2, 'f-yard'))];
    const x = 1.4, y = 10.0, w = 3.0, d = 2.4, h = 2.0, ly = y + d, rx = x + w;
    out.push(o(1, 'uchi', 13.1, I.box(x, y, w, d, h) + I.onL(x, ly, 1.9, 0, 0.6, 1.15, 'f-door') +
      I.roofX(x - 0.2, y - 0.2, w + 0.4, d + 0.4, h, 1.3)));
    // morning window (curtains open) and bedroom window (lights off, moon)
    out.push(o(1, 'okimasu', 13.15, I.onL(x, ly, 0.35, 0.75, 0.9, 0.7, 'f-win-day') +
      I.poly([P(x + 0.35, ly, 1.45), P(x + 0.6, ly, 1.45), P(x + 0.35, ly, 1.0)], 'f-curtain') +
      I.poly([P(x + 1.25, ly, 1.45), P(x + 1.0, ly, 1.45), P(x + 1.25, ly, 1.0)], 'f-curtain')));
    out.push(o(1, 'nemasu', 13.16, I.onR(rx, y, 0.6, 0.75, 0.9, 0.7, 'f-win-night') +
      I.circle(P(rx, y + 1.05, 1.1), 3.6, 'f-butter') + I.circle(P(rx, y + 0.97, 1.16), 3.2, 'f-win-night')));
    out.push(o(1, 'terebi', 13.2, I.pole(2.0, 11.2, 0.9, 'f-antenna', 3.3) +
      I.line(P(1.72, 11.2, 4.02), P(2.28, 11.2, 4.02), 'f-antenna') + I.line(P(1.8, 11.2, 3.8), P(2.2, 11.2, 3.8), 'f-antenna')));
    out.push(o(1, 'shinbun', 17.9, I.pole(5.0, 13.0, 0.72, 'f-pole') +
      I.box(4.8, 12.8, 0.4, 0.4, 0.32, { z: 0.72, l: 'f-coral', r: 'f-coral-d', t: 'f-coral-t' }) +
      I.onL(4.8, 13.2, 0.06, 0.8, 0.28, 0.12, 'f-paper')));
    out.push(o(1, 'asagohan', 15.8, I.box(1.9, 13.3, 1.0, 0.7, 0.45, { l: 'f-wood-l', r: 'f-wood-r', t: 'f-wood-t' }) +
      I.circle(P(2.25, 13.6, 0.5), 3.6, 'f-white') + I.circle(P(2.6, 13.7, 0.5), 2.6, 'f-coral')));
    const rp = P(3.6, 13.2);
    out.push(o(1, 'watashi', 16.8, '<g transform="translate(' + r1(rp[0]) + ' ' + r1(rp[1]) + ')">' +
      '<ellipse class="f-shadow" rx="7" ry="3"/><rect class="f-shirt" x="-5" y="-17" width="10" height="13" rx="4"/>' +
      '<circle class="f-skin" cy="-22" r="5"/><path class="f-hair" d="M-5 -23a5 5 0 0 1 10 0z"/></g>'));
    [[0.7, 9.6, 0.8], [0.9, 14.8, 0.75], [5.7, 15.0, 0.7]].forEach((t) => out.push(o(1, null, t[0] + t[1], I.tree(t[0], t[1], t[2], ctx.leaf))));
    return out;
  }

  function zone3front() {
    return [o(3, null, 15.3,
      I.box(5.8, 8.75, 1.0, 0.35, 1.05, { l: 'f-glass-l', r: 'f-glass-r', t: 'f-wall-t' }) +
      I.box(5.7, 8.65, 1.2, 0.55, 0.12, { z: 1.05, l: 'f-cobalt', r: 'f-cobalt-d', t: 'f-cobalt-t' }) +
      I.pole(6.95, 9.3, 1.5) + I.circle(P(6.95, 9.3, 1.55), 6, 'f-coral'))];
  }

  function zone2(ctx) {
    const out = [];
    const x = 9.0, y = 9.2, w = 2.8, d = 1.8, h = 1.5, ly = y + d, rx = x + w;
    let k = I.box(x, y, w, d, h, { t: 'f-roof-flat' }) +
      I.onL(x, ly, 0.25, 0.08, 2.3, 0.85, 'f-glass-l') + I.line(P(x + 1.4, ly, 0.08), P(x + 1.4, ly, 0.93), 'f-frame') +
      I.onL(x, ly, 0, 1.0, w, 0.08, 'f-coral') + I.onL(x, ly, 0, 1.08, w, 0.42, 'f-mint') + I.onR(rx, y, 0, 1.08, d, 0.42, 'f-mint-d');
    if (ctx.on('konbini')) k += '<g transform="' + I.matL(x, ly) + '">' + I.wallText(1.4, 1.17, 0.3, 'コンビニ', 'f-sign-text light') + '</g>';
    out.push(o(2, 'konbini', 20.5, k));
    out.push(o(2, 'gyuunyuu', 20.6, I.box(10.9, 9.5, 0.45, 0.45, 0.72, { z: h, l: 'f-white-l', r: 'f-white-r', t: 'f-cobalt-t' }) +
      I.onL(10.9, 9.95, 0, h + 0.25, 0.45, 0.22, 'f-cobalt')));

    const sx = 9.0, sy = 12.4, sw = 3.2, sd = 2.6, sh = 1.9, sly = sy + sd, srx = sx + sw;
    let s = I.box(sx, sy, sw, sd, sh, { t: 'f-roof-flat' }) +
      I.onL(sx, sly, 0, 1.38, sw, 0.5, 'f-coral') + I.onR(srx, sy, 0, 1.38, sd, 0.5, 'f-coral-d') +
      I.onL(sx, sly, 1.2, 0, 0.8, 1.05, 'f-glass-l') + I.onL(sx, sly, 0.2, 0.3, 0.75, 0.7) + I.onL(sx, sly, 2.25, 0.3, 0.75, 0.7);
    if (ctx.on('suupaa')) s += '<g transform="' + I.matL(sx, sly) + '">' + I.wallText(1.6, 1.5, 0.34, 'スーパー', 'f-sign-text light') + '</g>';
    out.push(o(2, 'suupaa', 24.3, s));
    const shirt = 'M1.08 0.95L1.2 0.95Q1.3 0.86 1.4 0.95L1.52 0.95L1.66 0.8L1.57 0.72L1.52 0.76L1.52 0.27L1.08 0.27L1.08 0.76L1.03 0.72L0.94 0.8Z';
    out.push(o(2, 'tshatsu', 24.4, '<g transform="' + I.matR(srx, sy, sd) + '"><path class="f-shirt-banner" d="' + shirt + '" vector-effect="non-scaling-stroke"/></g>'));
    let fr = I.box(9.5, 15.2, 1.3, 0.5, 0.45, { l: 'f-wood-l', r: 'f-wood-r', t: 'f-wood-t' });
    ['f-fruit-a', 'f-fruit-b', 'f-fruit-c', 'f-fruit-a'].forEach((c, i) => { fr += I.circle(P(9.72 + i * 0.28, 15.45, 0.5), 3.4, c); });
    out.push(o(2, 'kudamono', 25.6, fr));
    return out;
  }

  function lanternString(x0, x1, gy, k0) {
    const a = P(x0, gy, 1.95), b = P(x1, gy, 1.95);
    const cx = (a[0] + b[0]) / 2, cy = (a[1] + b[1]) / 2 + 12;
    let s = I.pole(x0, gy, 2.0) + I.pole(x1, gy, 2.0) +
      '<path class="f-string" d="M' + r1(a[0]) + ' ' + r1(a[1]) + 'Q' + r1(cx) + ' ' + r1(cy) + ' ' + r1(b[0]) + ' ' + r1(b[1]) + '"/>';
    for (let i = 1; i <= 5; i++) {
      const t = i / 6, u = 1 - t;
      const px = u * u * a[0] + 2 * u * t * cx + t * t * b[0], py = u * u * a[1] + 2 * u * t * cy + t * t * b[1];
      s += '<g transform="translate(' + r1(px) + ' ' + r1(py) + ')"><g class="lantern" style="--sway-delay:' + ((k0 + i) * 0.23).toFixed(2) + 's">' +
        '<line class="f-string" x1="0" y1="0" x2="0" y2="4"/><ellipse class="f-lantern" cx="0" cy="10" rx="4.6" ry="6"/>' +
        '<line class="f-lantern-band" x1="-4" y1="10" x2="4" y2="10"/></g></g>';
    }
    return s;
  }

  function zone6() {
    const out = [o(6, null, 0, I.flat(12.6, 9.0, 3.2, 6.6, 'f-plaza-fest'))];
    out.push(o(6, null, 23.4, I.line(P(13.0, 9.3), P(13.0, 9.3, 1.95), 'f-gate-post') + I.line(P(15.2, 9.3), P(15.2, 9.3, 1.95), 'f-gate-post') +
      I.poly([P(12.7, 9.3, 2.08), P(15.5, 9.3, 2.08), P(15.4, 9.3, 1.88), P(12.8, 9.3, 1.88)], 'f-gate') +
      I.poly([P(12.9, 9.3, 1.62), P(15.3, 9.3, 1.62), P(15.3, 9.3, 1.5), P(12.9, 9.3, 1.5)], 'f-gate')));
    out.push(o(6, 'omatsuri', 26.6, lanternString(12.9, 15.7, 11.2, 0) + lanternString(12.9, 15.7, 13.4, 5)));
    [12.9, 14.6].forEach((sx) => out.push(o(6, null, sx + 15.4,
      I.box(sx, 14.6, 1.1, 0.8, 0.85, { l: 'f-wood-l', r: 'f-wood-r', t: 'f-wood-t' }) +
      I.roofX(sx - 0.1, 14.5, 1.3, 1.0, 0.85, 0.35, { f: 'f-awning', b: 'f-awning-b', g: 'f-awning-g' }))));
    return out;
  }

  function bus(ctx) {
    const x = 0.5, y = 7.2, w = 2.0, d = 0.85, h = 0.95, ly = y + d;
    let s = I.box(x, y, w, d, h, { l: 'f-bus-l', r: 'f-bus-r', t: 'f-bus-t' });
    for (let i = 0; i < 4; i++) s += I.onL(x, ly, 0.12 + i * 0.44, 0.45, 0.34, 0.3, 'f-win');
    s += I.onR(x + w, y, 0.1, 0.4, 0.65, 0.42, 'f-win') +
      I.circle(P(x + 0.45, ly, 0.12), 4, 'f-wheel') + I.circle(P(x + 1.6, ly, 0.12), 4, 'f-wheel');
    return o(3, 'basu', 0, '<g class="bus' + (ctx.anim && ctx.on('basu') ? ' bus-drive' : '') + '">' + s + '</g>');
  }

  function sea() {
    const waves = [[15.0, 1.2], [14.8, 2.8], [15.4, 3.9]].map((g, i) => {
      const p = P(g[0], g[1]);
      return '<path class="f-wave" style="--wave-delay:' + i * 0.7 + 's" d="M' + r1(p[0] - 12) + ' ' + r1(p[1]) + 'q6 -5 12 0t12 0"/>';
    }).join('');
    return o(3, 'umi', 0, I.flat(13.6, 0, 0.6, 4.6, 'f-sand') + I.flat(14.2, 0, 1.8, 4.6, 'f-sea') + waves);
  }

  KT.cityParts = Object.assign(KT.cityParts || {}, { zone1, zone3front, zone2, zone6, bus, sea });
})();