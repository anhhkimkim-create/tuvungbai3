/* Assembles the isometric city SVG in painter's order: sky, island, roads,
   back half (behind the main road), the bus, then the front half.
   Locked zones are grey; an unlocked zone regains colour as its words are restored;
   objects tied to a word stay faint outlines until that word is answered correctly. */
(function () {
  'use strict';
  const KT = window.KT;
  const I = KT.iso, P = I.P;
  const VB_W = 940, VB_H = 700;
  const LEAF = { spring: 'f-leaf-sp', summer: 'f-leaf', autumn: 'f-leaf-au', winter: 'f-leaf-wi' };

  function makeCtx(opts) {
    return {
      anim: !KT.util.calm() && !(opts && opts.still),
      leaf: LEAF[KT.store.S.lastSeason] || 'f-leaf',
      on: (id) => KT.learn.peek(id).c > 0,
    };
  }

  function zoneAttr(zid) {
    if (!KT.learn.unlocked(zid)) return ' class="zone-g locked" filter="url(#kt-sat0)"';
    const pct = KT.learn.zoneStats(zid).pct;
    const f = pct < 34 ? 'kt-sat1' : pct < 67 ? 'kt-sat2' : '';
    return ' class="zone-g"' + (f ? ' filter="url(#' + f + ')"' : '');
  }

  const wrapObj = (ob, ctx) => (!ob.word ? ob.svg :
    '<g class="mobj ' + (ctx.on(ob.word) ? 'live' : 'ghost') + '" data-word="' + ob.word + '">' + ob.svg + '</g>');

  /** One <g data-zone> per zone inside a layer, objects sorted back to front. */
  function layer(list, order, ctx) {
    return order.map((zid) => {
      const objs = list.filter((x) => x.zone === zid).sort((a, b) => a.d - b.d);
      return objs.length ? '<g data-zone="' + zid + '"' + zoneAttr(zid) + '>' + objs.map((x) => wrapObj(x, ctx)).join('') + '</g>' : '';
    }).join('');
  }

  function ground() {
    let zebra = '';
    for (let i = 0; i < 4; i++) {
      zebra += I.flat(7.08 + i * 0.4, 8.75, 0.22, 0.5, 'f-zebra') + I.flat(8.75, 7.08 + i * 0.4, 0.5, 0.22, 'f-zebra');
    }
    return I.poly([P(0, 16), P(16, 16), P(16, 16, -0.9), P(0, 16, -0.9)], 'f-cliff-l') +
      I.poly([P(16, 0), P(16, 16), P(16, 16, -0.9), P(16, 0, -0.9)], 'f-cliff-r') +
      I.flat(0, 0, 16, 16, 'f-grass') +
      I.flat(0, 7, 16, 1.6, 'f-road') + I.flat(7, 0, 1.6, 16, 'f-road') +
      I.line(P(0, 7.8), P(7, 7.8), 'f-dash') + I.line(P(8.6, 7.8), P(16, 7.8), 'f-dash') +
      I.line(P(7.8, 0), P(7.8, 7), 'f-dash') + I.line(P(7.8, 8.6), P(7.8, 16), 'f-dash') + zebra;
  }

  function clouds(anim) {
    const c = (x, y, s) => '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')"><g class="cloud' + (anim ? ' drift' : '') + '">' +
      '<ellipse class="f-cloud" cx="0" cy="0" rx="26" ry="11"/><ellipse class="f-cloud" cx="-14" cy="3" rx="16" ry="9"/>' +
      '<ellipse class="f-cloud" cx="16" cy="4" rx="15" ry="8"/></g></g>';
    return c(300, 66, 1) + c(560, 28, 0.8) + c(170, 150, 0.7);
  }

  function petals(ctx) {
    if (!ctx.anim || !ctx.on('sakura')) return '';
    let s = '<g class="petals" aria-hidden="true">';
    for (let i = 0; i < 8; i++) {
      s += '<ellipse class="petal" cx="' + (650 + ((i * 37) % 140)) + '" cy="' + (262 + ((i * 23) % 44)) +
        '" rx="2.6" ry="1.7" style="--pd:' + (i * 0.7).toFixed(1) + 's"/>';
    }
    return s + '</g>';
  }

  /** Full city SVG. opts: { still, cls, label } */
  function render(opts) {
    const o = opts || {};
    const ctx = makeCtx(o);
    const C = KT.cityParts;
    const back = [].concat(C.zone4(ctx), C.zone3back(ctx), C.zone5(ctx));
    const front = [].concat(C.zone1(ctx), C.zone3front(ctx), C.zone2(ctx), C.zone6(ctx));
    const defs = '<defs><linearGradient id="kt-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="sky-a"/><stop offset="1" class="sky-b"/></linearGradient>' +
      '<filter id="kt-sat0"><feColorMatrix type="saturate" values="0"/></filter>' +
      '<filter id="kt-sat1"><feColorMatrix type="saturate" values="0.3"/></filter>' +
      '<filter id="kt-sat2"><feColorMatrix type="saturate" values="0.65"/></filter></defs>';
    return '<svg class="city-map' + (ctx.anim ? ' is-animated' : '') + (o.cls ? ' ' + o.cls : '') + '" viewBox="0 0 ' + VB_W + ' ' + VB_H +
      '" role="img" aria-label="' + KT.util.esc(o.label || 'Bản đồ thành phố Kotoba') + '">' + defs +
      '<rect class="m-sky" width="' + VB_W + '" height="' + VB_H + '" fill="url(#kt-sky)"/>' + clouds(ctx.anim) +
      layer(C.sky(ctx), [5, 6], ctx) + ground() + layer([C.sea(ctx)], [3], ctx) +
      layer(back, [4, 3, 5], ctx) + layer([C.bus(ctx)], [3], ctx) + layer(front, [1, 3, 2, 6], ctx) +
      petals(ctx) + '</svg>';
  }

  /** Pin position of a zone label, in % of the map box. */
  function pinPos(zone) {
    const p = P(zone.pin[0], zone.pin[1], zone.pin[2]);
    return { left: (p[0] / VB_W) * 100, top: (p[1] / VB_H) * 100 };
  }

  KT.cityMap = { render, pinPos, VB_W, VB_H };
})();