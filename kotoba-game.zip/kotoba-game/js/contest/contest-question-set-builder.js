/* Thi đấu — the shared question list. The host builds it once per match and sends it to every
   player, so everyone answers the same questions with the same options in the same order.
   Only quick single-answer types are used: no listening (not every device has a Japanese voice),
   no kana building and no pairing. Options come from KT.options with the city game's rules
   (one correct answer, unique labels, no confusable pairs), without the host's own progress. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;
  const SIZES = [10, 15, 20, 30];
  const WEIGHT = { meaning: 3, restore: 2, deliver: 1.5, deliverRev: 1.5, bus: 1.5, busRev: 1.5, clock: 2, clockRev: 2, calendar: 2, read: 1.5 };
  const SEASONS = ['spring', 'summer', 'autumn', 'winter'];
  /** "Địa điểm, di chuyển, học tập" -> "Địa điểm" for compact chips. */
  const shortGroup = (g) => String(KT.GROUPS[g] || g).split(',')[0];

  function eligible(groups) {
    const chosen = new Set((groups || []).filter((g) => KT.GROUPS[g]));
    return KT.WORDS.filter((w) => !chosen.size || chosen.has(w.g));
  }

  function pickType(w, prev, used, avoid) {
    const list = Object.keys(WEIGHT).filter((t) => KT.TYPES[t].ok(w)).map((t) => {
      let wt = WEIGHT[t] / (1 + (used[t] || 0) * 0.35);  // keep the mix varied
      if (t === prev) wt *= 0.2;                         // no long runs of one mechanic
      if (t === avoid) wt *= 0.1;                        // a repeated word comes back in another form
      return { item: t, w: wt };
    });
    return U.weighted(list) || 'meaning';
  }

  /** n question specs { t: type, w: answer id, m: label mode, o: option ids } from the chosen groups.
      Words repeat (in another form) only when the chosen groups hold fewer words than n. */
  function build(opts) {
    const o = opts || {};
    const n = SIZES.includes(Number(o.n)) ? Number(o.n) : 15;
    const pool = eligible(o.groups);
    const words = [];
    while (words.length < n && pool.length) {
      const batch = U.shuffle(pool);
      if (words.length && batch.length > 1 && batch[0] === words[words.length - 1]) batch.push(batch.shift());
      words.push(...batch);
    }
    const used = {}, lastType = {};
    let prev = null;
    return words.slice(0, n).map((w) => {
      const t = pickType(w, prev, used, lastType[w.id]);
      used[t] = (used[t] || 0) + 1; prev = t; lastType[w.id] = t;
      const opt = KT.options.forType(t, w, 4, { neutral: true });
      return { t, w: w.id, m: opt.mode, o: opt.words.map((x) => x.id) };
    });
  }

  const own = (obj, k) => typeof k === 'string' && Object.prototype.hasOwnProperty.call(obj, k);
  /** A received spec is usable on this device: known words, the answer exactly once among the options. */
  function valid(spec) {
    return !!(spec && own(WEIGHT, spec.t) && own(KT.WORD, spec.w) && Array.isArray(spec.o) && spec.o.length >= 2 && spec.o.length <= 6 &&
      spec.o.every((id) => own(KT.WORD, id)) && spec.o.filter((id) => id === spec.w).length === 1 && own(KT.options.LABEL, spec.m));
  }

  /** Question object for KT.challenges.choice — the same scene and options as in the city. */
  function toQuestion(spec, i) {
    const w = KT.WORD[spec.w];
    const q = { item: { id: w.id }, word: w, type: spec.t, zone: w.z, kind: 'choice', answered: false, assisted: false,
      variant: (i * 7 + w.id.length) % 9, options: spec.o.map((id) => KT.WORD[id]), mode: spec.m };
    if (q.zone === 5) q.season = w.season || ((KT.stage && KT.stage.SEASONS) || SEASONS)[i % 4];
    return q;
  }

  KT.contestQuestions = { SIZES, WEIGHT, shortGroup, eligible, build, valid, toQuestion };
})();