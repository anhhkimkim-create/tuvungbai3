/* Thi đấu — links between the host's browser (the room authority) and the players.
   Remote players use WebRTC data channels through PeerJS (vendored in js/vendor, loaded on
   first use; free public signalling server 0.peerjs.com with PeerJS's default STUN/TURN).
   The host's own player uses an in-memory local link. Every link carries plain JSON objects:
   { open, send(msg), close(), onMessage(fn), onClose(fn) }. */
(function () {
  'use strict';
  const KT = window.KT;
  const PREFIX = 'kotoba-bai3-';                          // namespace on the shared signalling server
  const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';  // no look-alikes (0/O, 1/I/L)
  const CODE_LEN = 5;
  const JOIN_TIMEOUT = 15000;
  const SELF = document.currentScript && document.currentScript.src;
  const vendorUrl = (file) => (SELF ? new URL('../vendor/' + file, SELF).href : 'js/vendor/' + file);
  const fail = (code, cause) => Object.assign(new Error(code), { code, cause });
  // Address discovery only. PeerJS's own free TURN relays (eu-0/us-0.turn.peerjs.com) no longer exist,
  // so relays come from js/contest/contest-turn-relay-config.js.
  const STUN = [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun.cloudflare.com:3478' }];
  const relays = () => (Array.isArray(KT.CONTEST_ICE_SERVERS) ? KT.CONTEST_ICE_SERVERS : [])
    .filter((s) => s && s.urls && [].concat(s.urls).some((u) => /^turns?:/.test(String(u))));
  /** True when a TURN relay is configured, i.e. players on other networks can reach the host. */
  const hasRelay = () => relays().length > 0;
  /** RTCPeerConnection settings for every peer; forceRelay (tests) proves that the relay path works on its own. */
  function iceConfig() {
    const cfg = { iceServers: STUN.concat(relays()) };
    if (KT.net && KT.net.forceRelay) cfg.iceTransportPolicy = 'relay';
    return cfg;
  }
  const safe = (fn, arg) => { try { fn(arg); } catch (e) { console.error('[contest]', e); } };

  function makeLink() {
    const onMsg = [], onEnd = [];
    const L = {
      open: true,
      send() {},
      close() {},
      onMessage(fn) { onMsg.push(fn); },
      onClose(fn) { onEnd.push(fn); },
      deliver(m) { if (L.open) onMsg.forEach((fn) => safe(fn, m)); },
      ended() { if (!L.open) return; L.open = false; onEnd.forEach((fn) => safe(fn)); },
    };
    return L;
  }

  /** Two connected in-memory ends; delivery is async and copies through JSON, like the network. */
  function localPair() {
    const a = makeLink(), b = makeLink();
    const wire = (from, to) => {
      from.send = (m) => {
        if (!from.open) return;
        const copy = JSON.stringify(m);
        setTimeout(() => to.deliver(JSON.parse(copy)), 0);
      };
      from.close = () => { if (!from.open) return; from.ended(); setTimeout(() => to.ended(), 0); };
    };
    wire(a, b); wire(b, a);
    return [a, b];
  }

  /* ---------- vendored libraries, loaded on demand ---------- */
  const loading = {};
  function loadVendor(file, globalName) {
    if (window[globalName]) return Promise.resolve(window[globalName]);
    if (!loading[file]) {
      loading[file] = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = vendorUrl(file);
        s.async = true;
        s.onload = () => (window[globalName] ? resolve(window[globalName]) : reject(fail('load')));
        s.onerror = () => { delete loading[file]; reject(fail('load')); };
        document.head.appendChild(s);
      });
    }
    return loading[file];
  }
  const loadPeer = () => loadVendor('peerjs.min.js', 'Peer');

  /** A PeerJS DataConnection (JSON serialization) as a link; `own` = this player's peer, destroyed with it. */
  function wrapConn(conn, own) {
    const L = makeLink();
    const drop = () => { if (own) { try { own.destroy(); } catch (e) { /* already gone */ } } L.ended(); };
    L.send = (m) => { try { if (conn.open) conn.send(m); } catch (e) { /* closing */ } };
    L.close = () => { try { conn.close(); } catch (e) { /* ignore */ } drop(); };
    conn.on('data', (d) => {
      let m = d;
      if (typeof d === 'string') { try { m = JSON.parse(d); } catch (e) { return; } }
      L.deliver(m);
    });
    conn.on('close', drop);
    conn.on('error', drop);
    return L;
  }

  const newCode = () => Array.from({ length: CODE_LEN }, () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)]).join('');
  const cleanCode = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, CODE_LEN);
  const validCode = (s) => { const c = cleanCode(s); return c.length === CODE_LEN && c.split('').every((ch) => CODE_CHARS.includes(ch)); };
  const errType = (e) => (e && e.type === 'browser-incompatible' ? 'browser' : e && e.type === 'peer-unavailable' ? 'not-found' : 'network');

  /** Register a new room code on the signalling server. onLink(link) fires for every player whose channel opens. */
  async function host(onLink, attempt) {
    const Peer = await loadPeer();
    const code = newCode();
    return new Promise((resolve, reject) => {
      let opened = false, closed = false;
      const peer = new Peer(PREFIX + code, { debug: 0, config: iceConfig() });
      const server = { code, close() { closed = true; try { peer.destroy(); } catch (e) { /* ignore */ } } };
      peer.on('open', () => { opened = true; resolve(server); });
      peer.on('connection', (conn) => conn.on('open', () => onLink(wrapConn(conn, null))));
      // Lost the signalling socket: players already in keep playing; re-register so new ones can still join.
      peer.on('disconnected', () => {
        if (!closed) setTimeout(() => { try { if (!closed && !peer.destroyed) peer.reconnect(); } catch (e) { /* next drop retries */ } }, 2000);
      });
      peer.on('error', (e) => {
        if (opened) return;                    // one player's failure never closes the room
        try { peer.destroy(); } catch (x) { /* ignore */ }
        if (e && e.type === 'unavailable-id' && (attempt || 0) < 4) host(onLink, (attempt || 0) + 1).then(resolve, reject);
        else reject(fail(errType(e), e));
      });
    });
  }

  /** Connect to a room as a player; resolves with a link once the data channel is open. */
  async function join(code) {
    const Peer = await loadPeer();
    return new Promise((resolve, reject) => {
      let settled = false;
      const peer = new Peer({ debug: 0, config: iceConfig() });
      const stop = (c, e) => {
        if (settled) return;
        settled = true; clearTimeout(timer);
        try { peer.destroy(); } catch (x) { /* ignore */ }
        reject(fail(c, e));
      };
      const timer = setTimeout(() => stop('timeout'), JOIN_TIMEOUT);
      peer.on('open', () => {
        const conn = peer.connect(PREFIX + cleanCode(code), { reliable: true, serialization: 'json' });
        conn.on('open', () => { if (settled) return; settled = true; clearTimeout(timer); resolve(wrapConn(conn, peer)); });
        conn.on('error', (e) => stop('connect', e));
      });
      peer.on('error', (e) => stop(errType(e), e));
    });
  }

  KT.net = { PREFIX, CODE_LEN, forceRelay: false, makeLink, localPair, loadVendor, loadPeer, host, join, newCode, cleanCode, validCode, hasRelay, iceConfig };
})();