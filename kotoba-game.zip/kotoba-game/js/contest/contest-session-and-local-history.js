/* Thi đấu — session glue for this device: its role in a room (host / player), creating and
   joining rooms, moving between the contest screens when the room changes phase, the player id
   and last-used name kept on this device, a short local match history, and keeping the screen
   awake. The host's page IS the room: leaving or reloading it closes the room for everyone. */
(function () {
  'use strict';
  const KT = window.KT;
  const KEY = 'kotoba-thi-dau-v1';
  const subs = new Set();
  const read = () => { try { return JSON.parse(window.localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } };
  let lock = null;

  /** Screen Wake Lock while in a room (best effort: unsupported or refused simply does nothing). */
  async function wake(on) {
    try {
      if (on && !lock && navigator.wakeLock && document.visibilityState === 'visible') {
        lock = await navigator.wakeLock.request('screen');
        lock.addEventListener('release', () => { lock = null; });
      } else if (!on && lock) { const l = lock; lock = null; await l.release(); }
    } catch (e) { lock = null; }
  }

  const X = (KT.contest = {
    role: null,        // 'host' | 'player' | null
    room: null,        // host: the room engine
    server: null,      // host: the signalling registration
    plays: false,      // host also plays (through a local link)
    joining: false,
    prefs: read(),     // { name, roomName, n, groups, plays, guard, history }
    client: null,
    save() { try { window.localStorage.setItem(KEY, JSON.stringify(X.prefs)); } catch (e) { /* storage blocked: memory only */ } },
    /** Player id per browser tab (sessionStorage): a reload keeps the seat, a second tab on the
        same device (host in one tab, player in another) is a different player. */
    pid() {
      if (X._pid) return X._pid;                       // tests give each simulated device its own id
      const KEY_PID = 'kotoba-thi-dau-pid';
      try { X._tab = X._tab || window.sessionStorage.getItem(KEY_PID); } catch (e) { /* storage blocked */ }
      if (!X._tab) {
        X._tab = 'p' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
        try { window.sessionStorage.setItem(KEY_PID, X._tab); } catch (e) { /* memory only */ }
      }
      return X._tab;
    },
    me: () => X.client.s,
    sub(fn) { subs.add(fn); return () => subs.delete(fn); },
    changed(kind) {
      subs.forEach((fn) => { try { fn(kind); } catch (e) { console.error('[contest ui]', e); } });
      route(kind);
    },

    /** Room code from an invite link: ?phong=K7P2Q (or #phong=K7P2Q). */
    codeFromUrl() {
      let raw = '';
      try { raw = new URLSearchParams(window.location.search).get('phong') || ''; } catch (e) { /* very old browser */ }
      if (!raw) { const m = /(?:^|[#&])phong=([A-Za-z0-9]+)/.exec(window.location.hash || ''); raw = m ? m[1] : ''; }
      return KT.net.validCode(raw) ? KT.net.cleanCode(raw) : '';
    },
    /** Shareable link to this page with the room code ('' when the game runs from a local file). */
    inviteLink(code) {
      const l = window.location;
      return /^https?:$/.test(l.protocol) ? l.origin + l.pathname + '?phong=' + code : '';
    },

    async create(o) {
      X.leaveRoom();
      let srv = null;
      srv = await KT.net.host((link) => { if (X.room && X.server === srv) X.room.attach(link); else link.close(); });
      Object.assign(X, { server: srv, role: 'host', plays: !!o.plays });
      X.room = KT.contestRoom.create({ code: srv.code, name: o.roomName, n: o.n, groups: o.groups, guard: o.guard,
        onChange: (k) => X.changed('host:' + k) });
      if (X.plays) {
        const pair = KT.net.localPair();
        X.room.attach(pair[0], true);
        X.joining = true;
        try { await X.client.join(srv.code, o.name, X.pid(), { link: pair[1], host: true }); }
        catch (e) { X.leaveRoom(); throw e; }
        finally { X.joining = false; }
      }
      wake(true);
      return X.room;
    },

    async join(code, name) {
      X.leaveRoom();
      X.role = 'player'; X.joining = true;
      try { await X.client.join(KT.net.cleanCode(code), name, X.pid()); }
      catch (e) { X.client.leave(true); X.role = null; throw e; }
      finally { X.joining = false; }
      X.prefs.name = KT.contestRoom.cleanName(name);
      X.save();
      wake(true);
    },

    leaveRoom() {
      if (X.client.s) X.client.leave(true);
      if (X.room) X.room.close();
      const srv = X.server;
      if (srv) setTimeout(() => srv.close(), 700);   // let the "closed" message reach the players first
      Object.assign(X, { room: null, server: null, role: null, plays: false });
      wake(false);
    },

    /** The contest screen that fits this device's current state. */
    screenFor() {
      if (X.role === 'host' && !X.plays && X.room) {
        const ph = X.room.phase;
        return ph === 'lobby' ? 'contestLobby' : ph === 'ended' ? 'contestRank' : 'contestPlay';
      }
      const s = X.me();
      if (!s || !X.role) return 'contest';
      return s.phase === 'ended' ? 'contestRank' : (s.phase === 'countdown' || s.phase === 'playing') ? 'contestPlay' : 'contestLobby';
    },
  });

  X.client = KT.contestClient.create({ onChange: (kind) => X.changed('client:' + kind) });

  function remember() {
    const s = X.me();
    const mine = s && s.board && s.board.find((r) => r.sid === s.sid);
    if (!mine) return;
    const list = (X.prefs.history || []).filter((h) => !(h.code === s.code && h.match === s.match));
    list.unshift({ at: Date.now(), code: s.code, match: s.match, room: s.room ? s.room.name : '', rank: mine.rank,
      total: s.board.length, score: mine.score, correct: mine.correct, n: s.n });
    X.prefs.history = list.slice(0, 6);
    X.save();
  }
  function bye(msg) {
    X.leaveRoom();
    KT.app.toast(msg, 4500);
    if (/^contest/.test(KT.app.screen || '')) KT.app.go('contest');
  }

  /** Follow the room: start -> race, end -> ranking, new match -> lobby, removed / closed -> hub. */
  function route(kind) {
    if (!KT.app || !KT.app.screen) return;
    const s = X.me();
    if (kind === 'client:start') KT.app.go('contestPlay');
    else if (kind === 'client:end') { remember(); KT.app.go('contestRank'); }
    else if (kind === 'client:lobby') {
      if (s && s.phase === 'lobby' && /^contest(Play|Rank)$/.test(KT.app.screen)) KT.app.go('contestLobby');
    } else if (kind === 'client:reject') {
      if (!X.joining) bye(s && s.error === 'kicked' ? 'Chủ phòng đã mời bạn ra khỏi phòng.' :
        s && s.error === 'started' ? 'Trận mới đã bắt đầu khi bạn mất kết nối. Chờ ván sau rồi vào lại nhé.' : 'Không vào lại được phòng.');
    } else if (kind === 'client:closed') {
      if (X.role === 'player') bye(s && s.error === 'lost' ? 'Mất kết nối với chủ phòng. Phòng có thể đã đóng.' : 'Chủ phòng đã đóng phòng.');
    } else if (kind === 'host:phase' && X.role === 'host' && !X.plays && X.room) {
      const ph = X.room.phase;
      if (ph === 'countdown') KT.app.go('contestPlay');
      else if (ph === 'ended') KT.app.go('contestRank');
      else if (ph === 'lobby') KT.app.go('contestLobby');
    }
  }

  // Reloading or closing the host's page would end the room for everyone: ask first.
  window.addEventListener('beforeunload', (e) => {
    if (X.role === 'host' && X.room && !X.room.closed) { e.preventDefault(); e.returnValue = ''; }
  });
  document.addEventListener('visibilitychange', () => { if (X.role && document.visibilityState === 'visible') wake(true); });
})();