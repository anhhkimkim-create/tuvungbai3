/* Thi đấu — points, ranking order, rank tiers and Mochi's comment for each tier.
   Correct answer: 100 points + up to 50 for speed (full bonus within 2 s, none after 8 s).
   Order: points, then correct answers, then finished before unfinished, then less time. */
(function () {
  'use strict';
  const KT = window.KT;
  const FAST_MS = 2000, SLOW_MS = 8000;

  function points(correct, ms) {
    if (!correct) return 0;
    const t = Number(ms);
    const f = Math.max(0, Math.min(1, (SLOW_MS - (isFinite(t) ? t : SLOW_MS)) / (SLOW_MS - FAST_MS)));
    return 100 + Math.round(50 * f);
  }

  /** Mochi's lines, word for word as the game's owner asked. */
  const TIERS = {
    top: { range: 'Top 1–5', label: 'Xuất khẩu vô tư', mood: 'happy', say: 'Bạn quá xuất sắc, xuất khẩu vô tư nha!' },
    mid: { range: 'Top 6–12', label: 'Bình thường', mood: '', say: 'Cũng bình thường thôi.' },
    ga: { range: 'Từ hạng 13', label: 'とり / gà', mood: 'sad', say: 'とり / gà' },
  };
  const tier = (rank) => (rank <= 5 ? 'top' : rank <= 12 ? 'mid' : 'ga');
  /** Speech-bubble markup: the Japanese とり gets Japanese typography. */
  const sayHTML = (k) => (k === 'ga' ? '<span class="jp" lang="ja">とり</span> / gà' : KT.util.esc(TIERS[k].say));

  function order(a, b) {
    return (b.score - a.score) || (b.correct - a.correct) || ((b.done ? 1 : 0) - (a.done ? 1 : 0)) ||
      ((a.timeMs || 0) - (b.timeMs || 0)) || ((a.sid || 0) - (b.sid || 0));
  }
  const rank = (rows) => rows.slice().sort(order).map((r, i) => Object.assign({}, r, { rank: i + 1, tier: tier(i + 1) }));

  /** A small paper-cut chicken for the "gà" tier (same palette as the city icons). */
  const CHICKEN = '<svg class="chicken" viewBox="0 0 64 64" aria-hidden="true" focusable="false">' +
    '<g stroke="#1F2350" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round">' +
    '<path d="M26 51v8M37 51v8M23 59h6M34 59h6" fill="none" stroke="#E9A23C"/>' +
    '<path d="M15 31l-8-7 2 10-6 1 10 6z" fill="#FFFBF3"/>' +
    '<ellipse cx="31" cy="39" rx="18" ry="14" fill="#FFFBF3"/>' +
    '<path d="M21 37q8-6 15 3q-8 7-15-3z" fill="#F8E6C4"/>' +
    '<circle cx="42" cy="23" r="9" fill="#FFFBF3"/>' +
    '<path d="M36 15q1-7 5-2q2-6 5 0q4-2 3 4" fill="#EF6A4C"/>' +
    '<path d="M50 22l7 3-7 3z" fill="#F9CF55"/>' +
    '<path d="M48 29q3 5-1 6q-3-3 1-6z" fill="#EF6A4C"/></g>' +
    '<circle cx="44.5" cy="21" r="1.9" fill="#1F2350"/></svg>';

  KT.contestRank = { FAST_MS, SLOW_MS, points, TIERS, tier, sayHTML, order, rank, CHICKEN };
})();