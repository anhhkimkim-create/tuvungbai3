/* Thi đấu — the room authority, running in the host's browser.
   Lobby: players join with a unique name; the host can remove someone (that device stays out).
   Start: one shared question list, a 3 s countdown, then everyone races at their own pace.
   End: 3 s after the first player answers the last question. With "chống bấm bừa" on, only a
   finisher with at least half the answers right starts that countdown. A match also ends as soon
   as every connected player is done, when the host ends it, or when time runs out (12 s per question:
   10 câu = 2 phút … 30 câu = 6 phút). Everyone then gets the same ranking. Player ids stay private:
   roster and ranking only carry seat numbers. */
(function () {
  'use strict';
  const KT = window.KT;
  const START_DELAY = 3000, END_DELAY = 3000, MAX_PLAYERS = 60, NAME_MAX = 20;
  /** Time limit of a match for n questions (KT.contestRoom.PER_QUESTION_MS is read each time, tests shorten it). */
  const limitFor = (n) => n * KT.contestRoom.PER_QUESTION_MS;
  const limitText = (n) => { const m = limitFor(n) / 60000; return (Number.isInteger(m) ? m : m.toFixed(1).replace('.', ',')) + ' phút'; };
  const strip = (s) => String(s == null ? '' : s).normalize('NFC').replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim();
  const cleanName = (s) => Array.from(strip(s)).slice(0, NAME_MAX).join('').trim();
  const nameKey = (s) => cleanName(s).toLocaleLowerCase('vi');
  const cleanRoom = (s) => Array.from(strip(s)).slice(0, 40).join('').trim() || 'Thi từ vựng Bài 3';
  const size = (n) => (KT.contestQuestions.SIZES.includes(Number(n)) ? Number(n) : 15);

  function create(opts) {
    const o = opts || {};
    const onChange = o.onChange || function () {};
    const timers = {}, banned = new Set(), hostLinks = new Set();
    let seq = 0;
    const R = {
      code: o.code, name: cleanRoom(o.name), n: size(o.n), groups: (o.groups || []).filter((g) => KT.GROUPS[g]),
      guard: o.guard !== false, phase: 'lobby', players: [], specs: null, startAt: 0, endAt: 0,
      ending: null, board: null, reason: '', match: 0, closed: false,
    };
    const info = () => ({ code: R.code, name: R.name, n: R.n, groups: R.groups, guard: R.guard, match: R.match,
      limit: R.specs ? R.limitMs : limitFor(R.n) });
    const roster = () => R.players.map((p) => ({ sid: p.sid, name: p.name, host: p.host, on: p.on }));
    const send = (p, m) => { if (p.link && p.link.open) p.link.send(m); };
    const broadcast = (m) => R.players.forEach((p) => send(p, m));
    const changed = (kind) => { try { onChange(kind); } catch (e) { console.error('[contest room]', e); } };
    const stopTimers = () => Object.keys(timers).forEach((k) => { clearTimeout(timers[k]); delete timers[k]; });
    const fresh = (p) => Object.assign(p, { answers: 0, correct: 0, score: 0, done: false, doneAt: 0, timeMs: 0 });
    const racing = () => R.phase === 'countdown' || R.phase === 'playing';
    const lobbyMsg = (extra) => Object.assign({ t: 'lobby', players: roster(), room: info() }, extra || {});
    const everyoneDone = () => { const on = R.players.filter((p) => p.on); return on.length > 0 && on.every((p) => p.done); };

    function raceFor(p) {
      if (!racing()) return null;
      const now = Date.now();
      return { specs: R.specs, idx: p.answers, score: p.score, correct: p.correct, startIn: Math.max(0, R.startAt - now),
        elapsed: Math.max(0, now - R.startAt), endIn: R.ending ? Math.max(0, R.endAt - now) : null, by: R.ending ? R.ending.name : '' };
    }
    function reject(link, reason) { link.send({ t: 'reject', reason }); setTimeout(() => link.close(), 400); }

    function hello(link, m) {
      const pid = String(m.pid || '').slice(0, 48), name = cleanName(m.name);
      if (pid && banned.has(pid)) { reject(link, 'kicked'); return; }
      if (!pid || !name) { reject(link, 'name-empty'); return; }
      let p = R.players.find((x) => x.pid === pid);
      // Someone racing keeps the name they started with; everyone else needs a free name.
      if (!(p && racing()) && R.players.some((x) => x !== p && nameKey(x.name) === nameKey(name))) { reject(link, 'name-taken'); return; }
      if (!p) {
        if (racing()) { reject(link, 'started'); return; }
        if (R.players.length >= MAX_PLAYERS) { reject(link, 'full'); return; }
        p = fresh({ pid, sid: ++seq, name, host: hostLinks.has(link), on: false, link: null });  // never trust a remote "host" claim
        R.players.push(p);
      } else if (!racing()) p.name = name;
      if (p.link && p.link !== link) { const old = p.link; p.link = null; old.close(); }  // same device, new connection
      p.link = link; p.on = true;
      send(p, { t: 'welcome', sid: p.sid, name: p.name, room: info(), phase: R.phase, players: roster(), race: raceFor(p),
        board: R.phase === 'ended' ? R.board : null, reason: R.reason, by: R.ending ? R.ending.name : '', n: R.specs ? R.specs.length : R.n });
      if (!racing()) broadcast(lobbyMsg());
      changed('roster');
    }

    function onMessage(link, m) {
      if (!m || typeof m !== 'object' || R.closed) return;
      if (m.t === 'hello') { hello(link, m); return; }
      const p = R.players.find((x) => x.link === link);
      if (!p) return;
      if (m.t === 'ans') answer(p, m);
      else if (m.t === 'bye') link.close();
    }
    function onClose(link) {
      if (R.closed) return;
      const p = R.players.find((x) => x.link === link);
      if (!p) return;
      p.link = null; p.on = false;
      if (!racing()) { R.players = R.players.filter((x) => x !== p); broadcast(lobbyMsg()); }
      else if (everyoneDone()) finish('all');
      changed('roster');
    }
    /** asHost: the host's own in-memory link (the only one allowed to hold the host seat). */
    function attach(link, asHost) {
      if (asHost) hostLinks.add(link);
      link.onMessage((m) => onMessage(link, m));
      link.onClose(() => { hostLinks.delete(link); onClose(link); });
    }

    function start() {
      if (R.phase !== 'lobby' || R.closed) return false;
      R.players = R.players.filter((p) => p.on);
      if (!R.players.length) return false;
      R.players.forEach(fresh);
      R.specs = KT.contestQuestions.build({ n: R.n, groups: R.groups });
      R.limitMs = limitFor(R.specs.length);
      R.match += 1;
      Object.assign(R, { phase: 'countdown', startAt: Date.now() + START_DELAY, ending: null, endAt: 0, board: null, reason: '' });
      broadcast({ t: 'start', specs: R.specs, in: START_DELAY, room: info() });
      timers.go = setTimeout(() => { R.phase = 'playing'; changed('phase'); }, START_DELAY);
      timers.time = setTimeout(() => finish('time'), START_DELAY + R.limitMs);
      changed('phase');
      return true;
    }

    function answer(p, m) {
      if (!racing() || p.done) return;
      const i = Number(m.i);
      if (i !== p.answers || !R.specs[i]) return;            // in order, once per question
      const ok = m.pick === R.specs[i].w;
      p.answers += 1;
      if (ok) p.correct += 1;
      p.score += KT.contestRank.points(ok, m.ms);
      p.timeMs = Math.max(0, Date.now() - R.startAt);
      if (p.answers === R.specs.length) finished(p);
      changed('progress');
    }
    function finished(p) {
      p.done = true; p.doneAt = p.timeMs;
      if (!R.ending && (!R.guard || p.correct * 2 >= R.specs.length)) {
        R.ending = { sid: p.sid, name: p.name };
        R.endAt = Date.now() + END_DELAY;
        broadcast({ t: 'ending', in: END_DELAY, by: p.name });
        timers.end = setTimeout(() => finish('first'), END_DELAY);
      }
      if (everyoneDone()) finish('all');
    }
    function finish(reason) {
      if (!racing()) return;
      stopTimers();
      R.phase = 'ended'; R.reason = reason;
      R.board = KT.contestRank.rank(R.players.map((p) => ({ sid: p.sid, name: p.name, score: p.score, correct: p.correct,
        answered: p.answers, done: p.done, timeMs: p.done ? p.doneAt : p.timeMs, host: p.host, off: !p.on })));
      broadcast({ t: 'end', board: R.board, n: R.specs.length, reason, by: R.ending ? R.ending.name : '', room: info() });
      changed('phase');
    }

    function kick(sid) {
      const p = R.players.find((x) => x.sid === Number(sid));
      if (!p || p.host) return false;
      banned.add(p.pid);
      R.players = R.players.filter((x) => x !== p);
      if (p.link) { const l = p.link; p.link = null; l.send({ t: 'reject', reason: 'kicked' }); setTimeout(() => l.close(), 400); }
      if (!racing()) broadcast(lobbyMsg());
      else if (everyoneDone()) finish('all');
      changed('roster');
      return true;
    }
    function setSize(n) {
      if (racing() || R.closed) return false;
      R.n = size(n);
      broadcast(lobbyMsg());
      changed('settings');
      return true;
    }
    function reset() {
      if (R.phase !== 'ended') return false;
      R.players = R.players.filter((p) => p.on).map(fresh);
      Object.assign(R, { phase: 'lobby', specs: null, board: null, ending: null, endAt: 0, reason: '' });
      broadcast(lobbyMsg({ reset: true }));
      changed('phase');
      return true;
    }
    function close() {
      if (R.closed) return;
      R.closed = true; stopTimers();
      broadcast({ t: 'closed' });
      const links = R.players.map((p) => p.link).filter(Boolean);
      setTimeout(() => links.forEach((l) => l.close()), 300);
      R.phase = 'closed';
      changed('phase');
    }
    /** Live view for a host who does not play: most answered first. */
    function progress() {
      return R.players.map((p) => ({ sid: p.sid, name: p.name, answered: p.answers, correct: p.correct, score: p.score, done: p.done, on: p.on, host: p.host }))
        .sort((a, b) => (b.answered - a.answered) || (b.correct - a.correct) || (a.sid - b.sid));
    }

    return Object.assign(R, { attach, start, kick, setSize, endNow: () => finish('host'), reset, close, roster, progress, info });
  }

  KT.contestRoom = { START_DELAY, END_DELAY, MAX_PLAYERS, NAME_MAX, PER_QUESTION_MS: 12000, limitText, cleanName, nameKey, create };
})();