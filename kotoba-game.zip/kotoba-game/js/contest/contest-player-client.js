/* Thi đấu — one player's side of a room (also the host's own player, over a local link).
   Joins with a name, follows the lobby, races through the shared questions and receives the
   final ranking. A dropped connection to a remote host retries by itself: the same player id
   gets the same seat back, and answers the host never received are sent again. */
(function () {
  'use strict';
  const KT = window.KT;
  const RETRY_MS = 2500, RETRIES = 8, LATE_MS = 600;
  const fail = (code) => Object.assign(new Error(code), { code });

  /* Everything a host sends is checked before use: plain numbers, short strings, known tiers. */
  const num = (v) => (isFinite(Number(v)) ? Number(v) : 0);
  const str = (v, max) => String(v == null ? '' : v).slice(0, max || 40);
  const objs = (list, max) => (Array.isArray(list) ? list.filter((x) => x && typeof x === 'object').slice(0, max) : []);
  const cleanRoom = (r, prev) => (r && typeof r === 'object' ? { code: KT.net.cleanCode(r.code), name: str(r.name), n: num(r.n),
    groups: Array.isArray(r.groups) ? r.groups.slice(0, 9).map((g) => str(g, 2)) : [], guard: !!r.guard, match: num(r.match),
    limit: num(r.limit) } : prev || null);
  const PHASES = ['lobby', 'countdown', 'playing', 'ended'];
  const cleanPlayers = (list) => objs(list, 80).map((p) => ({ sid: num(p.sid), name: str(p.name, 20), host: !!p.host, on: !!p.on }));
  const cleanBoard = (list) => objs(list, 80).map((r) => ({ sid: num(r.sid), name: str(r.name, 20), score: num(r.score), correct: num(r.correct),
    answered: num(r.answered), done: !!r.done, timeMs: num(r.timeMs), host: !!r.host, off: !!r.off, rank: num(r.rank), tier: KT.contestRank.tier(num(r.rank) || 99) }));

  /** hooks.onChange(kind) after every update; hooks.connect(code) -> Promise<link> (default: PeerJS). */
  function create(hooks) {
    const h = hooks || {};
    const connect = h.connect || ((code) => KT.net.join(code));
    const C = { s: null, link: null, tries: 0 };
    const notify = (kind) => { try { if (h.onChange) h.onChange(kind, C); } catch (e) { console.error('[contest client]', e); } };

    const blank = (code, name, pid, host) => ({ code, name, pid, host: !!host, sid: 0, phase: 'connecting', players: [], room: null,
      match: 0, specs: null, idx: 0, score: 0, correct: 0, sent: [], startLocal: 0, endLocal: 0, by: '', board: null, reason: '',
      n: 0, offline: false, error: '', wait: null });

    /** opts.link: an already open link (the host's own player); opts.host: marks the host's player. */
    C.join = function (code, name, pid, opts) {
      const o = opts || {};
      C.leave(true);
      const s = (C.s = blank(code, name, pid, o.host));
      return new Promise((resolve, reject) => {
        s.wait = { resolve, reject };
        if (o.link) use(s, o.link);
        else connect(code).then((l) => use(s, l), (e) => { if (C.s === s) C.s = null; settle(s, e && e.code ? e : fail('network')); });
      });
    };

    function use(s, link) {
      if (C.s !== s) { link.close(); return; }
      C.link = link;
      link.onMessage((m) => onMsg(s, link, m));
      link.onClose(() => lost(s, link));
      link.send({ t: 'hello', pid: s.pid, name: s.name, host: s.host, v: 1 });
    }
    function settle(s, error) {
      const w = s.wait;
      s.wait = null;
      if (w) { if (error) w.reject(error); else w.resolve(s); }
    }

    function onMsg(s, link, m) {
      if (C.s !== s || C.link !== link || !m || typeof m !== 'object') return;
      const now = Date.now();
      switch (m.t) {
        case 'welcome': welcome(s, link, m, now); break;
        case 'reject':
          s.phase = 'rejected'; s.error = String(m.reason || 'rejected');
          settle(s, fail(s.error));
          link.close();
          break;
        case 'lobby':
          s.players = cleanPlayers(m.players);
          s.room = cleanRoom(m.room, s.room);
          if (m.reset) Object.assign(s, { phase: 'lobby', specs: null, idx: 0, score: 0, correct: 0, sent: [], board: null, endLocal: 0, by: '', reason: '' });
          break;
        case 'start':
          Object.assign(s, { phase: 'countdown', specs: Array.isArray(m.specs) ? m.specs : [], idx: 0, score: 0, correct: 0, sent: [], board: null,
            reason: '', by: '', endLocal: 0, startLocal: now + num(m.in), room: cleanRoom(m.room, s.room), match: m.room ? num(m.room.match) : s.match + 1 });
          break;
        case 'ending': s.endLocal = now + num(m.in); s.by = str(m.by, 20); break;
        case 'end':
          Object.assign(s, { phase: 'ended', board: cleanBoard(m.board), reason: str(m.reason, 10), by: m.by ? str(m.by, 20) : s.by,
            n: num(m.n) || (s.specs ? s.specs.length : 0), endLocal: 0, room: cleanRoom(m.room, s.room) });
          break;
        case 'closed': s.phase = 'closed'; break;
        default: return;
      }
      notify(m.t);
    }

    /** First welcome, or a seat given back after a reconnect (the host's count of answers wins). */
    function welcome(s, link, m, now) {
      const r = m.race;
      const room = cleanRoom(m.room, s.room);
      const same = !!(r && s.specs && room && s.match === room.match);
      Object.assign(s, { sid: num(m.sid), name: str(m.name, 20) || s.name, room, players: cleanPlayers(m.players), phase: PHASES.includes(m.phase) ? m.phase : 'lobby',
        board: m.board ? cleanBoard(m.board) : null, reason: str(m.reason, 10), by: str(m.by, 20), n: num(m.n) || s.n, offline: false, error: '' });
      C.tries = 0;
      if (r && typeof r === 'object') {
        const idx = num(r.idx);
        if (same && s.idx > idx) s.sent.filter((a) => a.i >= idx).forEach((a) => link.send(Object.assign({ t: 'ans' }, a)));
        else if (same && s.idx < idx) Object.assign(s, { idx, score: num(r.score), correct: num(r.correct) });
        else if (!same) {
          Object.assign(s, { specs: Array.isArray(r.specs) ? r.specs : [], idx, score: num(r.score), correct: num(r.correct), sent: [],
            startLocal: num(r.startIn) ? now + num(r.startIn) : now - num(r.elapsed) });
        }
        s.match = room ? room.match : s.match;
        s.endLocal = r.endIn == null ? 0 : now + num(r.endIn);
        s.by = str(r.by, 20);
      }
      settle(s, null);
    }

    /** Record this player's answer for the current question; null when the match is already over. */
    C.answer = function (pick, ms) {
      const s = C.s;
      if (!s || !s.specs || !(s.phase === 'countdown' || s.phase === 'playing') || s.idx >= s.specs.length) return null;
      if (s.endLocal && Date.now() > s.endLocal + LATE_MS) return null;
      if (s.room && s.room.limit && Date.now() > s.startLocal + s.room.limit + LATE_MS) return null;   // time is up
      const i = s.idx, ok = pick === s.specs[i].w, pts = KT.contestRank.points(ok, ms);
      const a = { i, pick: String(pick == null ? '' : pick), ms: Math.max(0, Math.round(Number(ms) || 0)) };
      s.idx += 1; s.score += pts;
      if (ok) s.correct += 1;
      s.sent.push(a);
      if (C.link) C.link.send(Object.assign({ t: 'ans' }, a));
      return { ok, pts, done: s.idx >= s.specs.length };
    };
    C.racing = () => !!(C.s && C.s.specs && (C.s.phase === 'countdown' || C.s.phase === 'playing'));

    function lost(s, link) {
      if (C.s !== s || C.link !== link) return;
      C.link = null;
      if (s.phase === 'rejected') { notify('rejected'); return; }
      if (s.phase === 'connecting') { C.s = null; settle(s, fail('connect')); return; }
      if (s.host || s.phase === 'closed') { s.phase = 'closed'; notify('closed'); return; }
      s.offline = true;
      notify('offline');
      retry(s);
    }
    function retry(s) {
      if (C.s !== s) return;
      if (C.tries >= RETRIES) { s.phase = 'closed'; s.offline = false; s.error = 'lost'; notify('closed'); return; }
      C.tries += 1;
      setTimeout(() => {
        if (C.s !== s || C.link) return;
        connect(s.code).then((l) => use(s, l), () => retry(s));
      }, RETRY_MS);
    }

    /** Leave the room (tells the host, closes the connection). */
    C.leave = function (silent) {
      const s = C.s, l = C.link;
      C.s = null; C.link = null; C.tries = 0;
      if (s) settle(s, fail('left'));
      if (l) { l.send({ t: 'bye' }); setTimeout(() => l.close(), 150); }
      if (!silent && s) notify('left');
    };
    return C;
  }

  KT.contestClient = { RETRY_MS, RETRIES, LATE_MS, create };
})();