/* Thi đấu — MÁY CHUYỂN TIẾP (TURN) cho người chơi ở KHÁC MẠNG với chủ phòng (Wi-Fi ↔ 4G, nhà khác nhau…).
   Chưa điền thì phần thi đấu chỉ chạy khi mọi người dùng chung mạng với chủ phòng.

   Cách điền (miễn phí 20 GB mỗi tháng, thừa cho thi trắc nghiệm):
   1. Tạo tài khoản ở https://dashboard.metered.ca/signup
   2. Menu bên trái: TURN Server → Credentials → Create Credential → Create credential
   3. Ở dòng vừa tạo, bấm nút "ICE" để copy danh sách máy chủ
   4. Dán đè lên dấu [] ở dòng KT.CONTEST_ICE_SERVERS bên dưới (giữ dấu ; ở cuối), lưu file
   5. Đưa lại thư mục game lên Netlify
   Đã điền (Metered, vùng Global, tạo 12/11/2026). Đổi vùng hoặc tạo credential mới thì dán lại mảng mới.
   Thông tin này nằm công khai trong game (máy người chơi cần nó để kết nối) — đó là cách dùng bình thường. */
window.KT = window.KT || {};
window.KT.CONTEST_ICE_SERVERS = [
  { urls: 'stun:stun.relay.metered.ca:80' },
  { urls: 'turn:global.relay.metered.ca:80', username: '66e848745f14b0f62e2b1838', credential: 'Ywxx2bx6rb2NXkE9' },
  { urls: 'turn:global.relay.metered.ca:80?transport=tcp', username: '66e848745f14b0f62e2b1838', credential: 'Ywxx2bx6rb2NXkE9' },
  { urls: 'turn:global.relay.metered.ca:443', username: '66e848745f14b0f62e2b1838', credential: 'Ywxx2bx6rb2NXkE9' },
  { urls: 'turns:global.relay.metered.ca:443?transport=tcp', username: '66e848745f14b0f62e2b1838', credential: 'Ywxx2bx6rb2NXkE9' },
];
