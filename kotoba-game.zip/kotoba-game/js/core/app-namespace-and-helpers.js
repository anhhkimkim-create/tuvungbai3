/* KOTOBA — shared namespace, DOM helpers, tiny event bus, click-action delegation
   and Japanese text rendering (furigana). Classic scripts share window.KT so the
   game also runs straight from file:// without a dev server. */
(function () {
  'use strict';
  const KT = (window.KT = window.KT || {});
  KT.ui = KT.ui || {};
  KT.screens = KT.screens || {};
  KT.actions = KT.actions || {};

  const KANJI = /[\u3400-\u4dbf\u4e00-\u9fff\u3005]/;
  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  const U = (KT.util = {
    $: (sel, root) => (root || document).querySelector(sel),
    $$: (sel, root) => Array.from((root || document).querySelectorAll(sel)),
    esc: (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ESC[c]),
    hasKanji: (s) => KANJI.test(s || ''),
    clamp: (v, lo, hi) => Math.max(lo, Math.min(hi, v)),
    pct: (a, b) => (b ? Math.round((a / b) * 100) : 0),
    pick: (arr) => arr[Math.floor(Math.random() * arr.length)],
    shuffle(arr) {
      const a = arr.slice();
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    },
    /** Weighted random pick from [{ item, w }] (w > 0). */
    weighted(list) {
      const total = list.reduce((s, x) => s + x.w, 0);
      let r = Math.random() * total;
      for (const x of list) { r -= x.w; if (r <= 0) return x.item; }
      return list.length ? list[list.length - 1].item : null;
    },
    /** True when animations should be minimised (setting or OS preference). */
    calm() {
      const pref = KT.store && KT.store.S ? KT.store.S.settings.motion : 'auto';
      if (pref === 'reduce') return true;
      if (pref === 'full') return false;
      return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    },
    wait: (ms) => new Promise((res) => setTimeout(res, ms)),
  });

  /* ---------- tiny pub/sub ---------- */
  const subs = {};
  KT.on = (evt, fn) => { (subs[evt] = subs[evt] || []).push(fn); };
  KT.emit = (evt, data) => {
    (subs[evt] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });
  };

  /* ---------- click delegation: <button data-act="name" data-arg="x"> ---------- */
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled || el.getAttribute('aria-disabled') === 'true') return;
    const fn = KT.actions[el.dataset.act];
    if (!fn) return;
    e.preventDefault();
    try { fn(el, e); } catch (err) { console.error('[action ' + el.dataset.act + ']', err); }
  });

  /* ---------- Japanese text ---------- */
  const RUBY = /\{([^|}]+)\|([^}]+)\}/g;
  KT.jp = {
    /** Form shown inside quizzes (CD -> シーディー so the Latin letters do not give the answer away). */
    quiz: (w) => w.q || w.jp,
    /** Has a kanji reading worth showing. */
    hasReading: (w) => U.hasKanji(w.jp),
    /**
     * HTML for a word in Japanese. opts.quiz uses the quiz form; opts.hide drops the reading
     * (a challenge asking for that reading); opts.ruby true = reading always visible,
     * otherwise the "Hiện cách đọc" setting shows/hides it through the html.no-furi class.
     */
    html(w, opts) {
      const o = opts || {};
      const form = o.quiz ? w.q || w.jp : w.jp;
      if (!U.hasKanji(form) || o.ruby === false || o.hide) return '<span class="jp" lang="ja">' + U.esc(form) + '</span>';
      const src = form === w.jp && w.rb ? w.rb : '{' + form + '|' + w.kana + '}';
      let out = '', last = 0;
      src.replace(RUBY, (m, k, r, idx) => {
        out += U.esc(src.slice(last, idx)) + '<ruby>' + U.esc(k) + '<rt>' + U.esc(r) + '</rt></ruby>';
        last = idx + m.length;
        return m;
      });
      out += U.esc(src.slice(last));
      return '<span class="jp' + (o.ruby ? ' ruby-always' : '') + '" lang="ja">' + out + '</span>';
    },
    /** Plain text "学校 (がっこう)" for summaries. */
    plain(w) { return U.hasKanji(w.jp) || w.q ? w.jp + ' (' + w.kana + ')' : w.jp; },
  };
})();