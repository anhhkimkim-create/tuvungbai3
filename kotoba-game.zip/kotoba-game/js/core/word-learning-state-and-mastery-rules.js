/* Word learning states and the "Đã nhớ" rule.
   n = Chưa gặp · l = Đang học · r = Cần ôn · m = Đã nhớ
   Mastered = >= 3 counted correct answers, each in a DIFFERENT round, across >= 2
   challenge families. An answer right after the word card or after a mistake
   showed the answer (fewer than MIN_GAP questions later) never counts. */
(function () {
  'use strict';
  const KT = window.KT;
  const S = () => KT.store.S;

  const STATE_LABEL = { n: 'Chưa gặp', l: 'Đang học', r: 'Cần ôn', m: 'Đã nhớ' };
  const MIN_GAP = 3;
  const NEED_CREDITS = 3;
  const NEED_FAMILIES = 2;

  const learn = (KT.learn = {
    STATE_LABEL, MIN_GAP, NEED_CREDITS, NEED_FAMILIES,
    peek: (id) => KT.store.peek(id),

    /** Word card shown: the answer is now fresh in memory. */
    introduce(id) {
      const p = KT.store.word(id);
      p.in = 1;
      if (p.st === 'n') p.st = 'l';
      p.rv = S().turn;
    },

    /** A new question starts: advance the global turn counter. */
    tick() { S().turn += 1; return S().turn; },

    /**
     * Record one word's answer in the current question.
     * opts.assisted: hint used / sound switched to text -> correct but never a mastery credit.
     */
    record(id, fam, correct, opts) {
      const st = S(), p = KT.store.word(id), o = opts || {};
      const turn = st.turn;
      p.in = 1; p.lt = turn; p.lr = st.round;
      if (!correct) {
        p.w += 1; p.rv = turn; p.cr = []; p.st = 'r'; p.wr = st.round;
        return { credited: false, firstCorrect: false, becameMastered: false };
      }
      p.c += 1;
      const firstCorrect = !p.fr;
      if (firstCorrect) p.fr = st.round || 1;
      const fresh = turn - p.rv >= MIN_GAP;
      const newRound = !p.cr.some((c) => c[0] === st.round);
      let credited = false;
      if (fresh && newRound && !o.assisted) { p.cr.push([st.round, fam]); credited = true; }
      const before = p.st;
      if (p.st === 'n') p.st = 'l';
      if (p.st === 'r' && credited) p.st = 'l';
      if (learn.meetsMastery(p)) p.st = 'm';
      return { credited, firstCorrect, becameMastered: before !== 'm' && p.st === 'm' };
    },

    meetsMastery(p) {
      return p.cr.length >= NEED_CREDITS && new Set(p.cr.map((c) => c[1])).size >= NEED_FAMILIES;
    },
    families: (id) => Array.from(new Set(learn.peek(id).cr.map((c) => c[1]))),

    /* ---------- zone / overall progress ---------- */
    unlocked(zid) {
      const z = Number(zid);
      if (z === 1 || S().settings.unlockAll) return true;
      return (S().zones[z - 1] || { rounds: 0 }).rounds >= KT.UNLOCK_ROUNDS;
    },
    zoneStats(zid) {
      const ws = KT.zoneWords(zid);
      const r = { total: ws.length, met: 0, restored: 0, mastered: 0, review: 0 };
      ws.forEach((w) => {
        const p = learn.peek(w.id);
        if (p.in) r.met += 1;
        if (p.c > 0) r.restored += 1;
        if (p.st === 'm') r.mastered += 1;
        if (p.st === 'r') r.review += 1;
      });
      r.pct = KT.util.pct(r.restored, r.total);
      return r;
    },
    counts() {
      const c = { n: 0, l: 0, r: 0, m: 0 };
      KT.WORDS.forEach((w) => { c[learn.peek(w.id).st] += 1; });
      return c;
    },
    reviewWords() {
      return KT.WORDS.filter((w) => learn.peek(w.id).st === 'r')
        .sort((a, b) => learn.peek(b.id).w - learn.peek(a.id).w);
    },
    metWords: (filter) => KT.WORDS.filter((w) => learn.peek(w.id).in && (!filter || filter(w))),
  });
})();