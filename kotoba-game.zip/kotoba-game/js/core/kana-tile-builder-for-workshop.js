/* "Xưởng ghép chữ": splits a reading into kana tiles (small kana, ー, っ and
   dakuten stay exact), adds look-alike decoy tiles, and checks the answer.
   Long words use the curated chunks in the data (w.tiles). */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;
  const SMALL = 'ぁぃぅぇぉゃゅょゎァィゥェォャュョヮ';

  // Look-alike, dakuten and small/large confusions used to build decoys.
  const LOOK = {
    'あ': 'お', 'い': 'り', 'う': 'つ', 'え': 'ん', 'お': 'あ', 'か': 'が', 'が': 'か', 'き': 'ぎさ', 'ぎ': 'き',
    'く': 'ぐ', 'け': 'げ', 'げ': 'け', 'こ': 'ご', 'ご': 'こ', 'さ': 'ざち', 'し': 'じ', 'じ': 'し', 'す': 'ず',
    'ぜ': 'せ', 'た': 'だ', 'だ': 'た', 'ち': 'さ', 'つ': 'っ', 'っ': 'つ', 'て': 'で', 'で': 'て', 'と': 'ど',
    'ど': 'と', 'な': 'た', 'に': 'こ', 'ね': 'れわ', 'の': 'め', 'は': 'ばほ', 'ば': 'は', 'ひ': 'び',
    'び': 'ひ', 'ふ': 'ぶぷ', 'ぷ': 'ふぶ', 'へ': 'べ', 'べ': 'へ', 'ほ': 'ぼ', 'ま': 'も', 'み': 'む',
    'も': 'ま', 'ゃ': 'や', 'ゅ': 'ゆ', 'ょ': 'よ', 'よ': 'ょ', 'ら': 'ち', 'り': 'い', 'る': 'ろ', 'れ': 'ね',
    'ろ': 'る', 'わ': 'ね', 'ん': 'そ',
    'ア': 'マ', 'イ': 'ィ', 'ィ': 'イ', 'ウ': 'ゥ', 'ガ': 'カ', 'キ': 'ギ', 'ク': 'ケ', 'ケ': 'ク', 'コ': 'ゴ',
    'ゴ': 'コ', 'サ': 'ザ', 'シ': 'ツ', 'ジ': 'シ', 'ス': 'ズ', 'ズ': 'ス', 'タ': 'ダ', 'ダ': 'タ', 'チ': 'テ',
    'ツ': 'ッシ', 'ッ': 'ツ', 'テ': 'デ', 'デ': 'テ', 'ト': 'ド', 'ニ': 'ミ', 'ネ': 'ヌ', 'バ': 'ハパ',
    'パ': 'バ', 'ビ': 'ピ', 'ブ': 'プ', 'ベ': 'ペ', 'ム': 'ア', 'ャ': 'ヤ', 'ュ': 'ユ', 'ル': 'レ', 'レ': 'ル',
    'ン': 'ソ', 'ー': 'ウ', 'ホ': 'ボ', 'ラ': 'ヲ', 'ゥ': 'ウ',
  };

  /** Tiles that join exactly into w.kana. */
  function split(w) {
    if (w.tiles) return w.tiles.slice();
    const chars = Array.from(w.kana);
    if (chars.length <= 6) return chars;
    const units = [];
    chars.forEach((c) => {
      if (SMALL.includes(c) && units.length) units[units.length - 1] += c;
      else units.push(c);
    });
    const out = [];
    for (let i = 0; i < units.length; i += 2) out.push(units.slice(i, i + 2).join(''));
    return out;
  }

  /** Decoy tiles: one look-alike substitution each, never equal to a real tile. */
  function decoys(tiles, count) {
    const real = new Set(tiles);
    const out = [];
    for (const i of U.shuffle(tiles.map((_, k) => k))) {
      if (out.length >= count) break;
      const chars = Array.from(tiles[i]);
      const spots = U.shuffle(chars.map((_, k) => k)).filter((k) => LOOK[chars[k]]);
      for (const k of spots) {
        const alt = U.pick(Array.from(LOOK[chars[k]]));
        const cand = chars.slice(0, k).concat(alt, chars.slice(k + 1)).join('');
        if (!real.has(cand) && !out.includes(cand)) { out.push(cand); break; }
      }
    }
    return out;
  }

  /** Accepts the reading or any listed variant (おさけ/さけ, じゅっぷん/じっぷん). */
  const check = (w, text) => text === w.kana || (w.alt || []).includes(text);

  KT.tiles = {
    split, decoys, check, LOOK,
    /** Full tile set for a word: [{ id, text, real }], shuffled. */
    build(w) {
      const real = split(w);
      const extra = decoys(real, real.length <= 2 ? 3 : 2);
      const all = real.map((t) => ({ text: t, real: true })).concat(extra.map((t) => ({ text: t, real: false })));
      return { answer: real, tiles: U.shuffle(all).map((t, i) => Object.assign({ id: 't' + i }, t)) };
    },
  };
})();