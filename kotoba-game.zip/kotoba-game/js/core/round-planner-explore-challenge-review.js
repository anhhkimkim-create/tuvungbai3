/* Round planner — short rounds of 8–10 challenges.
   Explore  : a few new words (word card + first question, then a spaced repeat
              >= 3 questions later) mixed with review words, unseen words first.
   Challenge: only words already met, no cards, optional countdown.
   Review   : words marked "Cần ôn" (most mistakes first).
   Each item gets a challenge type that rotates within the zone's mechanics. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;
  const BASE = 8;   // planned challenges
  const MAX = 10;   // with re-queued mistakes
  const S = () => KT.store.S;
  const P = (id) => KT.store.peek(id);
  const met = (w) => !!P(w.id).in;

  // Recognition-type questions, preferred right after a word card.
  const EASY = { meaning: 1, deliver: 1, bus: 1, listen: 1, clock: 1, calendar: 1 };

  function priority(w) {
    const p = P(w.id);
    const since = S().turn - (p.lt || 0);
    let s;
    if (p.st === 'r') s = 1000 + p.w * 25 + since;          // needs review: most mistakes first
    else if (p.st === 'l') s = 500 - p.cr.length * 70 + since * 3;
    else s = 60 + since;                                    // mastered: occasional refresh
    return s + Math.random() * 40;
  }
  const ranked = (list) => list.map((w) => ({ w, s: priority(w) }))
    .sort((a, b) => b.s - a.s).map((x) => x.w);

  /** Place intros at 0,2,4…, their repeats >= 3 questions later, reviews in between. */
  function schedule(newIds, reviewIds, total) {
    const pending = [];
    newIds.forEach((id, i) => {
      pending.push({ id, intro: true, ready: i * 2 });
      pending.push({ id, seq: 1, ready: i * 2 + 3 });
    });
    reviewIds.forEach((id) => pending.push({ id, review: true, ready: 0 }));
    const out = [], first = {};
    while (out.length < total && pending.length) {
      const pos = out.length, prev = out[pos - 1];
      const ok = (it) => (!prev || prev.id !== it.id) &&
        (it.seq !== 1 || (first[it.id] !== undefined && pos - first[it.id] >= 3));
      const pick =
        pending.find((it) => it.seq === 1 && it.ready <= pos && ok(it)) ||
        pending.find((it) => it.intro && it.ready <= pos && ok(it)) ||
        pending.find((it) => it.review && ok(it)) ||
        pending.find((it) => it.intro && ok(it)) ||
        pending.find((it) => ok(it)) ||
        pending.find((it) => (!prev || prev.id !== it.id) && (it.seq !== 1 || first[it.id] !== undefined));
      if (!pick) break;
      pending.splice(pending.indexOf(pick), 1);
      if (pick.intro) first[pick.id] = pos;
      out.push({ id: pick.id, intro: !!pick.intro, seq: pick.seq || 0 });
    }
    return out;
  }

  function chooseType(w, zone, it, ctx, prev, used, avoidFam) {
    const credited = new Set(P(w.id).cr.map((c) => c[1]));
    const ok = Object.keys(KT.TYPES).filter((t) => KT.TYPES[t].ok(w, ctx));
    let list = ok.filter((t) => zone.types[t]).map((t) => ({ item: t, w: zone.types[t] }));
    if (!list.length) list = ok.filter((t) => t !== 'match').map((t) => ({ item: t, w: 1 }));
    list.forEach((x) => {
      const fam = KT.TYPES[x.item].fam;
      if (x.item === prev) x.w *= 0.15;                 // rotate mechanics
      if ((used[x.item] || 0) >= 2) x.w *= 0.45;
      if (it.intro) x.w *= EASY[x.item] ? 2.5 : 0.3;
      else if (!credited.has(fam)) x.w *= 2;            // aim for a new family (mastery needs 2)
      if (avoidFam && fam === avoidFam) x.w *= 0.3;
    });
    return U.weighted(list);
  }

  function matePool(w) {
    const metList = KT.learn.metWords((x) => x.id !== w.id);
    let pool = metList.filter((x) => x.k === w.k);
    if (pool.length < 3) pool = pool.concat(metList.filter((x) => x.z === w.z && x.k !== w.k));
    return KT.options.companions(w, 3, pool);
  }

  const zoneFor = (round, it) => round.zone || KT.WORD[it.id].z;

  function finish(round) {
    const ctx = { speech: !!(KT.speech && KT.speech.ok()), allowMatch: false };
    const used = {}, famOf = {};
    let prev = null, matchUsed = false;
    round.items.forEach((it) => {
      const w = KT.WORD[it.id];
      const mates = !matchUsed && !it.intro && !it.seq ? matePool(w) : [];
      ctx.allowMatch = mates.length >= 3;
      it.zone = zoneFor(round, it);
      it.type = chooseType(w, KT.zoneOf(it.zone), it, ctx, prev, used, famOf[it.id]);
      if (it.type === 'match') { it.mates = mates.slice(0, 3).map((x) => x.id); matchUsed = true; }
      used[it.type] = (used[it.type] || 0) + 1;
      famOf[it.id] = KT.TYPES[it.type].fam;
      prev = it.type;
    });
    round.planned = round.items.length;
    return round;
  }

  function explore(zid) {
    const z = Number(zid), zone = KT.zoneOf(z);
    const home = KT.zoneWords(z);
    const unseen = home.filter((w) => !met(w));
    const own = z === 6 ? KT.WORDS.filter(met) : home.filter(met);
    const extra = KT.WORDS.filter((w) => met(w) && !own.includes(w));
    let nNew = Math.min(unseen.length, zone.newPer);
    const need = () => Math.max(0, BASE - nNew * 2);
    let rev = ranked(own).slice(0, need());
    if (rev.length >= 3 && extra.length) rev = rev.slice(0, rev.length - 1).concat(ranked(extra).slice(0, 1));
    if (rev.length < need()) rev = rev.concat(ranked(extra.filter((w) => !rev.includes(w))).slice(0, need() - rev.length));
    while (nNew * 2 + rev.length < BASE && nNew < unseen.length) nNew += 1;
    rev = rev.slice(0, need());
    const fresh = unseen.slice(0, nNew).map((w) => w.id);
    const items = schedule(fresh, rev.map((w) => w.id), BASE);
    return finish({ mode: 'explore', zone: z, newIds: fresh, items });
  }

  function challenge(zid) {
    const z = Number(zid);
    const pool = (z === 6 ? KT.WORDS : KT.zoneWords(z)).filter(met);
    if (pool.length < 4) return null;
    const order = ranked(pool);
    const n = Math.min(MAX, Math.max(BASE, order.length));
    const items = [];
    for (let i = 0; items.length < n; i++) items.push({ id: order[i % order.length].id, intro: false, seq: 0 });
    return finish({ mode: 'challenge', zone: z, newIds: [], items, timer: S().settings.timer });
  }

  /** Wrong words first; short lists are filled with the weakest met words, then spaced repeats. */
  function review(onlyIds) {
    const wrong = onlyIds && onlyIds.length ? onlyIds.map((id) => KT.WORD[id]).filter(Boolean) : KT.learn.reviewWords();
    if (!wrong.length) return null;
    let list = ranked(wrong).slice(0, BASE);
    if (list.length < BASE) {
      const others = KT.WORDS.filter((w) => met(w) && !list.includes(w));
      list = list.concat(ranked(others.filter((w) => P(w.id).st !== 'm')), ranked(others.filter((w) => P(w.id).st === 'm'))).slice(0, BASE);
    }
    const items = list.map((w) => ({ id: w.id, intro: false, seq: 0 }));
    for (let i = 0; list.length >= 2 && items.length < Math.min(BASE, list.length * 2); i++) {
      items.push({ id: list[i % list.length].id, intro: false, seq: 0 });
    }
    return finish({ mode: 'review', zone: 0, newIds: [], items });
  }

  /** After a mistake: ask the word again >= 2 questions later, in another form. Retries never count for mastery. */
  function requeue(round, idx, id, failedType) {
    const later = round.items.slice(idx + 1).find((x) => x.id === id);
    if (later) { later.retry = true; return true; }   // its planned repeat becomes the retry
    if (round.items.length >= MAX) return false;
    if (round.items.length - idx - 1 < 2) return false;
    const it = { id, intro: false, seq: 0, retry: true };
    it.zone = zoneFor(round, it);
    const ctx = { speech: !!(KT.speech && KT.speech.ok()), allowMatch: false };
    const fam = KT.TYPES[failedType] ? KT.TYPES[failedType].fam : null;
    it.type = chooseType(KT.WORD[id], KT.zoneOf(it.zone), it, ctx, failedType, {}, fam);
    round.items.splice(Math.min(idx + 3, round.items.length), 0, it);
    return true;
  }

  KT.planner = { BASE, MAX, schedule, explore, challenge, review, requeue, chooseType };
})();