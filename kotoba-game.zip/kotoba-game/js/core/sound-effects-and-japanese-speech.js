/* Audio: tiny synthesized sound effects (WebAudio, no files) and Japanese
   speech through speechSynthesis. Speech is used ONLY when a ja-* voice exists —
   never another language's voice. Nothing plays before the player taps. */
(function () {
  'use strict';
  const KT = window.KT;

  const sfx = (KT.sfx = {
    ctx: null,
    ensure() {
      try {
        if (!this.ctx) {
          const AC = window.AudioContext || window.webkitAudioContext;
          if (!AC) return null;
          this.ctx = new AC();
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
      } catch (e) { this.ctx = null; }
      return this.ctx;
    },
    tone(f, t0, dur, type, vol) {
      const c = this.ctx;
      const o = c.createOscillator(), g = c.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(f, t0);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.12, t0 + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(c.destination);
      o.start(t0); o.stop(t0 + dur + 0.02);
    },
    play(name) {
      if (!KT.store.S.settings.sound) return;
      const c = this.ensure();
      if (!c) return;
      const t = c.currentTime + 0.01;
      try {
        if (name === 'ok') { this.tone(659, t, 0.16); this.tone(988, t + 0.09, 0.26); }
        else if (name === 'bad') { this.tone(246, t, 0.22, 'triangle', 0.1); this.tone(196, t + 0.12, 0.28, 'triangle', 0.09); }
        else if (name === 'tap') { this.tone(880, t, 0.05, 'sine', 0.05); }
        else if (name === 'tile') { this.tone(523, t, 0.07, 'triangle', 0.06); }
        else if (name === 'win') { [523, 659, 784, 1047].forEach((f, i) => this.tone(f, t + i * 0.1, 0.32, 'sine', 0.1)); }
        else if (name === 'unlock') { [392, 523, 659, 784, 1047].forEach((f, i) => this.tone(f, t + i * 0.07, 0.4, 'triangle', 0.08)); }
        else if (name === 'tick') { this.tone(1200, t, 0.03, 'square', 0.025); }
      } catch (e) { /* audio is optional */ }
    },
  });

  const speech = (KT.speech = {
    supported: typeof window !== 'undefined' && 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window,
    voice: null,
    init() {
      if (!this.supported) return;
      const load = () => {
        let list = [];
        try { list = window.speechSynthesis.getVoices() || []; } catch (e) { list = []; }
        const ja = list.filter((v) => /^ja([-_]|$)/i.test(v.lang || ''));
        const had = !!this.voice;
        this.voice = ja.find((v) => v.localService) || ja[0] || null;
        if (had !== !!this.voice) KT.emit('voices');
      };
      load();
      try { window.speechSynthesis.addEventListener('voiceschanged', load); } catch (e) { /* old browsers */ }
    },
    ok() { return !!this.voice; },
    name() { return this.voice ? this.voice.name : ''; },
    /** Speak Japanese text. Returns false (and calls onError) when no Japanese voice exists. */
    say(text, onEnd, onError) {
      if (!this.ok()) { if (onError) onError('novoice'); return false; }
      try {
        window.speechSynthesis.cancel();
        const u = new window.SpeechSynthesisUtterance(text);
        u.voice = this.voice;
        u.lang = this.voice.lang;
        u.rate = 0.85;
        u.onend = () => onEnd && onEnd();
        u.onerror = (e) => onError && onError(e && e.error);
        window.speechSynthesis.speak(u);
        return true;
      } catch (e) { if (onError) onError('fail'); return false; }
    },
    sayWord(w, onEnd, onError) { return this.say(w.tts || w.kana, onEnd, onError); },
  });
  sfx.speech = speech;
})();