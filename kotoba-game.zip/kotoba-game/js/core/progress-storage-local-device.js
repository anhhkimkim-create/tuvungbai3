/* Progress persistence on this device (localStorage, no login).
   Every storage access is wrapped in try/catch: when storage is blocked
   (private window, disabled site data) the game keeps working in memory and
   the UI warns that progress will not survive a reload. */
(function () {
  'use strict';
  const KT = window.KT;
  const KEY = 'kotoba-thanh-pho-ky-uc-v1';

  const defaults = () => ({
    v: 1,
    started: false,
    turn: 0,        // global question counter, used by spacing rules
    round: 0,       // global round counter
    score: 0,
    shards: 0,      // "mảnh ký ức"
    lastSeason: '',
    settings: { sound: true, motion: 'auto', furigana: true, theme: 'auto', timer: 20, unlockAll: false },
    zones: {},      // { [zoneId]: { rounds, best } }
    words: {},      // { [wordId]: progress, see newWord() }
  });

  /** in: introduced, c/w: right/wrong count, rv: turn the answer was last shown,
      lt/lr: last turn/round seen, cr: mastery credits [round, family], st: n|l|r|m,
      fr: round of first correct answer (object restored), wr: round of last mistake */
  const newWord = () => ({ in: 0, c: 0, w: 0, rv: -99, lt: 0, lr: 0, cr: [], st: 'n', fr: 0, wr: 0 });
  const EMPTY = Object.freeze(Object.assign(newWord(), { cr: Object.freeze([]) }));

  function merge(data) {
    const base = defaults();
    const out = Object.assign(base, data);
    out.settings = Object.assign(defaults().settings, data.settings || {});
    out.zones = data.zones && typeof data.zones === 'object' ? data.zones : {};
    out.words = {};
    Object.keys(data.words || {}).forEach((id) => {
      if (KT.WORD[id]) out.words[id] = Object.assign(newWord(), data.words[id]);
    });
    return out;
  }

  const store = (KT.store = {
    S: defaults(),
    persistent: true,
    load() {
      let raw = null;
      try { raw = window.localStorage.getItem(KEY); } catch (e) { this.persistent = false; }
      if (raw) {
        try {
          const data = JSON.parse(raw);
          if (data && data.v === 1) this.S = merge(data);
        } catch (e) { console.warn('[kotoba] save file unreadable, starting fresh', e); }
      }
      try {
        window.localStorage.setItem(KEY + '-probe', '1');
        window.localStorage.removeItem(KEY + '-probe');
      } catch (e) { this.persistent = false; }
      return this.S;
    },
    save() {
      if (!this.persistent) return false;
      try {
        window.localStorage.setItem(KEY, JSON.stringify(this.S));
        return true;
      } catch (e) {
        this.persistent = false;
        KT.emit('storage-failed');
        return false;
      }
    },
    /** Wipe learning progress, keep the player's settings. */
    reset() {
      const settings = Object.assign({}, this.S.settings);
      this.S = defaults();
      this.S.settings = settings;
      try { window.localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
      this.save();
    },
    zone(id) {
      return this.S.zones[id] || (this.S.zones[id] = { rounds: 0, best: 0 });
    },
    /** Progress record for a word (created on first write). */
    word(id) {
      return this.S.words[id] || (this.S.words[id] = newWord());
    },
    /** Read-only view that never creates a record. */
    peek(id) {
      return this.S.words[id] || EMPTY;
    },
  });
  store.KEY = KEY;
})();