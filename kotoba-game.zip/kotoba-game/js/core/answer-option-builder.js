/* Answer options for single-answer questions. Guarantees (covered by tests):
   exactly one correct option, unique visible labels, no confusable pair
   (KT.confusable), no accepted variant of the answer shown as a wrong option,
   and no option that sounds the same as the answer in sound-only questions. */
(function () {
  'use strict';
  const KT = window.KT;
  const U = KT.util;

  /** Visible label per option mode — duplicates are detected on these strings. */
  const LABEL = {
    vi: (w) => w.vi,              // Vietnamese meaning button
    jp: (w) => w.q || w.jp,       // Japanese word / sign / tag
    kana: (w) => w.kana,          // reading only
    card: (w) => w.vi,            // illustration + Vietnamese caption
  };

  const seen = (w) => (KT.store.peek(w.id).in ? 1 : 0);

  /**
   * Distractor words for `answer`.
   * opts.mode   label mode (vi | jp | kana | card)
   * opts.pools  pool order, default: own pool -> fallback pools -> everything
   * opts.filter extra eligibility test for a distractor word
   * opts.neutral do not prefer words this player already met (shared contest questions)
   */
  function distractors(answer, n, opts) {
    const o = opts || {};
    const label = LABEL[o.mode || 'vi'];
    const taken = new Set([label(answer)].concat(answer.alt || []));
    const pools = o.pools || [answer.k].concat(KT.POOL_FALLBACK[answer.k] || [], ['*']);
    const out = [];
    for (const pool of pools) {
      if (out.length >= n) break;
      let cands = U.shuffle(KT.WORDS.filter((w) =>
        w.id !== answer.id &&
        (pool === '*' || w.k === pool) &&
        !KT.confusable(answer.id, w.id) &&
        (!o.filter || o.filter(w))
      ));
      if (!o.neutral) cands = cands.sort((a, b) => seen(b) - seen(a)); // stable: words already met come first
      for (const w of cands) {
        if (out.length >= n) break;
        const text = label(w);
        if (taken.has(text)) continue;
        if ((w.alt || []).some((a) => taken.has(a))) continue;
        if (out.some((x) => x.id === w.id || KT.confusable(x.id, w.id))) continue;
        taken.add(text);
        out.push(w);
      }
    }
    return out;
  }

  /** Per challenge type: label mode + pool rules. */
  const RULES = {
    meaning: () => ({ mode: 'vi' }),
    lantern: () => ({ mode: 'vi' }),
    restore: () => ({ mode: 'jp' }),
    deliver: () => ({ mode: 'card', filter: (w) => KT.TYPES.deliver.ok(w) }),
    deliverRev: () => ({ mode: 'jp' }),
    bus: () => ({ mode: 'card', pools: ['place'] }),
    busRev: () => ({ mode: 'jp', pools: ['place'] }),
    clock: (a) => ({ mode: 'kana', pools: [a.k] }),
    clockRev: (a) => ({ mode: a.k === 'weekday' ? 'vi' : 'card', pools: [a.k] }),
    calendar: () => ({ mode: 'jp', pools: ['weekday'] }),
    read: () => ({ mode: 'kana', filter: (w) => U.hasKanji(w.jp) }),
    listen: (a) => ({ mode: 'card', filter: (w) => w.kana !== a.kana }),
  };

  KT.options = {
    LABEL, distractors, RULES,
    /** Shuffled option words (answer included) for a challenge type; `extra` adds options such as { neutral: true }. */
    forType(type, answer, n, extra) {
      const rule = Object.assign((RULES[type] || RULES.meaning)(answer), extra || {});
      const opts = U.shuffle([answer].concat(distractors(answer, (n || 4) - 1, rule)));
      return { mode: rule.mode, words: opts };
    },
    /** Companion words for a pairing challenge (no confusable pairs, unique labels). */
    companions(anchor, count, poolWords) {
      const out = [anchor];
      const vi = new Set([anchor.vi]), jp = new Set([KT.jp.quiz(anchor)]);
      for (const w of U.shuffle(poolWords)) {
        if (out.length > count) break;
        if (out.some((x) => x.id === w.id || KT.confusable(x.id, w.id))) continue;
        if (vi.has(w.vi) || jp.has(KT.jp.quiz(w))) continue;
        vi.add(w.vi); jp.add(KT.jp.quiz(w));
        out.push(w);
      }
      return out.slice(1);
    },
  };
})();