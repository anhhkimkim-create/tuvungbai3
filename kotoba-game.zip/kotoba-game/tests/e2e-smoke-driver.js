/* End-to-end smoke test: drives the real UI in headless Chrome and prints a report.
   chrome --headless=new --window-size=390,844 --virtual-time-budget=120000 --dump-dom tests/e2e-smoke-test.html */
(async function () {
  const KT = window.KT, $ = (s) => document.querySelector(s), $$ = (s) => Array.from(document.querySelectorAll(s));
  const out = [], fails = [];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const check = (c, m) => { if (!c) fails.push(m); };
  const click = async (sel) => {
    const el = typeof sel === 'string' ? $(sel) : sel;
    if (!el) throw new Error('missing element ' + sel);
    el.click(); await sleep(25);
  };
  const overflow = (where) => { const w = document.documentElement.scrollWidth, v = window.innerWidth; if (w > v + 1) fails.push('horizontal overflow on ' + where + ': ' + w + ' > ' + v); };
  const typesSeen = {};

  async function playRound(label, wrongEvery) {
    let n = 0, guard = 0;
    const total = KT.play.round.items.length;
    if (KT.play.round.mode === 'review') check(total >= 2 && total <= 10, label + ': review length ' + total);
    else check(total >= 8 && total <= 10, label + ': planned length ' + total);
    while (KT.app.screen === 'play' && guard++ < 60) {
      await sleep(20);
      if ($('[data-act="introDone"]')) { overflow(label + ' intro'); await click('[data-act="introDone"]'); continue; }
      const fb = $('#play-feedback');
      if (fb && !fb.hidden) { await click('[data-act="nextQuestion"]'); continue; }
      const q = KT.play.q;
      if (!q) { fails.push(label + ': no question'); break; }
      typesSeen[q.type] = (typesSeen[q.type] || 0) + 1;
      n++;
      overflow(label + ' ' + q.type);
      const wrong = wrongEvery && n % wrongEvery === 0;
      if (q.kind === 'choice') {
        const btns = $$('[data-opt]');
        check(btns.filter((b) => b.dataset.opt === q.word.id).length === 1, label + ': exactly one correct option ' + q.word.id);
        const texts = btns.map((b) => (b.querySelector('.opt-text, .opt-cap') || b).textContent.trim());
        check(new Set(texts).size === texts.length, label + ': duplicate option labels ' + texts.join('|'));
        if (q.type === 'read') check(!$('.prompt-jp.kanji rt'), 'reading visible before answering ' + q.word.id);
        const stg = $('.stage').getBoundingClientRect(), ob = $('.stage-object').getBoundingClientRect();
        const bub = $('.bubble');
        if (bub) {
          const bb = bub.getBoundingClientRect();
          check(bb.left >= stg.left - 1 && bb.right <= stg.right + 1 && bb.top >= stg.top - 1, label + ': bubble outside stage ' + q.type + ' ' + q.word.id + ' ' + Math.round(bb.left) + '..' + Math.round(bb.right) + ' top ' + Math.round(bb.top - stg.top));
          const ix = Math.max(0, Math.min(bb.right, ob.right) - Math.max(bb.left, ob.left)), iy = Math.max(0, Math.min(bb.bottom, ob.bottom) - Math.max(bb.top, ob.top));
          check(ix * iy < 0.1 * ob.width * ob.height, label + ': bubble covers the object ' + q.word.id);
        }
        $$('.prompt-jp, .prompt-vi, .opt').forEach((el) => check(el.scrollWidth <= el.clientWidth + 2, label + ': text overflows ' + el.className + ' ' + q.word.id));
        if (q.type === 'listen') check(KT.speech.ok(), 'listen scheduled without a Japanese voice');
        await click(wrong ? btns.find((b) => b.dataset.opt !== q.word.id) : btns.find((b) => b.dataset.opt === q.word.id));
      } else if (q.kind === 'workshop') {
        if (wrong) {
          const decoy = q.ws.tiles.find((t) => !t.real) || q.ws.tiles[0];
          await click('[data-tile="' + decoy.id + '"]');
        } else {
          const free = q.ws.tiles.filter((t) => t.real);
          for (const txt of q.ws.answer) { const t = free.find((x) => x.text === txt); free.splice(free.indexOf(t), 1); await click('[data-tile="' + t.id + '"]'); }
        }
        await click('[data-ws="check"]');
      } else if (q.kind === 'match') {
        for (const w of q.set) {
          if (wrong && w === q.set[0]) { await click('.m-card.side-L[data-id="' + w.id + '"]'); await click('.m-card.side-R[data-id="' + q.set[1].id + '"]'); }
          await click('.m-card.side-L[data-id="' + w.id + '"]'); await click('.m-card.side-R[data-id="' + w.id + '"]');
        }
      }
      await sleep(20);
      check(!$('#play-feedback').hidden, label + ': feedback after ' + q.type);
      if (!$('#play-feedback').hidden && !q.answered) fails.push(label + ': q not marked answered');
    }
    check(KT.app.screen === 'result', label + ': ended on result screen (got ' + KT.app.screen + ')');
    overflow(label + ' result');
    out.push(label + ': ' + n + ' questions, ' + KT.play.round.correct + ' correct');
  }

  try {
    await sleep(200);
    // Generated SVG must never contain NaN / undefined / unreplaced {xx} palette placeholders.
    const bad = (s) => /NaN|undefined|\{[a-z0-9]{1,3}\}/.test(s);
    check(!bad(KT.cityMap.render()), 'city map markup has NaN/undefined/placeholder');
    KT.WORDS.forEach((w) => check(!bad(KT.icons.forWord(w)), 'icon markup broken for ' + w.id + ' (' + w.ic + ')'));
    Object.keys(KT.ICON_SRC).forEach((k) => check(!bad(KT.icons.svg(k)), 'icon source broken ' + k));
    [1, 2, 3, 4, 5, 6].forEach((z) => check(!bad(KT.stage.backdrop(z)), 'stage backdrop broken ' + z));
    for (let i = 0; i < 9; i++) check(!bad(KT.sprites.person(i)), 'person sprite broken ' + i);
    check(!bad(KT.sprites.cat()), 'cat sprite broken');
    out.push('art markup checked: map, ' + KT.WORDS.length + ' word pictures, ' + Object.keys(KT.ICON_SRC).length + ' icons, 6 scenes');
    check(!!$('.start .title-k'), 'start title');
    check(!!$('.start svg.city-map'), 'start city illustration');
    check($('[data-act="continueJourney"]').disabled, 'continue disabled without save');
    overflow('start');
    await click('[data-act="startJourney"]');
    for (let i = 0; i < 3; i++) { check(KT.app.screen === 'story', 'story panel ' + i); await click('[data-act="storyNext"]'); }
    check(KT.app.screen === 'map', 'map after story');
    check($$('.pin').length === 6, 'six zone pins');
    check($$('.mobj.ghost').length > 20, 'faded objects at start: ' + $$('.mobj.ghost').length);
    overflow('map');

    await click('[data-act="playZone"][data-arg="1"]');
    await playRound('Z1 round 1', 4);
    check($$('.res-block').length === 3, 'three result blocks');
    const reviewBtn = $('[data-act="reviewWrong"]');
    if (reviewBtn && !reviewBtn.disabled) { await click(reviewBtn); if (KT.app.screen === 'play') await playRound('Review', 0); }
    await click('[data-act="go"][data-arg="map"]');
    await click('[data-act="playZone"][data-arg="1"]');
    await playRound('Z1 round 2', 5);
    check(KT.learn.unlocked(2), 'zone 2 unlocked after two rounds');
    check(!!$('.unlock-banner'), 'unlock banner shown');

    KT.store.S.settings.unlockAll = true;
    for (const z of [2, 3, 4, 5, 6, 4, 6]) {
      KT.app.go('map');
      await click('[data-act="selectZone"][data-arg="' + z + '"]');
      await click('[data-act="playZone"][data-arg="' + z + '"]');
      await playRound('Z' + z, 5);
    }

    // Challenge with timer: answer once, then let the timer run out.
    KT.store.S.settings.timer = 10;
    KT.app.go('map');
    await click('[data-act="selectZone"][data-arg="4"]');
    await click('[data-act="challengeZone"][data-arg="4"]');
    check(KT.app.screen === 'play' && KT.play.round.mode === 'challenge', 'challenge started');
    check(!$('#play-timer').hidden, 'timer visible');
    await sleep(21000);
    check(/Hết giờ/.test($('#play-feedback').textContent), 'timeout feedback');
    await click('[data-act="nextQuestion"]');
    await playRound('Challenge', 0);

    // Notebook
    KT.app.go('notebook');
    check($$('.nb-row').length === 111, 'notebook lists 111 rows: ' + $$('.nb-row').length);
    await click('[data-act="nbGroup"][data-arg="E"]');
    check($$('.nb-row').length === 7, 'group E has 7 rows');
    await click('[data-act="nbGroup"][data-arg="all"]');
    const inp = $('#nb-q'); inp.value = 'さくら'; inp.dispatchEvent(new Event('input')); await sleep(300);
    check($$('.nb-row').length >= 1, 'search finds さくら');
    inp.value = ''; inp.dispatchEvent(new Event('input')); await sleep(300);
    await click('[data-act="nbState"][data-arg="m"]');
    out.push('mastered after test play: ' + $$('.nb-row').length);
    await click('[data-act="nbState"][data-arg="all"]');
    await click('[data-act="wordDetail"]');
    check(!!$('.dialog-box .wc-jp'), 'word detail dialog');
    await click('.dialog-box [data-dlg="0"]');
    overflow('notebook');

    KT.app.go('review'); overflow('review');
    KT.app.go('settings'); overflow('settings');
    await click('[data-act="setValue"][data-key="theme"][data-arg="dark"]');
    check(document.documentElement.getAttribute('data-theme') === 'dark', 'dark theme applied');
    await click('[data-act="setToggle"][data-arg="furigana"]');
    check(document.documentElement.classList.contains('no-furi'), 'furigana hidden class');
    await click('[data-act="setValue"][data-key="motion"][data-arg="reduce"]');
    check(document.documentElement.classList.contains('calm'), 'calm mode');
    KT.app.go('map'); overflow('map dark calm');
    KT.app.go('settings');
    await click('[data-act="askReset"]');
    await click('.dialog-box [data-dlg="1"]');
    check(KT.app.screen === 'start' && !KT.store.S.started && KT.store.S.score === 0, 'reset returns to start with empty progress');
    check(KT.store.S.settings.theme === 'dark', 'settings kept after reset');
  } catch (e) {
    fails.push('EXCEPTION ' + e.message + '\n' + e.stack);
  }
  const errs = window.__errors || [];
  out.unshift((fails.length || errs.length ? 'E2E: FAIL' : 'E2E: PASS') + ' · viewport ' + window.innerWidth + 'px · types seen ' + JSON.stringify(typesSeen));
  document.getElementById('out').textContent = out.concat(fails.map((f) => 'FAIL ' + f), errs.map((e) => 'JS ' + e)).join('\n');
})();