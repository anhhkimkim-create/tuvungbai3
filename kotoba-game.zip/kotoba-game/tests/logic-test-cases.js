/* Logic tests run in headless Chrome: chrome --headless=new --dump-dom tests/logic-tests.html */
(function () {
  const KT = window.KT;
  const lines = [];
  let pass = 0, fail = 0;
  const ok = (cond, msg) => { if (cond) pass++; else { fail++; if (fail < 60) lines.push('FAIL ' + msg); } };
  const fresh = () => { KT.store.persistent = false; KT.store.reset(); };
  const run = (name, fn) => { try { fn(); } catch (e) { fail++; lines.push('ERROR in ' + name + ': ' + e.message + '\n' + e.stack); } };
  KT.speech.voice = null;

  run('data', () => {
    ok(KT.WORDS.length === 111, 'expected 111 words, got ' + KT.WORDS.length);
    const ids = new Set(KT.WORDS.map((w) => w.id));
    ok(ids.size === KT.WORDS.length, 'duplicate ids');
    const per = {};
    KT.WORDS.forEach((w) => { per[w.g] = (per[w.g] || 0) + 1; });
    const want = { A: 14, B: 16, C: 14, D: 21, E: 7, F: 12, G: 10, H: 11, I: 6 };
    Object.keys(want).forEach((g) => ok(per[g] === want[g], 'group ' + g + ' count ' + per[g]));
    const inZone = {};
    KT.ZONES.forEach((z) => z.order.forEach((id) => {
      ok(!!KT.WORD[id], 'zone ' + z.id + ' unknown id ' + id);
      ok(!inZone[id], 'id in two zones ' + id);
      inZone[id] = z.id;
      ok(KT.WORD[id] && KT.WORD[id].z === z.id, 'zone mismatch ' + id);
    }));
    KT.WORDS.forEach((w) => {
      ok(inZone[w.id], 'word not reachable in any zone ' + w.id);
      ok(w.jp && w.kana && w.vi && w.g && w.k && w.ic, 'missing field ' + w.id);
      ok(KT.POOL_FALLBACK[w.k] !== undefined, 'unknown pool ' + w.k);
      if (w.tiles) ok(w.tiles.join('') === w.kana, 'tiles do not join ' + w.id);
    });
    const vi = new Set(KT.WORDS.map((w) => w.vi));
    ok(vi.size === 111, 'duplicate VI meanings');
    const jp = new Set(KT.WORDS.map((w) => KT.jp.quiz(w)));
    ok(jp.size === 111, 'duplicate JP quiz forms');
    const kana = {};
    KT.WORDS.forEach((w) => { (kana[w.kana] = kana[w.kana] || []).push(w.id); });
    Object.keys(kana).forEach((k) => {
      if (kana[k].length > 1) ok(kana[k].every((a) => kana[k].every((b) => a === b || KT.confusable(a, b))), 'homophones not excluded ' + kana[k]);
    });
    ok(KT.WORD.hi_fire.nl && KT.WORD.hi_sun.nl, '火/日 must never be sound-only');
  });

  run('options', () => {
    fresh();
    const types = ['meaning', 'restore', 'deliver', 'deliverRev', 'bus', 'busRev', 'clock', 'clockRev', 'calendar', 'read', 'listen'];
    let made = 0, short = [];
    KT.WORDS.forEach((w) => types.forEach((t) => {
      if (!KT.TYPES[t].ok(w, { speech: true, allowMatch: false })) return;
      for (let i = 0; i < 25; i++) {
        const r = KT.options.forType(t, w, 4);
        made++;
        const labels = r.words.map(KT.options.LABEL[r.mode]);
        ok(r.words.filter((x) => x.id === w.id).length === 1, t + ' answer count ' + w.id);
        ok(new Set(labels).size === labels.length, t + ' duplicate labels ' + w.id + ' ' + labels);
        if (r.words.length < 4 && short.indexOf(t + ':' + w.id) < 0) short.push(t + ':' + w.id);
        ok(r.words.length >= 3, t + ' fewer than 3 options ' + w.id);
        r.words.forEach((x) => {
          if (x.id === w.id) return;
          ok(!KT.confusable(w.id, x.id), t + ' confusable pair ' + w.id + '/' + x.id);
          ok(!(w.alt || []).includes(KT.options.LABEL[r.mode](x)), t + ' variant as distractor ' + w.id);
          if (t === 'listen') ok(x.kana !== w.kana, 'listen homophone ' + w.id);
          if (t === 'read' || t === 'clock') ok(x.kana !== w.kana, t + ' same reading ' + w.id + '/' + x.id);
        });
      }
    }));
    ok(made > 5000, 'too few option sets generated: ' + made);
    lines.push('info: option sets generated = ' + made + (short.length ? ' · <4 options: ' + short.join(', ') : ' · all have 4 options'));
  });

  run('tiles', () => {
    KT.WORDS.forEach((w) => {
      if (!KT.TYPES.workshop.ok(w)) return;
      for (let i = 0; i < 20; i++) {
        const b = KT.tiles.build(w);
        ok(b.answer.join('') === w.kana, 'tiles join ' + w.id);
        const real = b.tiles.filter((t) => t.real).map((t) => t.text);
        const fake = b.tiles.filter((t) => !t.real).map((t) => t.text);
        ok(real.length === b.answer.length, 'real tile count ' + w.id);
        fake.forEach((f) => ok(!b.answer.includes(f), 'decoy equals real tile ' + w.id + ' ' + f));
        ok(KT.tiles.check(w, w.kana), 'check reading ' + w.id);
      }
      (w.alt || []).forEach((a) => ok(KT.tiles.check(w, a), 'variant accepted ' + w.id + ' ' + a));
    });
    ok(!KT.TYPES.workshop.ok(KT.WORD.fun), '分 excluded from workshop');
    ok(KT.tiles.check(KT.WORD.juppun, 'じっぷん') && KT.tiles.check(KT.WORD.juppun, 'じゅっぷん'), '十分 both readings');
    ok(!KT.tiles.check(KT.WORD.gyuunyuu, 'ぎゆうにゆう'), 'small ゅ must be exact');
  });

  run('mastery', () => {
    fresh();
    const L = KT.learn, S = KT.store.S;
    S.round = 1; L.introduce('uchi'); L.tick();
    let r = L.record('uchi', 'B', true);
    ok(!r.credited, 'answer right after card must not count');
    L.tick(); L.tick(); L.tick();
    r = L.record('uchi', 'B', true);
    ok(r.credited, 'spaced answer should count');
    L.tick(); L.tick(); L.tick();
    r = L.record('uchi', 'A', true);
    ok(!r.credited, 'second credit in same round must not count');
    S.round = 2; L.tick(); L.tick(); L.tick(); L.record('uchi', 'B', true);
    S.round = 3; L.tick(); L.tick(); L.tick(); L.record('uchi', 'B', true);
    ok(L.peek('uchi').st !== 'm', 'one family only must not master');
    S.round = 4; L.tick(); L.tick(); L.tick(); L.record('uchi', 'C', true);
    ok(L.peek('uchi').st === 'm', 'three rounds + two families should master');
    L.tick(); L.record('uchi', 'C', false);
    ok(L.peek('uchi').st === 'r' && L.peek('uchi').cr.length === 0, 'wrong answer -> Cần ôn, credits reset');
    L.tick(); L.tick(); L.tick();
    r = L.record('uchi', 'A', true, { assisted: true });
    ok(!r.credited && L.peek('uchi').st === 'r', 'assisted/retry answer must not count');
  });

  run('planner', () => {
    fresh();
    const S = KT.store.S;
    S.settings.unlockAll = true;
    const r = KT.planner.explore(1);
    ok(r.items.length === 8, 'first round length ' + r.items.length);
    ok(r.newIds.length === 4, 'first round new words ' + r.newIds.length);
    r.newIds.forEach((id) => {
      const pos = r.items.map((it, i) => (it.id === id ? i : -1)).filter((i) => i >= 0);
      ok(r.items[pos[0]].intro, 'intro first for ' + id);
      ok(pos.length >= 2 && pos[1] - pos[0] >= 3, 'spaced repeat for ' + id + ' ' + pos);
    });
    // Simulate many rounds in every zone with random answers: every word must appear.
    const seenIds = new Set();
    for (let n = 0; n < 160; n++) {
      const z = (n % 6) + 1;
      const round = n % 9 === 8 ? KT.planner.review() || KT.planner.explore(z) : KT.planner.explore(z);
      S.round += 1;
      for (let i = 0; i < round.items.length; i++) {
        const it = round.items[i], w = KT.WORD[it.id];
        ok(KT.TYPES[it.type] && KT.TYPES[it.type].ok(w, { speech: false, allowMatch: it.type === 'match' }), 'type not allowed ' + it.type + ' ' + it.id);
        if (i > 0) ok(round.items[i - 1].id !== it.id || it.retry, 'adjacent duplicate ' + it.id);
        if (it.intro) KT.learn.introduce(it.id);
        KT.learn.tick();
        const good = Math.random() < 0.75;
        KT.learn.record(it.id, KT.TYPES[it.type].fam, good, { assisted: !!it.retry });
        (it.mates || []).forEach((m) => KT.learn.record(m, 'F', true));
        if (!good) KT.planner.requeue(round, i, it.id, it.type);
        seenIds.add(it.id);
        ok(round.items.length <= KT.planner.MAX, 'round too long');
        const p = KT.learn.peek(it.id);
        if (p.st === 'm') ok(new Set(p.cr.map((c) => c[0])).size >= 3 && new Set(p.cr.map((c) => c[1])).size >= 2, 'mastery invariant ' + it.id);
      }
      KT.store.zone(round.zone || 1).rounds += 1;
    }
    const missing = KT.WORDS.filter((w) => !seenIds.has(w.id)).map((w) => w.id);
    ok(missing.length === 0, 'words never scheduled: ' + missing.join(','));
    const c = KT.learn.counts();
    lines.push('info: after 160 simulated rounds -> ' + JSON.stringify(c));
    const ch = KT.planner.challenge(4);
    ok(ch && ch.items.length >= 8 && ch.items.every((it) => !it.intro), 'challenge round');
  });

  run('matching', () => {
    KT.WORDS.forEach((w) => {
      const mates = KT.options.companions(w, 3, KT.WORDS.filter((x) => x.k === w.k && x.id !== w.id));
      const set = [w].concat(mates);
      set.forEach((a) => set.forEach((b) => { if (a !== b) ok(!KT.confusable(a.id, b.id), 'match confusable ' + a.id + '/' + b.id); }));
      ok(new Set(set.map((x) => x.vi)).size === set.length, 'match duplicate vi ' + w.id);
    });
  });

  lines.unshift((fail ? 'RESULT: FAIL' : 'RESULT: PASS') + ' — ' + pass + ' passed, ' + fail + ' failed');
  document.getElementById('out').textContent = lines.join('\n');
})();