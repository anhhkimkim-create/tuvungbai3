/* Thi đấu logic tests — a tiny async harness shared by the case files. Cases run in order and the
   report goes to #out: chrome --headless=new --allow-file-access-from-files --virtual-time-budget=120000
   --dump-dom tests/contest-logic-tests.html */
(function () {
  const lines = [];
  let pass = 0, fail = 0;
  const T = (window.CTEST = {
    cases: [],
    ok(c, m) { if (c) pass++; else { fail++; if (fail < 80) lines.push('FAIL ' + m); } },
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
    add(name, fn) { T.cases.push({ name, fn }); },
    async runAll() {
      for (const c of T.cases) {
        try { await c.fn(); } catch (e) { fail++; lines.push('ERROR in ' + c.name + ': ' + e.message + '\n' + e.stack); }
      }
      lines.unshift((fail ? 'RESULT: FAIL' : 'RESULT: PASS') + ' — ' + pass + ' passed, ' + fail + ' failed');
      document.getElementById('out').textContent = lines.join('\n');
    },
  });
  window.KT.store.persistent = false;
})();