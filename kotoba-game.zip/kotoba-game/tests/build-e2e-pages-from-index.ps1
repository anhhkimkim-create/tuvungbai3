﻿# Rebuilds the end-to-end pages from index.html: ../ paths, an error collector that also clears
# saved progress, and a driver (e2e-smoke-test.html: the city game; e2e-contest-ui-test.html:
# Thi đấu screens offline). Run after adding or renaming scripts in index.html:
#   powershell -ExecutionPolicy Bypass -File tests/build-e2e-pages-from-index.ps1
$root = Split-Path -Parent $PSScriptRoot
$t = [IO.File]::ReadAllText((Join-Path $root 'index.html'), [Text.Encoding]::UTF8).Replace("`r`n", "`n")
$t = $t.Replace('href="css/', 'href="../css/').Replace('src="js/', 'src="../js/')
$collector = "<script>window.__errors=[];window.addEventListener('error',function(e){window.__errors.push('error: '+e.message+' @'+String(e.filename||'').split('/').pop()+':'+e.lineno)});window.addEventListener('unhandledrejection',function(e){window.__errors.push('promise: '+(e.reason&&e.reason.message||e.reason))});try{localStorage.clear()}catch(e){}</script>"
$i = $t.IndexOf('<script src="../js/')
$t = $t.Insert($i, $collector + "`n")
foreach ($page in @(@('e2e-smoke-test.html', 'e2e-smoke-driver.js'), @('e2e-contest-ui-test.html', 'e2e-contest-ui-driver.js'))) {
  $out = '<pre id="out" style="position:fixed;top:0;left:0;z-index:999;background:#fff;color:#000;max-height:40vh;overflow:auto;font-size:11px">running</pre>' + "`n" + '<script src="' + $page[1] + '"></script>' + "`n</body>"
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot $page[0]), $t.Replace('</body>', $out), [Text.UTF8Encoding]::new($false))
  'rebuilt tests/' + $page[0]
}