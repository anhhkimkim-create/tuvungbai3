/* Thi đấu logic tests, part 1: shared question lists (one answer, unique labels, no confusable pairs,
   chosen groups only, every word reachable), points, tiers and Mochi's lines, names and room codes,
   relay (TURN) settings, the time limit, and hostile messages from a host being cleaned before use. */
(function () {
  const KT = window.KT, U = KT.util, T = window.CTEST, ok = T.ok, sleep = T.sleep;

  T.add('question lists', () => {
    const keys = Object.keys(KT.GROUPS), seen = new Set();
    for (let k = 0; k < 400; k++) {
      const n = KT.contestQuestions.SIZES[k % 4];
      const groups = k % 4 === 0 ? [] : U.shuffle(keys).slice(0, 1 + (k % 3));
      const specs = KT.contestQuestions.build({ n, groups });
      ok(specs.length === n, 'length ' + specs.length + ' for n=' + n + ' groups ' + groups);
      specs.forEach((sp, i) => {
        seen.add(sp.w);
        ok(KT.contestQuestions.valid(sp), 'invalid spec ' + JSON.stringify(sp));
        ok(sp.o.length === 4, 'four options for ' + sp.w + ' got ' + sp.o.length);
        ok(['listen', 'workshop', 'match'].indexOf(sp.t) < 0 && KT.contestQuestions.WEIGHT[sp.t], 'type not allowed ' + sp.t);
        ok(KT.TYPES[sp.t].ok(KT.WORD[sp.w], {}), 'type does not fit ' + sp.t + ' ' + sp.w);
        const label = KT.options.LABEL[sp.m];
        const labels = sp.o.map((id) => label(KT.WORD[id]));
        ok(new Set(labels).size === labels.length, 'duplicate labels ' + labels.join('|'));
        sp.o.forEach((a) => sp.o.forEach((b) => { if (a !== b) ok(!KT.confusable(a, b), 'confusable pair ' + a + '/' + b); }));
        const wrongLabels = sp.o.filter((id) => id !== sp.w).map((id) => label(KT.WORD[id]));
        (KT.WORD[sp.w].alt || []).forEach((alt) => ok(!wrongLabels.includes(alt), 'accepted variant shown as wrong option ' + sp.w));
        if (groups.length) ok(groups.includes(KT.WORD[sp.w].g), 'word outside chosen groups ' + sp.w);
        if (i) ok(specs[i - 1].w !== sp.w, 'same word twice in a row ' + sp.w);
        const q = KT.contestQuestions.toQuestion(sp, i);
        ok(q.word.id === sp.w && q.options.length === 4 && q.kind === 'choice' && q.options.some((w) => w.id === sp.w), 'question object ' + sp.w);
      });
    }
    ok(seen.size === KT.WORDS.length, 'every word can come up: ' + seen.size + '/' + KT.WORDS.length);
    ok(!KT.contestQuestions.valid({ t: 'listen', w: 'umi', m: 'card', o: ['umi', 'kouen'] }), 'listening never accepted');
    ok(!KT.contestQuestions.valid({ t: 'meaning', w: 'umi', m: 'vi', o: ['kouen', 'gakkou'] }), 'answer must be among the options');
  });

  T.add('points and tiers', () => {
    const P = KT.contestRank.points;
    ok(P(true, 500) === 150 && P(true, 2000) === 150, 'full speed bonus');
    ok(P(true, 8000) === 100 && P(true, 60000) === 100, 'no bonus when slow');
    ok(P(true, 5000) === 125, 'half bonus at 5 s');
    ok(P(false, 100) === 0, 'wrong answer = 0');
    ok(P(true, NaN) === 100 && P(true, -5) === 150, 'odd times are safe');
    const rows = Array.from({ length: 15 }, (_, i) => ({ sid: i + 1, name: 'P' + i, score: 2000 - i * 10, correct: 10, done: true, timeMs: 1000 }));
    const r = KT.contestRank.rank(U.shuffle(rows));
    ok(r.map((x) => x.sid).join() === rows.map((x) => x.sid).join(), 'sorted by points');
    r.forEach((x) => ok(x.tier === (x.rank <= 5 ? 'top' : x.rank <= 12 ? 'mid' : 'ga'), 'tier at rank ' + x.rank));
    const tie = KT.contestRank.rank([
      { sid: 1, score: 500, correct: 4, done: false, timeMs: 9000 }, { sid: 2, score: 500, correct: 5, done: false, timeMs: 9000 },
      { sid: 3, score: 500, correct: 5, done: true, timeMs: 9500 }, { sid: 4, score: 500, correct: 5, done: true, timeMs: 8000 },
    ]);
    ok(tie.map((x) => x.sid).join() === '4,3,2,1', 'tie-breaks correct > finished > time: ' + tie.map((x) => x.sid).join());
    ok(KT.contestRank.TIERS.top.say === 'Bạn quá xuất sắc, xuất khẩu vô tư nha!', 'top 1–5 line');
    ok(KT.contestRank.TIERS.mid.say === 'Cũng bình thường thôi.', 'top 6–12 line');
    ok(KT.contestRank.TIERS.ga.say === 'とり / gà', 'rank 13+ line');
    ok(KT.contestRank.tier(5) === 'top' && KT.contestRank.tier(6) === 'mid' && KT.contestRank.tier(12) === 'mid' && KT.contestRank.tier(13) === 'ga', 'tier edges');
  });

  T.add('relay (TURN) settings', () => {
    const saved = KT.CONTEST_ICE_SERVERS;
    KT.CONTEST_ICE_SERVERS = [];
    ok(!KT.net.hasRelay(), 'no relay configured by default');
    let cfg = KT.net.iceConfig();
    ok(cfg.iceServers.length === 2 && cfg.iceServers.every((s) => /^stun:/.test(s.urls)) && !cfg.iceTransportPolicy, 'STUN only, normal policy');
    ok(!JSON.stringify(cfg).includes('peerjs.com'), "PeerJS's dead relays are not used");
    KT.CONTEST_ICE_SERVERS = [{ urls: 'stun:stun.relay.metered.ca:80' }, { urls: 'turn:global.relay.metered.ca:80', username: 'u', credential: 'c' },
      { urls: 'turns:global.relay.metered.ca:443?transport=tcp', username: 'u', credential: 'c' }, null, { nourl: 1 }];
    ok(KT.net.hasRelay(), 'relay detected from a pasted Metered array');
    cfg = KT.net.iceConfig();
    ok(cfg.iceServers.length === 4 && cfg.iceServers.filter((s) => /^turns?:/.test(s.urls)).length === 2, 'TURN entries added, junk skipped');
    KT.net.forceRelay = true;
    ok(KT.net.iceConfig().iceTransportPolicy === 'relay', 'test mode forces the relay path');
    KT.net.forceRelay = false;
    KT.CONTEST_ICE_SERVERS = saved;
  });

  T.add('time limit: 12 s per question, time up ends the match', async () => {
    const CR = KT.contestRoom;
    ok(CR.PER_QUESTION_MS === 12000, '12 s per question');
    ok(['10', '15', '20', '30'].map((n) => CR.limitText(Number(n))).join() === '2 phút,3 phút,4 phút,6 phút', 'minutes per size: ' + [10, 15, 20, 30].map(CR.limitText).join());
    CR.PER_QUESTION_MS = 200;                       // 10 questions = 2 s, keeps the test short
    try {
      const R = CR.create({ code: 'TIME1', n: 10 });
      const pair = KT.net.localPair();
      R.attach(pair[0]);
      const c = KT.contestClient.create({});
      await c.join('TIME1', 'Chậm rãi', 't1', { link: pair[1] });
      ok(c.s.room.limit === 2000, 'players are told the limit: ' + c.s.room.limit);
      R.start();
      await sleep(CR.START_DELAY + 50);
      c.answer(c.s.specs[0].w, 1000);
      await sleep(1000);
      ok(R.phase === 'playing', 'still playing before the limit');
      await sleep(1200);
      ok(R.phase === 'ended' && R.reason === 'time', 'time up ends the match: ' + R.phase + '/' + R.reason);
      ok(c.s.phase === 'ended' && c.s.board[0].answered === 1 && c.s.board[0].score > 100, 'ranking counts what was done in time');
      ok(c.answer(c.s.specs[1].w, 100) === null, 'no answers after the end');
      R.close();
    } finally { CR.PER_QUESTION_MS = 12000; }
  });

  T.add('names and codes', () => {
    const c = KT.contestRoom.cleanName, key = KT.contestRoom.nameKey;
    ok(c('  An   Bình  ') === 'An Bình', 'spaces collapsed');
    ok(c('<b>Lan</b>') === 'bLan/b', 'angle brackets dropped');
    ok(c('a\u0000b\nc') === 'abc', 'control characters dropped');
    ok(Array.from(c('x'.repeat(50))).length === 20, 'at most 20 characters');
    ok(key('ĐỨC') === key('đức') && key('Đức') !== key('Duc'), 'case-insensitive, diacritics kept');
    for (let i = 0; i < 200; i++) ok(KT.net.validCode(KT.net.newCode()), 'generated code valid');
    ok(KT.net.validCode('k7p2q') && !KT.net.validCode('K7P2') && !KT.net.validCode('K0P2Q'), 'code check');
  });

  T.add('hostile messages from a host are cleaned', async () => {
    const [a, b] = KT.net.localPair();
    const c = KT.contestClient.create({});
    const joined = c.join('EVIL1', 'Bình', 'v1', { link: b });
    a.onMessage(() => {});
    a.send({ t: 'welcome', sid: '<b>', name: '<img src=x onerror=alert(1)>', phase: '__proto__', room: { name: 7, n: '<svg>', match: 'x' },
      players: [null, { sid: '2', name: { x: 1 }, host: 'yes' }], board: [{ rank: '<i>', name: 'A', score: '9e9x', correct: 'NaN' }] });
    await joined;
    const s = c.s;
    ok(s.sid === 0 && s.phase === 'lobby' && s.room.n === 0 && s.room.match === 0, 'numbers and phase normalised');
    ok(s.players.length === 1 && s.players[0].sid === 2 && s.players[0].host === true && typeof s.players[0].name === 'string', 'roster rows normalised');
    ok(s.board.length === 1 && s.board[0].rank === 0 && s.board[0].score === 0 && s.board[0].tier === 'ga', 'board rows normalised');
    a.send({ t: 'end', board: 'nope', n: '<x>', reason: '<script>', room: null });
    await sleep(20);
    ok(Array.isArray(s.board) && s.board.length === 0 && s.n === 0 && s.reason.length <= 10, 'end message normalised');
    ok(!KT.contestQuestions.valid({ t: '__proto__', w: '__proto__', m: '__proto__', o: ['__proto__'] }), 'prototype keys are not valid questions');
    c.leave(true);
  });
})();
