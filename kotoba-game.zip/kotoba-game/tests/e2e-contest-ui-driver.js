/* Thi đấu UI end-to-end without network: drives the real screens in headless Chrome, with rooms on
   in-memory links. Covers the hub form, the invite screen, a host who only watches (lobby, live
   progress, finish banner, ranking, new match), one player's whole race through the UI, and the
   ranking tiers with Mochi's three lines. Prints "E2E: PASS|FAIL …" into #out. */
(async function () {
  const KT = window.KT, X = KT.contest, $ = (s) => document.querySelector(s), $$ = (s) => Array.from(document.querySelectorAll(s));
  const out = [], fails = [];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const check = (c, m) => { if (!c) fails.push(m); };
  const click = async (sel) => { const el = typeof sel === 'string' ? $(sel) : sel; if (!el) throw new Error('missing element ' + sel); el.click(); await sleep(30); };
  const until = async (fn, ms, label) => {
    const t0 = Date.now();
    for (;;) { try { if (fn()) return true; } catch (e) { /* not yet */ } if (Date.now() - t0 > ms) { fails.push('timeout: ' + label); return false; } await sleep(50); }
  };
  const overflow = (where) => { const w = document.documentElement.scrollWidth, v = window.innerWidth; if (w > v + 1) fails.push('horizontal overflow on ' + where + ': ' + w + ' > ' + v); };
  const sim = (R, pid, name) => { const p = KT.net.localPair(); R.attach(p[0]); const c = KT.contestClient.create({}); c.join(R.code, name, pid, { link: p[1] }); return c; };
  try {
    await sleep(200);
    check($$('#tabbar .nav-btn').length === 5, 'five tabs in the tab bar');
    await click('#tabbar [data-arg="contest"]');
    check(KT.app.screen === 'contest' && $('#tabbar [data-arg="contest"]').getAttribute('aria-current') === 'page', 'hub opens, tab highlighted');
    const rules = $('.ct-rules').textContent;
    check(/Bạn quá xuất sắc, xuất khẩu vô tư nha!/.test(rules) && /Cũng bình thường thôi\./.test(rules) && /とり \/ gà/.test(rules), 'Mochi lines on the hub');
    await click('[data-act="ctGroup"][data-arg="E"]');
    check(/^7 từ/.test($('#ct-wc').textContent), 'group E counts 7 words: ' + $('#ct-wc').textContent);
    await click('[data-act="ctGroup"][data-arg="all"]');
    await click('[data-act="ctToggle"][data-arg="plays"]');
    check($('#ct-host-name-f').hidden, 'host name hidden when the host only watches');
    await click('[data-act="ctToggle"][data-arg="plays"]');
    $('#ct-code').value = 'AB'; await click('[data-act="ctJoin"]');
    check(!$('#ct-join-err').hidden && /5 ký tự/.test($('#ct-join-err').textContent), 'short code message');
    $('#ct-code').value = 'K7P2Q'; $('#ct-name').value = '   '; await click('[data-act="ctJoin"]');
    check(/nhập tên/i.test($('#ct-join-err').textContent), 'empty name message');
    overflow('hub');
    KT.app.go('contestJoin', { code: 'k7p2q' });
    check($('.ct-code-inline').textContent === 'K7P2Q' && $('#tabbar').hidden, 'invite screen: code, no tab bar');
    overflow('invite screen');

    // A host who only watches; three simulated players on in-memory links.
    X.role = 'host'; X.plays = false;
    X.room = KT.contestRoom.create({ code: 'WATCH', name: 'Lớp xem', n: 10, guard: true, onChange: (k) => X.changed('host:' + k) });
    const sims = [0, 1, 2].map((i) => sim(X.room, 'sim' + i, 'Học sinh ' + (i + 1)));
    await sleep(80);
    KT.app.go('contestLobby');
    check($$('#ct-roster .ct-player').length === 3 && $$('.ct-kick').length === 3, 'host lobby: 3 players with remove buttons');
    check(!!$('.ct-note') && $('#ct-code-big').textContent === 'WATCH', 'file:// page: code shown, note instead of a link');
    overflow('host lobby');
    await click('[data-act="ctLobbySize"][data-arg="15"]');
    check(X.room.n === 15 && $('[data-act="ctLobbySize"][data-arg="15"]').getAttribute('aria-pressed') === 'true', 'question count changed in the lobby');
    check(/15 câu · 3 phút/.test($('[data-act="ctLobbySize"][data-arg="15"]').textContent), 'lobby shows the time for 15 questions');
    await click('[data-act="ctLobbySize"][data-arg="10"]');
    await click('#ct-start');
    await until(() => KT.app.screen === 'contestPlay' && $('#ct-progress'), 2000, 'host live view');
    check(!$('#ct-count3').hidden, '3-2-1 on the host screen');
    await sleep(3300);
    sims.forEach((c, i) => { for (let q = 0; q < 10 - i * 3; q++) { const sp = c.s.specs[c.s.idx]; c.answer(sp.w, 1500); } });
    await until(() => $$('.ct-prow.is-done').length === 1 && !$('#ct-ending').hidden, 2000, 'live progress + finish banner');
    check($$('.ct-prow').length === 3 && /Học sinh 1/.test($('#ct-ending').textContent), 'three progress rows, banner names the finisher');
    overflow('host live view');
    await until(() => KT.app.screen === 'contestRank', 5000, 'host ranking 3 s after the finisher');
    check($$('.ct-row').length === 3 && /Học sinh 1/.test($('.ct-row').textContent), 'host ranking rows, winner first');
    await sleep(1100);
    check(!$('#ct-mochi').hidden && /Quán quân: Học sinh 1/.test($('#ct-mochi').textContent), 'Mochi announces the winner to the host');
    overflow('host ranking');
    await click('[data-act="ctRematch"]');
    await until(() => KT.app.screen === 'contestLobby', 2000, 'new match goes back to the lobby');
    X.leaveRoom();
    await sleep(500);
    check(sims.every((c) => c.s && c.s.phase === 'closed'), 'closing reaches every player');

    // One player racing through the real UI (the room runs in this page on an in-memory link).
    const R = KT.contestRoom.create({ code: 'PLAY2', name: 'Phòng thử', n: 10, guard: true });
    const pair = KT.net.localPair();
    R.attach(pair[0]);
    const rival = sim(R, 'rival', 'Đối thủ');
    X.role = 'player';
    await X.client.join('PLAY2', 'Mình', 'pid-me', { link: pair[1] });
    KT.app.go(X.screenFor());
    check(KT.app.screen === 'contestLobby' && $$('#ct-roster .ct-player').length === 2 && !!$('.ct-player.is-me'), 'player lobby with "Bạn"');
    overflow('player lobby');
    R.start();
    await until(() => KT.app.screen === 'contestPlay', 2000, 'race opens when the host starts');
    check($('#tabbar').hidden && !$('#ct-count3').hidden, 'full-screen race with 3-2-1');
    for (let i = 0; i < 10; i++) {
      if (!await until(() => $('#ct-q') && X.me().idx === i && $$('#ct-q [data-opt]').length && !$('#ct-q [data-opt]').disabled, 6000, 'question ' + (i + 1))) break;
      const spec = X.me().specs[i], btns = $$('#ct-q [data-opt]');
      if (i === 0) check(/^(2:00|1:5\d)$/.test($('#ct-clock').textContent), 'race clock counts down from 2:00: ' + $('#ct-clock').textContent);
      check(btns.filter((b) => b.dataset.opt === spec.w).length === 1, 'one correct option at question ' + (i + 1));
      overflow('race question ' + (i + 1) + ' (' + spec.t + ')');
      if (i === 3) { await click(btns.find((b) => b.dataset.opt !== spec.w)); check(/Đáp án/.test($('#ct-fb').textContent), 'a wrong answer shows the right one'); }
      else await click(btns.find((b) => b.dataset.opt === spec.w));
      if (i === 0) for (let q = 0; q < 2; q++) { const sp = rival.s.specs[rival.s.idx]; rival.answer(sp.w, 4000); }
    }
    await until(() => KT.app.screen === 'contestRank', 6000, 'ranking after finishing');
    check(/Bạn hạng 1\/2/.test(($('.ct-rank-head h1') || {}).textContent), 'rank 1 of 2');
    await sleep(1100);
    check(/Bạn quá xuất sắc, xuất khẩu vô tư nha!/.test($('#ct-mochi').textContent), 'top-5 line for rank 1');
    check((X.prefs.history || [])[0] && X.prefs.history[0].rank === 1, 'match saved in recent matches');
    overflow('player ranking');
    R.close();
    await until(() => KT.app.screen === 'contest' && !X.role, 3000, 'a closed room sends the player to the hub');

    // Time limit reached with nobody finished: "Sắp hết giờ" banner, then the ranking says time is up.
    KT.contestRoom.PER_QUESTION_MS = 1500;          // 10 questions = 15 s instead of 2 minutes
    X.role = 'host'; X.plays = false;
    X.room = KT.contestRoom.create({ code: 'TIMEUP', name: 'Hết giờ', n: 10, onChange: (k) => X.changed('host:' + k) });
    const slow = sim(X.room, 'slow', 'Chậm');
    await sleep(80);
    KT.app.go('contestLobby');
    await click('#ct-start');
    await until(() => KT.app.screen === 'contestPlay', 2000, 'timed match starts');
    await sleep(3300);
    slow.answer(slow.s.specs[0].w, 1000);
    await until(() => !$('#ct-ending').hidden && /Sắp hết giờ/.test($('#ct-ending').textContent), 16000, 'last-10-seconds banner');
    check($('#ct-clock').classList.contains('low'), 'clock turns red near the end');
    await until(() => KT.app.screen === 'contestRank', 15000, 'time up shows the ranking');
    check(/Hết giờ làm bài/.test($('.ct-rank-head').textContent) && $$('.ct-row').length === 1, 'ranking says time is up');
    KT.contestRoom.PER_QUESTION_MS = 12000;
    X.leaveRoom();
    await sleep(400);

    // Ranking tiers on a 15-player board, seen as rank 14, 8 and 2.
    const board = KT.contestRank.rank(Array.from({ length: 15 }, (_, i) => ({ sid: i + 1, name: 'Bạn số ' + (i + 1), score: 2200 - i * 90,
      correct: 15 - Math.floor(i / 2), answered: 15, done: i < 9, timeMs: 70000 + i * 1500 })));
    X.role = 'player';
    X.client.s = { code: 'K7P2Q', sid: 14, name: 'Bạn số 14', phase: 'ended', board, n: 15, reason: 'first', by: 'Bạn số 1', room: { name: 'Lớp đông', n: 15 }, players: [] };
    const expect = { 14: /とり \/ gà/, 8: /Cũng bình thường thôi\./, 2: /Bạn quá xuất sắc, xuất khẩu vô tư nha!/ };
    for (const sid of [14, 8, 2]) {
      X.client.s.sid = sid;
      KT.app.go('contestRank');
      await sleep(1100);
      check(expect[sid].test($('#ct-mochi').textContent), 'Mochi line for rank ' + sid);
      check($$('.ct-row').length === 15 && $$('.ct-row .ct-tier.tier-ga').length === 3, 'tier chips on the board');
      overflow('ranking seen as rank ' + sid);
    }
    check(!!$('.ct-row.is-me .ct-rank.r2'), 'own row highlighted');
    X.client.s.sid = 14; KT.app.go('contestRank'); await sleep(1100);
    check(!!$('#ct-mochi .ct-mochi-chicken svg'), 'chicken drawn for とり / gà');
    X.client.s = null; X.role = null;
    out.push('contest UI: hub, invite, host watching (lobby, live view, ranking, new match), player race, 3 Mochi tiers');
  } catch (e) { fails.push('EXCEPTION ' + e.message + '\n' + e.stack); }
  const errs = window.__errors || [];
  out.unshift((fails.length || errs.length ? 'E2E: FAIL' : 'E2E: PASS') + ' · contest UI · viewport ' + window.innerWidth + 'px');
  document.getElementById('out').textContent = out.concat(fails.map((f) => 'FAIL ' + f), errs.map((e) => 'JS ' + e)).join('\n');
})();