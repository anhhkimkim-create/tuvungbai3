/* Thi đấu live end-to-end over the real network: two copies of the game in iframes (host 1000px,
   player 375px) meet through the PeerJS signalling server and play a full match over WebRTC.
   Checks: invite-link boot, duplicate name, lobby, start, same questions, the 3 s end rule, the
   same ranking + Mochi on both, new match, closing. Needs internet; runs in real time, so the
   verdict goes to the console ("E2E-LIVE: PASS|FAIL …") as well as #out. Command: see README. */
(async function () {
  const out = [], fails = [], errs = [];
  const say = (m) => { out.push(m); console.log('E2E-LIVE step: ' + m); };
  const check = (c, m) => { if (!c) { fails.push(m); console.log('E2E-LIVE fail: ' + m); } };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const H = document.getElementById('host'), P = document.getElementById('player');
  const W = (f) => f.contentWindow, D = (f) => f.contentWindow.document;
  const $ = (f, s) => D(f).querySelector(s), $$ = (f, s) => Array.from(D(f).querySelectorAll(s));
  async function until(fn, ms, label) {
    const t0 = Date.now();
    for (;;) {
      try { if (fn()) return true; } catch (e) { /* not ready yet */ }
      if (Date.now() - t0 > ms) { check(false, 'timeout: ' + label); return false; }
      await sleep(100);
    }
  }
  const click = async (f, s) => { const el = typeof s === 'string' ? $(f, s) : s; if (!el) throw new Error('missing ' + s); el.click(); await sleep(80); };
  const type = (f, s, v) => { const el = $(f, s); el.value = v; el.dispatchEvent(new (W(f).Event)('input', { bubbles: true })); };
  const hook = (f, tag) => {
    W(f).addEventListener('error', (e) => errs.push(tag + ': ' + e.message + ' @' + String(e.filename || '').split('/').pop() + ':' + e.lineno));
    W(f).addEventListener('unhandledrejection', (e) => errs.push(tag + ' promise: ' + ((e.reason && e.reason.message) || e.reason)));
  };
  const overflow = (f, where) => { const d = D(f).documentElement; if (d.scrollWidth > W(f).innerWidth + 1) fails.push('overflow ' + where + ': ' + d.scrollWidth + ' > ' + W(f).innerWidth); };

  /** Click the right (or a wrong) option of the question on screen; false while none is clickable. */
  function answerUp(f, K, right) {
    const s = K.contest.me(), btns = $$(f, '#ct-q [data-opt]');
    if (!s || !s.specs || !btns.length || btns[0].disabled) return false;
    const spec = s.specs[s.idx];
    (right ? btns.find((x) => x.dataset.opt === spec.w) : btns.find((x) => x.dataset.opt !== spec.w)).click();
    return true;
  }
  async function race(f, K, pace, wrongEvery, label) {
    let n = 0;
    while (K.app.screen === 'contestPlay' && K.contest.me() && K.contest.me().idx < K.contest.me().specs.length) {
      const right = !(wrongEvery && (K.contest.me().idx + 1) % wrongEvery === 0);
      if (answerUp(f, K, right)) { n++; await sleep(pace); } else await sleep(60);
    }
    say(label + ' answered ' + n);
  }

  const RELAY = new URLSearchParams(location.search).get('relay') === '1';   // ?relay=1: TURN path only
  try {
    await until(() => W(H).KT && W(H).KT.app.screen === 'start', 20000, 'host page boots');
    hook(H, 'host');
    const HK = W(H).KT;
    HK.contest._pid = 'e2e-host';
    if (RELAY) { HK.net.forceRelay = true; say('relay-only mode, relay configured: ' + HK.net.hasRelay()); }
    HK.app.go('contest');
    type(H, '#ct-room', 'Lớp E2E'); type(H, '#ct-host-name', 'Cô Lan');
    await click(H, '[data-act="ctSize"][data-arg="10"]');
    const t0 = Date.now();
    await click(H, '[data-act="ctCreate"]');
    if (!await until(() => HK.app.screen === 'contestLobby', 30000, 'room registered on the signalling server')) {
      throw new Error('no room: ' + (($(H, '#ct-create-err') || {}).textContent || ''));
    }
    const code = HK.contest.room.code;
    say('room ' + code + ' registered in ' + (Date.now() - t0) + 'ms');
    check($(H, '#ct-code-big').textContent === code && $$(H, '#ct-roster .ct-player').length === 1, 'host lobby: code + host listed');

    P.src = '../index.html?phong=' + code.toLowerCase();
    await until(() => W(P).KT && W(P).KT.app && W(P).KT.app.screen === 'contestJoin', 20000, 'invite link opens the join screen');
    hook(P, 'player');
    const PK = W(P).KT;
    PK.contest._pid = 'e2e-player';
    if (RELAY) PK.net.forceRelay = true;
    check($(P, '.ct-code-inline').textContent === code, 'join screen shows the code from the link');
    overflow(P, 'player join');
    type(P, '#ctj-name', 'cô LAN');
    await click(P, '[data-act="ctJoinGo"]');
    await until(() => !$(P, '#ctj-err').hidden, 30000, 'answer to a duplicate name');
    check(/đã có người dùng/.test($(P, '#ctj-err').textContent), 'duplicate name rejected over the network: ' + $(P, '#ctj-err').textContent);
    type(P, '#ctj-name', 'Bình');
    const t1 = Date.now();
    await click(P, '[data-act="ctJoinGo"]');
    await until(() => PK.app.screen === 'contestLobby', 30000, 'player joins the lobby');
    say('player joined in ' + (Date.now() - t1) + 'ms');
    await until(() => $$(H, '#ct-roster .ct-player').length === 2 && $$(P, '#ct-roster .ct-player').length === 2, 8000, 'both lobbies list 2 players');
    overflow(P, 'player lobby');

    await click(H, '#ct-start');
    await until(() => HK.app.screen === 'contestPlay' && PK.app.screen === 'contestPlay', 8000, 'both devices open the race');
    check(!$(P, '#ct-count3').hidden, '3-2-1 on the player');
    const ps = PK.contest.me(), hs = HK.contest.me();
    check(ps.specs.length === 10 && JSON.stringify(ps.specs) === JSON.stringify(hs.specs), 'same 10 questions on both devices');
    await until(() => $(P, '#ct-q') && $(H, '#ct-q'), 8000, 'first questions shown');
    overflow(P, 'player race');
    const hostRun = race(H, HK, 1200, 3, 'host');
    await race(P, PK, 40, 0, 'player');
    const tDone = Date.now();
    await until(() => !$(H, '#ct-ending').hidden && /Bình/.test($(H, '#ct-ending').textContent), 3000, 'finish banner on the host');
    await until(() => HK.app.screen === 'contestRank' && PK.app.screen === 'contestRank', 9000, 'both on the ranking');
    const dt = Date.now() - tDone;
    say('ranking shown ' + dt + 'ms after the player finished');
    check(dt > 2000 && dt < 5500, 'match ended about 3 s after the first finisher (' + dt + 'ms)');
    await hostRun;
    const pb = PK.contest.me().board, hb = HK.contest.me().board;
    check(pb && hb && pb.length === 2 && JSON.stringify(pb) === JSON.stringify(hb), 'same ranking on both devices');
    check(pb[0].name === 'Bình' && pb[0].done && pb[0].correct === 10 && !pb[1].done, 'Bình wins 10/10, host unfinished');
    await until(() => !$(P, '#ct-mochi').hidden && !$(H, '#ct-mochi').hidden, 3000, 'Mochi comments on both devices');
    check(/Bạn quá xuất sắc, xuất khẩu vô tư nha!/.test($(P, '#ct-mochi').textContent), 'top-5 line for the player (rank 1)');
    check(/Bạn hạng 2\/2/.test($(H, '.ct-rank-head h1').textContent), 'host sees own rank 2/2');
    overflow(P, 'player ranking');

    await click(H, '[data-act="ctRematch"]');
    await until(() => HK.app.screen === 'contestLobby' && PK.app.screen === 'contestLobby', 8000, 'new match: both back in the lobby');
    await click(H, '[data-act="ctClose"]');
    await click(H, '.dialog-box [data-dlg="1"]');
    await until(() => PK.app.screen === 'contest' && !PK.contest.role, 10000, 'closing the room sends the player to the hub');
    check(HK.app.screen === 'contest' && !HK.contest.role, 'host back in the hub');
  } catch (e) { fails.push('EXCEPTION ' + e.message + '\n' + e.stack); }
  const verdict = fails.length || errs.length ? 'E2E-LIVE: FAIL' : 'E2E-LIVE: PASS';
  const text = [verdict].concat(out, fails.map((f) => 'FAIL ' + f), errs.map((e) => 'JS ' + e));
  document.getElementById('out').textContent = text.join('\n');
  console.log(text.join(' | '));
})();