/* Thi đấu logic tests, part 2: whole rooms on in-memory links — names, kick, start, the race, the
   3 s end rule, "chống bấm bừa", reconnecting with resent answers, late answers, a new match,
   closing and the host seat. */
(function () {
  const KT = window.KT, T = window.CTEST, ok = T.ok, sleep = T.sleep;
  const { START_DELAY, END_DELAY } = KT.contestRoom;

  const room = (opts) => KT.contestRoom.create(Object.assign({ code: 'TEST2', name: 'Lớp test', n: 10, groups: [], guard: true }, opts || {}));
  const linkTo = (R) => { const pair = KT.net.localPair(); R.attach(pair[0]); return pair[1]; };
  /** A remote device: in-memory link to the room; reconnects go through the same room. */
  function device(R, pid, name) {
    const d = { pid, name, events: [], result: null };
    d.c = KT.contestClient.create({ onChange: (k) => d.events.push(k), connect: () => Promise.resolve(linkTo(R)) });
    d.c.join(R.code, name, pid).then(() => { d.result = 'ok'; }, (e) => { d.result = e.code; });
    return d;
  }
  function answerOne(d, right, ms) {
    const s = d.c.s, spec = s.specs[s.idx];
    return d.c.answer(right ? spec.w : spec.o.find((id) => id !== spec.w), ms);
  }
  const hostRow = (R, pid) => R.players.find((p) => p.pid === pid);

  T.add('room: lobby, race, 3 s end, ranking, new match', async () => {
    const R = room({ code: 'ROOMA' });
    const ds = [];
    for (let i = 0; i < 16; i++) ds.push(device(R, 'pid' + i, 'Người ' + (i + 1)));
    const dup = device(R, 'pidX', '  người   1 '), empty = device(R, 'pidY', '   ');
    await sleep(40);
    ok(ds.every((d) => d.result === 'ok'), 'all 16 joined: ' + ds.map((d) => d.result).join());
    ok(dup.result === 'name-taken', 'duplicate name rejected: ' + dup.result);
    ok(empty.result === 'name-empty', 'empty name rejected: ' + empty.result);
    ok(R.roster().length === 16 && ds[0].c.s.players.length === 16, 'everyone sees 16 players');
    ok(new Set(ds.map((d) => d.c.s.sid)).size === 16, 'unique seats');
    ok(!/pid/.test(JSON.stringify(ds[0].c.s.players)), 'player ids are never broadcast');
    ok(R.kick(ds[15].c.s.sid), 'kick');
    await sleep(500);
    ok(R.roster().length === 15, 'kicked player removed');
    ok(ds[15].events.includes('reject') && ds[15].c.s.error === 'kicked', 'kicked device is told');
    const again = device(R, 'pid15', 'Người 16 mới');
    await sleep(40);
    ok(again.result === 'kicked', 'kicked device cannot come back: ' + again.result);

    const racers = ds.slice(0, 15);
    ok(R.start(), 'start');
    ok(!R.start(), 'second start refused');
    await sleep(30);
    const specs = JSON.stringify(R.specs);
    ok(R.specs.length === 10 && racers.every((d) => JSON.stringify(d.c.s.specs) === specs), 'same 10 questions for everyone');
    ok(racers.every((d) => d.c.s.phase === 'countdown' && d.events.includes('start')), 'start received');
    const late = device(R, 'pidLate', 'Đến muộn');
    await sleep(40);
    ok(late.result === 'started', 'no joining once started: ' + late.result);
    await sleep(START_DELAY + 30);
    ok(R.phase === 'playing', 'playing after the 3 s countdown');

    for (let q = 0; q < 10; q++) answerOne(racers[0], true, 300);
    for (let i = 1; i < 15; i++) { const k = Math.max(2, 9 - Math.floor(i / 2)); for (let q = 0; q < k; q++) answerOne(racers[i], q % 3 !== 2 || i < 3, 1000 + i * 200); }
    await sleep(40);
    ok(R.ending && R.ending.name === 'Người 1', 'first finisher starts the end countdown');
    ok(racers.every((d) => d.c.s.endLocal > 0 && d.c.s.by === 'Người 1'), 'everyone is told who finished');
    await sleep(END_DELAY - 500);
    ok(R.phase === 'playing', 'still playing just before 3 s');
    const before = hostRow(R, 'pid14').answers;
    answerOne(racers[14], true, 1500);
    await sleep(30);
    ok(hostRow(R, 'pid14').answers === before + 1, 'answers inside the 3 s still count');
    await sleep(600);
    ok(R.phase === 'ended' && R.reason === 'first', 'ended 3 s after the first finisher: ' + R.phase + '/' + R.reason);
    await sleep(30);
    const board = racers[3].c.s.board;
    ok(board.length === 15 && board[0].name === 'Người 1' && board[0].done, 'winner on top of 15 rows');
    ok(board.every((r, i) => r.rank === i + 1), 'ranks 1..15');
    for (let i = 1; i < board.length; i++) ok(KT.contestRank.order(board[i - 1], board[i]) <= 0, 'board order at ' + i);
    ok(board.filter((r) => r.tier === 'top').length === 5 && board.filter((r) => r.tier === 'mid').length === 7 && board.filter((r) => r.tier === 'ga').length === 3, 'tiers 5 / 7 / 3');
    ok(racers.every((d) => d.c.s.phase === 'ended' && JSON.stringify(d.c.s.board) === JSON.stringify(board)), 'same board on every device');
    ok(answerOne(racers[5], true, 100) === null, 'client refuses answers after the end');
    const pts = R.players.map((p) => p.score).join();
    racers[5].c.link.send({ t: 'ans', i: racers[5].c.s.idx, pick: 'x', ms: 1 });
    await sleep(30);
    ok(R.players.map((p) => p.score).join() === pts, 'host ignores answers after the end');
    racers.forEach((d) => { const p = hostRow(R, d.pid); ok(p.score === d.c.s.score && p.correct === d.c.s.correct, 'host and device agree for ' + d.name); });

    ok(R.reset(), 'new match');
    await sleep(30);
    ok(R.phase === 'lobby' && R.roster().length === 15, 'lobby keeps connected players');
    ok(racers.every((d) => d.c.s.phase === 'lobby' && !d.c.s.board && d.c.s.idx === 0), 'devices back in the lobby');
    ok(R.start(), 'second match starts');
    await sleep(30);
    ok(R.match === 2 && racers.every((d) => d.c.s.match === 2), 'match number 2 everywhere');
    await sleep(START_DELAY + 30);
    racers.forEach((d) => { for (let q = 0; q < 10; q++) answerOne(d, q !== 0, 2000); });
    await sleep(60);
    ok(R.phase === 'ended' && R.reason === 'all', 'everyone done ends at once: ' + R.reason);
    R.close();
    await sleep(500);
    ok(racers.every((d) => d.events.includes('closed')), 'closing tells every device');
  });

  T.add('chống bấm bừa + host ends', async () => {
    const R = room({ code: 'ROOMB', guard: true });
    const a = device(R, 'g1', 'Bấm bừa'), b = device(R, 'g2', 'Chăm chỉ'), c = device(R, 'g3', 'Thứ ba');
    await sleep(40); R.start(); await sleep(START_DELAY + 30);
    for (let q = 0; q < 10; q++) answerOne(a, q < 4, 200);
    await sleep(40);
    ok(!R.ending && R.phase === 'playing', 'a finisher under half right does not end the match');
    ok(a.c.s.idx === 10 && !a.c.s.endLocal, 'that player is done and waits');
    for (let q = 0; q < 10; q++) answerOne(b, q < 5, 3000);
    await sleep(40);
    ok(R.ending && R.ending.name === 'Chăm chỉ', 'a finisher with half right starts the countdown');
    await sleep(END_DELAY + 100);
    ok(R.phase === 'ended' && R.reason === 'first', 'ended by the valid finisher');
    const rc = b.c.s.board.find((r) => r.name === 'Thứ ba');
    ok(rc && rc.answered === 0 && !rc.done && rc.rank === 3, 'a player with no answers ranks last');
    ok(c.c.s.phase === 'ended', 'idle player also sees the end');
    R.close();
    const R2 = room({ code: 'ROOMC', guard: false });
    const x = device(R2, 'h1', 'Nhanh tay');
    device(R2, 'h2', 'Từ tốn');
    await sleep(40); R2.start(); await sleep(START_DELAY + 30);
    for (let q = 0; q < 10; q++) answerOne(x, q < 2, 200);
    await sleep(40);
    ok(R2.ending && R2.ending.name === 'Nhanh tay', 'with the guard off any finisher starts the end');
    R2.endNow();
    await sleep(30);
    ok(R2.phase === 'ended' && R2.reason === 'host', 'host can end the match');
    R2.close();
  });

  T.add('reconnect keeps the seat and resends answers', async () => {
    const R = room({ code: 'ROOMD' });
    const a = device(R, 'r1', 'Mất sóng');
    device(R, 'r2', 'Ổn định');
    await sleep(40); R.start(); await sleep(START_DELAY + 30);
    for (let q = 0; q < 3; q++) answerOne(a, true, 1000);
    await sleep(30);
    const seat = a.c.s.sid;
    a.c.link.close();
    await sleep(30);
    ok(a.c.s.offline && a.events.includes('offline'), 'device notices the drop');
    ok(hostRow(R, 'r1').on === false, 'host marks the player offline');
    answerOne(a, true, 1000); answerOne(a, false, 1000);
    ok(hostRow(R, 'r1').answers === 3, 'host has 3 answers while offline');
    await sleep(KT.contestClient.RETRY_MS + 200);
    ok(!a.c.s.offline && a.c.s.sid === seat, 'same seat after reconnecting');
    const hp = hostRow(R, 'r1');
    ok(hp.on && hp.answers === 5 && hp.correct === 4 && hp.score === a.c.s.score, 'offline answers resent: ' + hp.answers + '/' + hp.correct);
    a.c.leave(true);
    await sleep(300);
    const reload = device(R, 'r1', 'Tên khác');
    await sleep(40);
    ok(reload.result === 'ok' && reload.c.s.idx === 5 && reload.c.s.specs.length === 10, 'a reloaded page resumes at question 6');
    ok(reload.c.s.name === 'Mất sóng', 'mid-match the name stays the same');
    for (let q = 0; q < 5; q++) answerOne(reload, true, 1000);
    await sleep(40);
    ok(R.ending && R.ending.name === 'Mất sóng', 'the reconnected player can still finish first');
    R.close();
  });

  T.add('lobby leave, size change, host player', async () => {
    const R = room({ code: 'ROOME' });
    const a = device(R, 'l1', 'Minh');
    await sleep(40);
    a.c.leave(true);
    await sleep(300);
    ok(R.roster().length === 0, 'leaving the lobby removes the player');
    const b = device(R, 'l2', 'minh');
    await sleep(40);
    ok(b.result === 'ok', 'the name is free again');
    ok(R.setSize(20) && R.n === 20, 'question count can change in the lobby');
    await sleep(30);
    ok(b.c.s.room.n === 20, 'players see the new count');
    const fake = KT.net.localPair();
    R.attach(fake[0]);
    const liar = KT.contestClient.create({});
    await liar.join('ROOME', 'Giả chủ phòng', 'liar', { link: fake[1], host: true });
    ok(!R.roster().find((p) => p.name === 'Giả chủ phòng').host, 'a remote "host" claim is ignored');
    const pair = KT.net.localPair();
    R.attach(pair[0], true);
    const hc = KT.contestClient.create({});
    await hc.join('ROOME', 'Cô giáo', 'hostpid', { link: pair[1], host: true });
    const hostSeat = R.roster().find((p) => p.host);
    ok(hostSeat && hostSeat.name === 'Cô giáo', 'host flagged in the roster');
    ok(!R.kick(hostSeat.sid), 'the host cannot be removed');
    ok(R.start() && R.specs.length === 20, 'starts with 20 questions');
    R.close();
  });
})();
