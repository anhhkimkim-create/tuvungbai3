# KOTOBA — Thành phố thất lạc ký ức

Web game học 111 từ vựng tiếng Nhật Bài 3 (lấy từ ảnh vở ghi, không có ngữ pháp) cho người Việt mới học.
Không cần cài đặt, không cần đăng nhập. Tiến độ lưu trong trình duyệt trên máy đang chơi.

## Chơi
- Mở `index.html` bằng Chrome / Edge / Firefox (chạy trực tiếp từ file, không cần server).
- Bản online riêng tư: https://claude.ai/artifact/TE32PG5CkcsBg2AsYDUsqd

## Thi đấu (xếp hạng trực tiếp)
Tab **Thi đấu**: tạo phòng → link mời `?phong=MÃ` / QR → người chơi đặt tên → chủ phòng bấm Bắt đầu →
cả phòng làm cùng bộ câu hỏi (giới hạn 12 giây/câu: 10 câu = 2 phút) → kết thúc khi hết giờ hoặc 3 giây sau người
về đích đầu tiên → bảng xếp hạng theo điểm (đúng 100 + nhanh tối đa +50) + nhận xét của Mochi.
Hướng dẫn cho chủ phòng và cách đưa game lên Netlify: `HUONG-DAN-THI-DAU.md`.
- Không cần máy chủ/tài khoản: máy chủ phòng là trọng tài; người chơi nối WebRTC qua PeerJS 1.5.5
  (`js/vendor/`, tải khi dùng lần đầu; ghép phòng ở 0.peerjs.com, STUN Google + Cloudflare).
- Khác mạng cần TURN: TURN miễn phí của PeerJS (eu-0/us-0.turn.peerjs.com) và Open Relay tĩnh đã chết (không còn DNS, 11/2026).
  Dán ICE servers array (Metered: TURN Server → Credentials → ICE) vào `js/contest/contest-turn-relay-config.js`.
  Kiểm chứng đường relay: mở `tests/e2e-contest-live-two-devices.html?relay=1` (ép mọi kết nối qua TURN).
- `js/contest/`: kết nối (PeerJS + kết nối nội bộ), bộ câu hỏi chung, điểm/xếp hạng/lời Mochi, phòng (máy chủ phòng),
  người chơi (tự kết nối lại), phiên trên thiết bị. `js/ui/contest-*.js`: 4 màn hình. CSS: `css/contest-*.css`.

## Cấu trúc
- `js/data/` ngân hàng từ (nhóm A–I), 6 khu, các cặp dễ nhầm không được đặt cạnh nhau.
- `js/core/` lưu tiến độ, trạng thái từ và luật “Đã nhớ”, tạo đáp án, ghép kana, lập lượt chơi, âm thanh/giọng đọc.
- `js/art/` icon SVG, bản đồ isometric, cảnh từng khu, mèo Mochi.
- `js/ui/` các màn hình và 5 cơ chế chơi + ghép cặp.
- `css/` màu ngày/đêm, thành phần, màn hình, màn chơi.

## Kiểm thử (Chrome headless, không cần Node)
```powershell
$c = "C:\Program Files\Google\Chrome\Application\chrome.exe"
Start-Process $c -ArgumentList "--headless=new","--allow-file-access-from-files","--virtual-time-budget=200000","--dump-dom","file:///C:/Kichban/kotoba-game/tests/logic-tests.html" -RedirectStandardOutput out.html -Wait -NoNewWindow
```
Kết quả nằm trong `<pre id="out">` của `out.html`.
- `tests/logic-tests.html`: dữ liệu, đáp án duy nhất, ghép kana, luật “Đã nhớ”, mô phỏng 160 lượt.
- `tests/e2e-smoke-test.html`: tự chơi toàn bộ luồng (6 khu, ôn từ sai, thử thách hết giờ, sổ tay, cài đặt, đặt lại).
- `tests/e2e-mobile-frame-375px.html`: như trên trong khung 375px (thêm cờ `--disable-web-security`).

- `tests/contest-logic-tests.html`: bộ câu hỏi thi, điểm, hạng, phòng mô phỏng 16 người (tên trùng, mời ra, luật 3 giây,
  chống bấm bừa, mất mạng rồi vào lại, ván mới, dữ liệu xấu).
- `tests/e2e-contest-ui-test.html`: các màn hình Thi đấu không cần mạng (cả khung 375px: `e2e-mobile-frame-375px.html?p=e2e-contest-ui-test.html`).
- `tests/e2e-contest-live-two-devices.html`: hai bản game thi thật qua mạng (cần internet; chạy thời gian thực, kết quả in ra console):
```powershell
Start-Process $c -ArgumentList "--headless=new","--allow-file-access-from-files","--disable-web-security","--enable-logging=stderr","--v=0","--window-size=1420,900","--remote-debugging-port=0","file:///C:/Kichban/kotoba-game/tests/e2e-contest-live-two-devices.html" -RedirectStandardError live.txt
# đợi ~30 s rồi tìm "E2E-LIVE: PASS" trong live.txt
```
- Thêm/đổi script trong `index.html` thì chạy `powershell -ExecutionPolicy Bypass -File tests/build-e2e-pages-from-index.ps1`.

## Sửa từ vựng
Sửa trong `js/data/vocabulary-*.js`, thêm id vào `order` của khu trong `js/data/zones-challenge-types-and-content-rules.js`, rồi chạy lại test logic.